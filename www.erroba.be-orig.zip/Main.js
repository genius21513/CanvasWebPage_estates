var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var EnumHelper = /** @class */ (function () {
            function EnumHelper() {
            }
            EnumHelper.GetNames = function (e) {
                return Object.keys(e).filter(function (v) { return isNaN(parseInt(v, 10)); });
            };
            EnumHelper.GetName = function (e, value) {
                var names = EnumHelper.GetNames(e);
                return (value < names.length) ? names[value] : "";
            };
            EnumHelper.GetValues = function (e) {
                var numberKeys = Object.keys(e).map(function (v) { return parseInt(v, 10); }).filter(function (v) { return !isNaN(v); });
                return numberKeys;
            };
            return EnumHelper;
        }());
        Web.EnumHelper = EnumHelper;
        var GraphDocking;
        (function (GraphDocking) {
            GraphDocking[GraphDocking["Background"] = 0] = "Background";
            GraphDocking[GraphDocking["Top"] = 1] = "Top";
            GraphDocking[GraphDocking["Bottom"] = 2] = "Bottom";
            GraphDocking[GraphDocking["Left"] = 3] = "Left";
            GraphDocking[GraphDocking["Right"] = 4] = "Right";
            GraphDocking[GraphDocking["Center"] = 5] = "Center";
            GraphDocking[GraphDocking["CenterTopLeft"] = 6] = "CenterTopLeft";
            GraphDocking[GraphDocking["CenterTopRight"] = 7] = "CenterTopRight";
            GraphDocking[GraphDocking["CenterBottomLeft"] = 8] = "CenterBottomLeft";
            GraphDocking[GraphDocking["CenterBottomRight"] = 9] = "CenterBottomRight";
            GraphDocking[GraphDocking["CenterLeft"] = 10] = "CenterLeft";
            GraphDocking[GraphDocking["CenterRight"] = 11] = "CenterRight";
            GraphDocking[GraphDocking["CenterTop"] = 12] = "CenterTop";
            GraphDocking[GraphDocking["CenterBottom"] = 13] = "CenterBottom";
            GraphDocking[GraphDocking["CenterNumpad7"] = 14] = "CenterNumpad7";
            GraphDocking[GraphDocking["CenterNumpad8"] = 15] = "CenterNumpad8";
            GraphDocking[GraphDocking["CenterNumpad9"] = 16] = "CenterNumpad9";
            GraphDocking[GraphDocking["CenterNumpad4"] = 17] = "CenterNumpad4";
            GraphDocking[GraphDocking["CenterNumpad5"] = 18] = "CenterNumpad5";
            GraphDocking[GraphDocking["CenterNumpad6"] = 19] = "CenterNumpad6";
            GraphDocking[GraphDocking["CenterNumpad1"] = 20] = "CenterNumpad1";
            GraphDocking[GraphDocking["CenterNumpad2"] = 21] = "CenterNumpad2";
            GraphDocking[GraphDocking["CenterNumpad3"] = 22] = "CenterNumpad3";
            GraphDocking[GraphDocking["Overlay"] = 23] = "Overlay";
        })(GraphDocking = Web.GraphDocking || (Web.GraphDocking = {}));
        var Align;
        (function (Align) {
            Align[Align["Floating"] = 0] = "Floating";
            Align[Align["TopLeft"] = 1] = "TopLeft";
            Align[Align["TopRight"] = 2] = "TopRight";
            Align[Align["BottomLeft"] = 3] = "BottomLeft";
            Align[Align["BottomRight"] = 4] = "BottomRight";
        })(Align = Web.Align || (Web.Align = {}));
        // context.font = "[font style] [font weight] [font size]px [font face]";
        var FontStyle;
        (function (FontStyle) {
            FontStyle[FontStyle["normal"] = 0] = "normal";
            FontStyle[FontStyle["italic"] = 1] = "italic";
            FontStyle[FontStyle["oblique"] = 2] = "oblique";
            FontStyle[FontStyle["inherit"] = 3] = "inherit";
        })(FontStyle = Web.FontStyle || (Web.FontStyle = {}));
        var FontWeight;
        (function (FontWeight) {
            FontWeight[FontWeight["normal"] = 0] = "normal";
            FontWeight[FontWeight["bold"] = 1] = "bold";
            FontWeight[FontWeight["bolder"] = 2] = "bolder";
            FontWeight[FontWeight["lighter"] = 3] = "lighter";
            FontWeight[FontWeight["auto"] = 4] = "auto";
            FontWeight[FontWeight["inherit"] = 5] = "inherit";
        })(FontWeight = Web.FontWeight || (Web.FontWeight = {}));
        var Requirement;
        (function (Requirement) {
            Requirement[Requirement["Mandatory"] = 0] = "Mandatory";
            Requirement[Requirement["NiceToHave"] = 1] = "NiceToHave";
            Requirement[Requirement["Optional"] = 2] = "Optional";
        })(Requirement = Web.Requirement || (Web.Requirement = {}));
        var TextBaseline;
        (function (TextBaseline) {
            TextBaseline[TextBaseline["top"] = 0] = "top";
            TextBaseline[TextBaseline["bottom"] = 1] = "bottom";
            TextBaseline[TextBaseline["middle"] = 2] = "middle";
            TextBaseline[TextBaseline["alphabetic"] = 3] = "alphabetic";
            TextBaseline[TextBaseline["hanging"] = 4] = "hanging";
        })(TextBaseline = Web.TextBaseline || (Web.TextBaseline = {}));
        var TextAlign;
        (function (TextAlign) {
            TextAlign[TextAlign["start"] = 0] = "start";
            TextAlign[TextAlign["end"] = 1] = "end";
            TextAlign[TextAlign["left"] = 2] = "left";
            TextAlign[TextAlign["right"] = 3] = "right";
            TextAlign[TextAlign["center"] = 4] = "center";
        })(TextAlign = Web.TextAlign || (Web.TextAlign = {}));
        // Cursor enum for names supported in HTML5 (http://www.w3schools.com/cssref/pr_class_cursor.asp)
        // the actual names are mapped when the Renderer is instantiated.
        var MouseCursor;
        (function (MouseCursor) {
            MouseCursor[MouseCursor["Alias"] = 0] = "Alias"; // The cursor indicates an alias of something is to be created
            MouseCursor[MouseCursor["AllScroll"] = 1] = "AllScroll"; // The cursor indicates that something can be scrolled in any direction
            MouseCursor[MouseCursor["Auto"] = 2] = "Auto"; // Default.The browser sets a cursor
            MouseCursor[MouseCursor["Cell"] = 3] = "Cell"; // The cursor indicates that a cell (or set of cells) may be selected
            MouseCursor[MouseCursor["ContextMenu"] = 4] = "ContextMenu"; // The cursor indicates that a context- menu is available
            MouseCursor[MouseCursor["ColumnResize"] = 5] = "ColumnResize"; // The cursor indicates that the column can be resized horizontally
            MouseCursor[MouseCursor["Copy"] = 6] = "Copy"; // The cursor indicates something is to be copied
            MouseCursor[MouseCursor["Crosshair"] = 7] = "Crosshair"; // The cursor render as a crosshair
            MouseCursor[MouseCursor["Default"] = 8] = "Default"; // The default cursor
            MouseCursor[MouseCursor["EastResize"] = 9] = "EastResize"; // The cursor indicates that an edge of a box is to be moved right (east)
            MouseCursor[MouseCursor["EastWestResize"] = 10] = "EastWestResize"; // Indicates a bidirectional resize cursor
            MouseCursor[MouseCursor["Grab"] = 11] = "Grab"; // The cursor indicates that something can be grabbed
            MouseCursor[MouseCursor["Grabbing"] = 12] = "Grabbing"; // The cursor indicates that something can be grabbed
            MouseCursor[MouseCursor["Help"] = 13] = "Help"; // The cursor indicates that help is available
            MouseCursor[MouseCursor["Move"] = 14] = "Move"; // The cursor indicates something is to be moved
            MouseCursor[MouseCursor["NorthResize"] = 15] = "NorthResize"; // The cursor indicates that an edge of a box is to be moved up (north)
            MouseCursor[MouseCursor["NorthEastResize"] = 16] = "NorthEastResize"; // The cursor indicates that an edge of a box is to be moved up and right (north / east)
            MouseCursor[MouseCursor["NorthEastSouthWestResize"] = 17] = "NorthEastSouthWestResize"; // Indicates a bidirectional resize cursor
            MouseCursor[MouseCursor["NorthSouthResize"] = 18] = "NorthSouthResize"; // Indicates a bidirectional resize cursor
            MouseCursor[MouseCursor["NorthWestResize"] = 19] = "NorthWestResize"; // The cursor indicates that an edge of a box is to be moved up and left (north / west)
            MouseCursor[MouseCursor["NorthWestSouthEastResize"] = 20] = "NorthWestSouthEastResize"; // Indicates a bidirectional resize cursor
            MouseCursor[MouseCursor["NoDrop"] = 21] = "NoDrop"; // The cursor indicates that the dragged item cannot be dropped here
            MouseCursor[MouseCursor["None"] = 22] = "None"; // No cursor is rendered for the element
            MouseCursor[MouseCursor["NotAllowed"] = 23] = "NotAllowed"; // The cursor indicates that the requested action will not be executed
            MouseCursor[MouseCursor["Pointer"] = 24] = "Pointer"; // The cursor is a pointer and indicates a link
            MouseCursor[MouseCursor["Progress"] = 25] = "Progress"; // The cursor indicates that the program is busy (in progress)
            MouseCursor[MouseCursor["RowResize"] = 26] = "RowResize"; // The cursor indicates that the row can be resized vertically
            MouseCursor[MouseCursor["SouthResize"] = 27] = "SouthResize"; // The cursor indicates that an edge of a box is to be moved down (south)
            MouseCursor[MouseCursor["SouthEastResize"] = 28] = "SouthEastResize"; // The cursor indicates that an edge of a box is to be moved down and right (south / east)
            MouseCursor[MouseCursor["SouthWestResize"] = 29] = "SouthWestResize"; // The cursor indicates that an edge of a box is to be moved down and left (south / west)
            MouseCursor[MouseCursor["Text"] = 30] = "Text"; // The cursor indicates text that may be selected
            MouseCursor[MouseCursor["URL"] = 31] = "URL"; // A comma separated list of URLs to custom cursors.Note: Always specify a generic cursor at the end of the list, in case none of the URL-defined cursors can be used
            MouseCursor[MouseCursor["VerticalText"] = 32] = "VerticalText"; // The cursor indicates vertical- text that may be selected
            MouseCursor[MouseCursor["WestResize"] = 33] = "WestResize"; // The cursor indicates that an edge of a box is to be moved left (west)
            MouseCursor[MouseCursor["Wait"] = 34] = "Wait"; // The cursor indicates that the program is busy
            MouseCursor[MouseCursor["ZoomIn"] = 35] = "ZoomIn"; // The cursor indicates that something can be zoomed in
            MouseCursor[MouseCursor["ZoomOut"] = 36] = "ZoomOut"; // The cursor indicates that something can be zoomed out
            MouseCursor[MouseCursor["Initial"] = 37] = "Initial"; // Sets this property to its default value.Read about initial
        })(MouseCursor = Web.MouseCursor || (Web.MouseCursor = {}));
        var SpecialKey;
        (function (SpecialKey) {
            SpecialKey[SpecialKey["Tab"] = 0] = "Tab";
            SpecialKey[SpecialKey["Esc"] = 1] = "Esc";
            SpecialKey[SpecialKey["Backspace"] = 2] = "Backspace";
            SpecialKey[SpecialKey["Del"] = 3] = "Del";
            SpecialKey[SpecialKey["Home"] = 4] = "Home";
            SpecialKey[SpecialKey["End"] = 5] = "End";
            SpecialKey[SpecialKey["Left"] = 6] = "Left";
            SpecialKey[SpecialKey["Right"] = 7] = "Right";
            SpecialKey[SpecialKey["Up"] = 8] = "Up";
            SpecialKey[SpecialKey["Down"] = 9] = "Down";
            SpecialKey[SpecialKey["Enter"] = 10] = "Enter";
            SpecialKey[SpecialKey["Return"] = 11] = "Return";
            SpecialKey[SpecialKey["Insert"] = 12] = "Insert";
        })(SpecialKey = Web.SpecialKey || (Web.SpecialKey = {}));
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Guid = /** @class */ (function () {
            function Guid(guid) {
                this.guid = guid;
            }
            Guid.prototype.ToString = function () {
                return this.guid;
            };
            Guid.NewGuid = function () {
                var result;
                var i;
                var j;
                result = "";
                for (j = 0; j < 32; j++) {
                    if (j == 8 || j == 12 || j == 16 || j == 20)
                        result = result + '-';
                    i = Math.floor(Math.random() * 16).toString(16).toUpperCase();
                    result = result + i;
                }
                return new Guid(result);
            };
            return Guid;
        }());
        Web.Guid = Guid;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="../enums.ts" />
/// <reference path="../Guid.ts" />
/// <reference path="../Interfaces/IAutoDrawing.ts" />
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var AutoDrawingBase = /** @class */ (function () {
            function AutoDrawingBase(size, requirement, requiredReplacement) {
                if (requirement === void 0) { requirement = Web.Requirement.Mandatory; }
                if (requiredReplacement === void 0) { requiredReplacement = null; }
                this.guid = Web.Guid.NewGuid();
                this.dockStack = 0;
                this.layer = 0;
                this.alignedToCenter = false;
                this.visible = true;
                this.size = size;
                this.requirement = requirement;
                this.requiredReplacement = requiredReplacement;
            }
            Object.defineProperty(AutoDrawingBase.prototype, "Guid", {
                get: function () {
                    return this.guid;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AutoDrawingBase.prototype, "Dock", {
                get: function () {
                    return this.dock;
                },
                set: function (value) {
                    this.dock = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AutoDrawingBase.prototype, "DisplayName", {
                get: function () {
                    return this.displayName;
                },
                set: function (value) {
                    this.displayName = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AutoDrawingBase.prototype, "DockStack", {
                get: function () {
                    return this.dockStack;
                },
                set: function (value) {
                    this.dockStack = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AutoDrawingBase.prototype, "Layer", {
                get: function () {
                    return this.layer;
                },
                set: function (value) {
                    this.layer = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AutoDrawingBase.prototype, "AlignedToCenter", {
                get: function () {
                    return this.alignedToCenter;
                },
                set: function (value) {
                    this.alignedToCenter = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AutoDrawingBase.prototype, "Visible", {
                get: function () {
                    return this.visible;
                },
                set: function (value) {
                    this.visible = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AutoDrawingBase.prototype, "Requirement", {
                get: function () {
                    return this.requirement;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(AutoDrawingBase.prototype, "RequiredReplacement", {
                get: function () {
                    return this.requiredReplacement;
                },
                set: function (value) {
                    this.requiredReplacement = value;
                },
                enumerable: true,
                configurable: true
            });
            AutoDrawingBase.prototype.MeasureDock = function (otherSize) {
                return this.size;
            };
            AutoDrawingBase.prototype.Render = function (width, height) {
                // Do nothing.
            };
            AutoDrawingBase.prototype.HitTest = function (width, height, mouseEvent) {
                return false;
            };
            return AutoDrawingBase;
        }());
        Web.AutoDrawingBase = AutoDrawingBase;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Color = /** @class */ (function () {
            function Color(red, green, blue, alpha) {
                if (alpha === void 0) { alpha = 1; }
                this.Red = red;
                this.Green = green;
                this.Blue = blue;
                this.Alpha = alpha;
            }
            Object.defineProperty(Color, "Transparent", {
                // Color values as defined in the .NET System.Drawing.Color
                // The colors returned are created each time since we use there definitions just to set the initial values, but each object needs a separate instance
                // so the can be changed dynamically without affecting other objects.
                get: function () { return new Color(0, 0, 0, 0); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Black", {
                get: function () { return new Color(0, 0, 0, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "White", {
                get: function () { return new Color(255, 255, 255, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "DimGray", {
                get: function () { return new Color(105, 105, 105, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Silver", {
                get: function () { return new Color(192, 192, 192, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "LightSlateGray", {
                get: function () { return new Color(119, 136, 153, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Red", {
                get: function () { return new Color(255, 0, 0, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Brown", {
                get: function () { return new Color(165, 42, 42, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "LightSalmon", {
                get: function () { return new Color(255, 160, 122, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "DarkRed", {
                get: function () { return new Color(139, 0, 0, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "PureGreen", {
                get: function () { return new Color(0, 255, 0, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Green", {
                get: function () { return new Color(0, 128, 0, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "DarkOliveGreen", {
                get: function () { return new Color(85, 107, 47, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "DarkGreen", {
                get: function () { return new Color(0, 100, 0, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Blue", {
                get: function () { return new Color(0, 0, 255, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Yellow", {
                get: function () { return new Color(255, 255, 0, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Cyan", {
                get: function () { return new Color(0, 255, 255, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "DarkCyan", {
                get: function () { return new Color(0, 139, 139, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "LightBlue", {
                get: function () { return new Color(173, 216, 230, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "GreenYellow", {
                get: function () { return new Color(173, 255, 47, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "CadetBlue", {
                get: function () { return new Color(95, 158, 160, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "CornflowerBlue", {
                get: function () { return new Color(100, 149, 237, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Aqua", {
                get: function () { return new Color(0, 255, 255, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Orange", {
                get: function () { return new Color(255, 165, 0, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "OrangeRed", {
                get: function () { return new Color(255, 69, 0, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "DarkSeaGreen", {
                get: function () { return new Color(143, 188, 143, 1); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color, "Aquamarine", {
                get: function () { return new Color(127, 255, 212, 1); },
                enumerable: true,
                configurable: true
            });
            Color.FromColor = function (color, alpha) {
                if (alpha === void 0) { alpha = 1; }
                return new Color(color.red, color.green, color.blue, color.Alpha * alpha);
            };
            Color.FromOpaqueColor = function (color, alpha) {
                if (alpha === void 0) { alpha = 1; }
                return new Color(color.red, color.green, color.blue, alpha);
            };
            Color.prototype.Clone = function () {
                return new Color(this.red, this.green, this.blue, this.alpha);
            };
            Color.prototype.Copy = function (colorFrom, colorTo) {
                colorTo.Red = colorFrom.Red;
                colorTo.Green = colorFrom.Green;
                colorTo.Blue = colorFrom.Blue;
                colorTo.Alpha = colorFrom.Alpha;
            };
            Color.prototype.Equals = function (color) {
                return this.red === color.Red && this.green === color.Green && this.blue === color.Blue && this.alpha === color.Alpha;
            };
            Color.prototype.RGB_Equals = function (color) {
                return this.red === color.Red && this.green === color.Green && this.blue === color.Blue;
            };
            Object.defineProperty(Color.prototype, "Value", {
                get: function () { return this.stringValue; },
                enumerable: true,
                configurable: true
            });
            Color.prototype.ValueWithNewAlpha = function (alpha) {
                if (alpha < 0) {
                    alpha = 0;
                }
                else if (alpha >= 1) {
                    return this.stringValue;
                }
                return "rgba(" + this.red + "," + this.green + "," + this.blue + "," + this.alpha * alpha + ")";
            };
            Object.defineProperty(Color.prototype, "Red", {
                get: function () { return this.red; },
                set: function (value) {
                    value = Math.round(value);
                    if (value >= 0 && value <= 255) {
                        this.red = value;
                        this.stringValue = "rgba(" + this.red + "," + this.green + "," + this.blue + "," + this.alpha + ")";
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color.prototype, "Green", {
                get: function () { return this.green; },
                set: function (value) {
                    value = Math.round(value);
                    if (value >= 0 && value <= 255) {
                        this.green = value;
                        this.stringValue = "rgba(" + this.red + "," + this.green + "," + this.blue + "," + this.alpha + ")";
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color.prototype, "Blue", {
                get: function () { return this.blue; },
                set: function (value) {
                    value = Math.round(value);
                    if (value >= 0 && value <= 255) {
                        this.blue = value;
                        this.stringValue = "rgba(" + this.red + "," + this.green + "," + this.blue + "," + this.alpha + ")";
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Color.prototype, "Alpha", {
                get: function () { return this.alpha; },
                set: function (value) {
                    if (value >= 0 && value <= 1) {
                        this.alpha = value;
                        this.stringValue = "rgba(" + this.red + "," + this.green + "," + this.blue + "," + this.alpha + ")";
                    }
                },
                enumerable: true,
                configurable: true
            });
            Color.prototype.ToString = function () {
                return this.stringValue;
            };
            Color.Interpolate = function (targetColor, oldColor, newColor, oldPercentage, newPercentage) {
                targetColor.Red = Color.InterpolateNumber(oldColor.Red, newColor.Red, oldPercentage, newPercentage);
                targetColor.Green = Color.InterpolateNumber(oldColor.Green, newColor.Green, oldPercentage, newPercentage);
                targetColor.Blue = Color.InterpolateNumber(oldColor.Blue, newColor.Blue, oldPercentage, newPercentage);
                targetColor.Alpha = Color.InterpolateNumber(oldColor.Alpha, newColor.Alpha, oldPercentage, newPercentage);
            };
            Color.InterpolateNumber = function (oldNumber, newNumber, oldPercentage, newPercentage) {
                return (oldNumber * oldPercentage) + (newNumber * newPercentage);
            };
            return Color;
        }());
        Web.Color = Color;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="Interfaces/IDictionary.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Dictionary = /** @class */ (function () {
            function Dictionary() {
                this.keys = [];
                this.values = [];
            }
            Object.defineProperty(Dictionary.prototype, "Keys", {
                get: function () {
                    return this.keys;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Dictionary.prototype, "Values", {
                get: function () {
                    return this.values;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Dictionary.prototype, "Count", {
                get: function () { return this.keys.length; },
                enumerable: true,
                configurable: true
            });
            Dictionary.prototype.Add = function (key, value) {
                if (!this.ContainsKey(key)) {
                    this.keys.push(key);
                    this.values.push(value);
                }
            };
            Dictionary.prototype.Remove = function (key) {
                var index = this.keys.indexOf(key, 0);
                this.keys.splice(index, 1);
                this.values.splice(index, 1);
            };
            Dictionary.prototype.ContainsKey = function (key) {
                var index = this.keys.indexOf(key, 0);
                if (index < 0) {
                    return false;
                }
                return true;
            };
            Dictionary.prototype.ValueOf = function (key) {
                var index = this.keys.indexOf(key, 0);
                if (index < 0) {
                    return null;
                }
                return this.values[index];
            };
            Dictionary.prototype.ToLookup = function () {
                return this;
            };
            return Dictionary;
        }());
        Web.Dictionary = Dictionary;
        var SortedDictionary = /** @class */ (function () {
            function SortedDictionary() {
                this.keys = [];
                this.values = [];
            }
            Object.defineProperty(SortedDictionary.prototype, "Keys", {
                get: function () {
                    return this.keys;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SortedDictionary.prototype, "Values", {
                get: function () {
                    return this.values;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SortedDictionary.prototype, "Count", {
                get: function () { return this.keys.length; },
                enumerable: true,
                configurable: true
            });
            SortedDictionary.prototype.Add = function (key, value) {
                if (!this.ContainsKey(key)) {
                    var inserted = false;
                    var maxIndex = this.keys.length - 1;
                    for (var iKey = maxIndex; iKey >= 0; iKey--) {
                        var existingKey = this.keys[iKey];
                        if (key > existingKey) {
                            if (iKey == maxIndex) {
                                break;
                            }
                            var firstPartKeys = this.keys.slice(0, iKey - 1);
                            var secondPartKeys = this.keys.slice(iKey, maxIndex);
                            firstPartKeys.push(key);
                            this.keys = firstPartKeys.concat(secondPartKeys);
                            var firstPartValues = this.values.slice(0, iKey - 1);
                            var secondPartValues = this.values.slice(iKey, maxIndex);
                            firstPartValues.push(value);
                            this.values = firstPartValues.concat(secondPartValues);
                            inserted = true;
                            break;
                        }
                    }
                    if (!inserted) {
                        this.keys.push(key);
                        this.values.push(value);
                    }
                }
            };
            SortedDictionary.prototype.Remove = function (key) {
                var index = this.keys.indexOf(key, 0);
                this.keys.splice(index, 1);
                this.values.splice(index, 1);
            };
            SortedDictionary.prototype.ContainsKey = function (key) {
                var index = this.keys.indexOf(key, 0);
                if (index < 0) {
                    return false;
                }
                return true;
            };
            SortedDictionary.prototype.ValueOf = function (key) {
                var index = this.keys.indexOf(key, 0);
                if (index < 0) {
                    return null;
                }
                return this.values[index];
            };
            SortedDictionary.prototype.ToLookup = function () {
                return this;
            };
            return SortedDictionary;
        }());
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var SortedDictionary = /** @class */ (function () {
            function SortedDictionary() {
                this.keys = [];
                this.values = [];
            }
            Object.defineProperty(SortedDictionary.prototype, "Keys", {
                get: function () {
                    return this.keys;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SortedDictionary.prototype, "Values", {
                get: function () {
                    return this.values;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SortedDictionary.prototype, "Count", {
                get: function () {
                    return this.keys.length;
                },
                enumerable: true,
                configurable: true
            });
            SortedDictionary.prototype.Add = function (key, value) {
                if (!this.ContainsKey(key)) {
                    var inserted = false;
                    var maxIndex = this.keys.length - 1;
                    for (var iKey = maxIndex; iKey >= 0; iKey--) {
                        var existingKey = this.keys[iKey];
                        if (key > existingKey) {
                            if (iKey == maxIndex) {
                                break;
                            }
                            var firstPartKeys = this.keys.slice(0, iKey - 1);
                            var secondPartKeys = this.keys.slice(iKey, maxIndex);
                            firstPartKeys.push(key);
                            this.keys = firstPartKeys.concat(secondPartKeys);
                            var firstPartValues = this.values.slice(0, iKey - 1);
                            var secondPartValues = this.values.slice(iKey, maxIndex);
                            firstPartValues.push(value);
                            this.values = firstPartValues.concat(secondPartValues);
                            inserted = true;
                            break;
                        }
                    }
                    if (!inserted) {
                        this.keys.push(key);
                        this.values.push(value);
                    }
                }
            };
            SortedDictionary.prototype.Remove = function (key) {
                var index = this.keys.indexOf(key, 0);
                this.keys.splice(index, 1);
                this.values.splice(index, 1);
            };
            SortedDictionary.prototype.ContainsKey = function (key) {
                var index = this.keys.indexOf(key, 0);
                if (index < 0) {
                    return false;
                }
                return true;
            };
            SortedDictionary.prototype.ValueOf = function (key) {
                var index = this.keys.indexOf(key, 0);
                if (index < 0) {
                    return null;
                }
                return this.values[index];
            };
            SortedDictionary.prototype.ToLookup = function () {
                return this;
            };
            return SortedDictionary;
        }());
        Web.SortedDictionary = SortedDictionary;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="SortedDictionary.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var DockSide = /** @class */ (function () {
            function DockSide() {
                this.dockStackDictionary = new Web.SortedDictionary();
                this.Dimensions = new Web.Rectangle(0, 0, 0, 0);
            }
            Object.defineProperty(DockSide.prototype, "DockStacks", {
                get: function () { return this.dockStackDictionary.Values; },
                enumerable: true,
                configurable: true
            });
            DockSide.prototype.DockStackOf = function (stack) {
                if (this.dockStackDictionary.ContainsKey(stack)) {
                    return this.dockStackDictionary.ValueOf(stack);
                }
                return null;
            };
            DockSide.prototype.Add = function (dockStack) {
                var newDockStack = new Web.DockStack();
                this.dockStackDictionary.Add(dockStack, newDockStack);
                return newDockStack;
            };
            DockSide.prototype.Contains = function (dockStack) {
                return this.dockStackDictionary.ContainsKey(dockStack);
            };
            DockSide.prototype.NextDockStack = function () {
                if (this.dockStackDictionary.Count == 0) {
                    return 0;
                }
                // Search a free (empty stack)
                for (var iKey = 0; iKey < this.dockStackDictionary.Count; iKey++) {
                    var dockStack = this.dockStackDictionary.Values[iKey];
                    if (dockStack.IsEmpty) {
                        return this.dockStackDictionary.Keys[iKey];
                    }
                }
                return this.dockStackDictionary.Keys[this.dockStackDictionary.Count - 1] + 1;
            };
            return DockSide;
        }());
        Web.DockSide = DockSide;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="Interfaces/IGuid.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var DockStack = /** @class */ (function () {
            function DockStack() {
                this.guid = Web.Guid.NewGuid();
                this.layerDictionary = new Web.SortedDictionary();
                this.Dimensions = new Web.Rectangle(0, 0, 0, 0);
            }
            Object.defineProperty(DockStack.prototype, "Guid", {
                get: function () { return this.guid; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DockStack.prototype, "AlignedToCenter", {
                get: function () { return this.alignedToCenter; },
                set: function (value) { this.alignedToCenter = value; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DockStack.prototype, "IsEmpty", {
                get: function () { return this.layerDictionary.Count == 0; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DockStack.prototype, "DockLayers", {
                get: function () {
                    return this.layerDictionary.Values;
                },
                enumerable: true,
                configurable: true
            });
            DockStack.prototype.Add = function (layer) {
                var dockLayer = new Web.DockLayer();
                this.layerDictionary.Add(layer, dockLayer);
                return dockLayer;
            };
            DockStack.prototype.DockLayerOf = function (layer) {
                if (this.layerDictionary.ContainsKey(layer)) {
                    return this.layerDictionary.ValueOf(layer);
                }
                return null;
            };
            DockStack.prototype.Contains = function (layer) {
                return this.layerDictionary.ContainsKey(layer);
            };
            DockStack.prototype.Remove = function (layer) {
                var found = false;
                var layerToRemove = 0;
                var values = this.layerDictionary.Values;
                var keys = this.layerDictionary.Keys;
                for (var i = 0; i < values.length; i++) {
                    var value = values[i];
                    if (value === layer) {
                        layerToRemove = keys[i];
                        found = true;
                        break;
                    }
                }
                if (found) {
                    this.layerDictionary.Remove(layerToRemove);
                }
            };
            DockStack.prototype.NextDockLayer = function () {
                var keys = this.layerDictionary.Keys;
                if (keys.length == 0) {
                    return 0;
                }
                for (var i = keys.length - 1; i >= 0; i--) {
                    var layer = keys[i];
                    if (layer < Number.MAX_VALUE) {
                        return layer + 1;
                    }
                }
                return keys[keys.length - 1] - 1;
            };
            return DockStack;
        }());
        Web.DockStack = DockStack;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var DockLayer = /** @class */ (function () {
            function DockLayer() {
                this.autoDrawings = new Web.Dictionary();
                this.Dimensions = new Web.Rectangle(0, 0, 0, 0);
            }
            Object.defineProperty(DockLayer.prototype, "AutoDrawings", {
                get: function () { return this.autoDrawings.Values; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(DockLayer.prototype, "IsEmpty", {
                get: function () { return this.autoDrawings.Count == 0; },
                enumerable: true,
                configurable: true
            });
            DockLayer.prototype.AddAutoDrawing = function (autoDrawing) {
                this.autoDrawings.Add(autoDrawing.Guid, autoDrawing);
            };
            return DockLayer;
        }());
        Web.DockLayer = DockLayer;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="Interfaces/IEventHandler.ts" />
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var EventHandler = /** @class */ (function () {
            function EventHandler() {
                this.handlers = [];
            }
            EventHandler.prototype.On = function (handler) {
                this.Off(handler);
                this.handlers.push(handler);
            };
            EventHandler.prototype.Off = function (handler) {
                this.handlers = this.handlers.filter(function (h) { return h !== handler; });
            };
            EventHandler.prototype.Trigger = function (data) {
                this.handlers.slice(0).forEach(function (h) { return h(data); });
            };
            return EventHandler;
        }());
        Web.EventHandler = EventHandler;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="EventHandler.ts"/>
/// <reference path="Interfaces/IEventHandler.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var KeyInfo = /** @class */ (function () {
            function KeyInfo() {
                var _this = this;
                this.onKeyDown = new Web.EventHandler();
                this.ClearKeys = function () {
                    _this.F1 = false;
                    _this.Control = false;
                    _this.Alt = false;
                    _this.Shift = false;
                    _this.Tab = false;
                    _this.Escape = false;
                    _this.Backspace = false;
                    _this.Delete = false;
                    _this.Home = false;
                    _this.End = false;
                    _this.LeftArrow = false;
                    _this.RightArrow = false;
                    _this.UpArrow = false;
                    _this.DownArrow = false;
                    _this.Enter = false;
                    _this.Return = false;
                    _this.Insert = false;
                    _this.KeyChar = "";
                    _this.KeyCode = "";
                };
                this.TestSpecialKey = function (key) {
                    _this.ClearKeys();
                    _this.Tab = key === "Tab";
                    _this.Escape = key === "Esc";
                    _this.Backspace = key === "Backspace";
                    _this.Delete = key === "Del";
                    _this.Home = key === "Home";
                    _this.End = key === "End";
                    _this.LeftArrow = key === "Left";
                    _this.RightArrow = key === "Right";
                    _this.UpArrow = key === "Up";
                    _this.DownArrow = key === "Down";
                    _this.Enter = key === "Enter";
                    _this.Return = key === "Return";
                    _this.Insert = key === "Insert";
                };
                this.EventKeyDown = function (keyEvent) {
                    _this.Control = keyEvent.ctrlKey;
                    _this.Alt = keyEvent.altKey;
                    _this.Shift = keyEvent.shiftKey;
                    _this.TestSpecialKey(keyEvent.key);
                    _this.KeyCode = keyEvent.key;
                    var isF1 = keyEvent.key === "F1";
                    if (isF1) {
                        _this.F1 = true;
                    }
                    _this.KeyChar = keyEvent.key;
                    _this.TriggerKeyDown();
                };
                this.EventKeyUp = function (keyEvent) {
                    _this.Control = keyEvent.ctrlKey;
                    _this.Alt = keyEvent.altKey;
                    _this.Shift = keyEvent.shiftKey;
                    var isF1 = keyEvent.key === "F1";
                    if (isF1) {
                        _this.F1 = false;
                    }
                };
            }
            Object.defineProperty(KeyInfo.prototype, "KeyDown", {
                get: function () { return this.onKeyDown; },
                enumerable: true,
                configurable: true
            });
            KeyInfo.prototype.TriggerKeyDown = function () {
                this.onKeyDown.Trigger(this);
            };
            Object.defineProperty(KeyInfo.prototype, "IsSpecialKey", {
                get: function () {
                    return this.Enter || this.Return || this.Escape || this.Tab || this.LeftArrow || this.RightArrow || this.DownArrow || this.UpArrow || this.Insert || this.Home || this.Delete || this.Backspace;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(KeyInfo.prototype, "KeyChar", {
                get: function () { return this.keyChar; },
                set: function (value) {
                    if (value.length === 1) {
                        this.keyChar = value;
                    }
                },
                enumerable: true,
                configurable: true
            });
            return KeyInfo;
        }());
        Web.KeyInfo = KeyInfo;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Point = /** @class */ (function () {
            function Point(x, y) {
                this.x = x;
                this.y = y;
            }
            Point.prototype.Equals = function (other) {
                var xDiff = this.x - other.x;
                if (Math.abs(xDiff) < Point.differenceTolerance) {
                    var yDiff = this.y - other.y;
                    return (Math.abs(yDiff) < Point.differenceTolerance);
                }
                return false;
            };
            Point.differenceTolerance = .000001;
            return Point;
        }());
        Web.Point = Point;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="Interfaces/IQueue.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var FifoQueue = /** @class */ (function () {
            function FifoQueue(length) {
                this.list = [];
                this.maxLength = length;
            }
            FifoQueue.prototype.Push = function (value) {
                if (this.list.length == this.maxLength) {
                    this.Pop();
                }
                this.list.push(value);
                return this.list.length;
            };
            FifoQueue.prototype.Pop = function () {
                if (this.list.length > 0) {
                    var firstValue = this.list[0];
                    this.list.splice(0, 1);
                    return firstValue;
                }
                return null;
            };
            FifoQueue.prototype.Peek = function () {
                if (this.list.length > 0) {
                    var firstValue = this.list[0];
                    return firstValue;
                }
                return null;
            };
            FifoQueue.prototype.Clear = function () {
                this.list = [];
            };
            Object.defineProperty(FifoQueue.prototype, "Count", {
                get: function () { return this.list.length; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(FifoQueue.prototype, "IsEmpty", {
                get: function () { return this.list.length == 0; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(FifoQueue.prototype, "Any", {
                get: function () { return this.list.length != 0; },
                enumerable: true,
                configurable: true
            });
            return FifoQueue;
        }());
        Web.FifoQueue = FifoQueue;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Queue = /** @class */ (function () {
            function Queue() {
                this.list = [];
            }
            Queue.prototype.Push = function (value) {
                this.list.push(value);
                return this.list.length;
            };
            Queue.prototype.Pop = function () {
                if (this.list.length > 0) {
                    var firstValue = this.list[0];
                    this.list.splice(0, 1);
                    return firstValue;
                }
                return null;
            };
            Queue.prototype.Peek = function () {
                if (this.list.length > 0) {
                    var firstValue = this.list[0];
                    return firstValue;
                }
                return null;
            };
            Queue.prototype.Clear = function () {
                this.list = [];
            };
            Object.defineProperty(Queue.prototype, "Count", {
                get: function () { return this.list.length; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Queue.prototype, "IsEmpty", {
                get: function () { return this.list.length == 0; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Queue.prototype, "Any", {
                get: function () { return this.list.length != 0; },
                enumerable: true,
                configurable: true
            });
            return Queue;
        }());
        Web.Queue = Queue;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Rectangle = /** @class */ (function () {
            function Rectangle(x, y, width, height) {
                this.x = x;
                this.y = y;
                this.Width = width;
                this.Height = height;
            }
            Object.defineProperty(Rectangle.prototype, "X", {
                get: function () { return this.x; },
                set: function (value) {
                    this.x = value;
                    this.right = this.x + this.width;
                    this.centerX = this.x + this.width * .5;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Rectangle.prototype, "Y", {
                get: function () { return this.y; },
                set: function (value) {
                    this.y = value;
                    this.bottom = this.y + this.height;
                    this.centerY = this.y + this.height * .5;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Rectangle.prototype, "Width", {
                get: function () { return this.width; },
                set: function (value) {
                    if (value >= 0) {
                        this.width = value;
                        this.right = this.x + this.width;
                        this.centerX = this.x + this.width * .5;
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Rectangle.prototype, "Height", {
                get: function () { return this.height; },
                set: function (value) {
                    if (value >= 0) {
                        this.height = value;
                        this.bottom = this.y + this.height;
                        this.centerY = this.y + this.height * .5;
                    }
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Rectangle.prototype, "Left", {
                get: function () { return this.x; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Rectangle.prototype, "Right", {
                get: function () { return this.right; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Rectangle.prototype, "Top", {
                get: function () { return this.y; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Rectangle.prototype, "Bottom", {
                get: function () { return this.bottom; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Rectangle.prototype, "CenterX", {
                get: function () { return this.centerX; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Rectangle.prototype, "CenterY", {
                get: function () { return this.centerY; },
                enumerable: true,
                configurable: true
            });
            Rectangle.prototype.Clone = function () {
                var clone = new Rectangle(this.X, this.Y, this.Width, this.Height);
                return clone;
            };
            Rectangle.prototype.PointInside = function (x, y) {
                return x >= this.x && x <= this.right && y >= this.y && y <= this.bottom;
            };
            Rectangle.prototype.PointNearby = function (x, y, margin) {
                return x >= this.x - margin && x <= this.right + margin && y >= this.y - margin && y <= this.bottom + margin;
            };
            return Rectangle;
        }());
        Web.Rectangle = Rectangle;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="Point.ts" />
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Size = /** @class */ (function () {
            function Size(width, height) {
                this.Width = width;
                this.Height = height;
            }
            Size.prototype.Equals = function (other) {
                var widthDiff = this.Width - other.Width;
                if (Math.abs(widthDiff) < Web.Point.differenceTolerance) {
                    var heightDiff = this.Height - other.Height;
                    return (Math.abs(heightDiff) < Web.Point.differenceTolerance);
                }
                return false;
            };
            Size.differenceTolerance = .000001;
            return Size;
        }());
        Web.Size = Size;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="Color.ts"/>
/// <reference path="Font.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Theme = /** @class */ (function () {
            function Theme(backgroundColor, backgroundColorHighlight, sectionBackgroundColor, titleColor, selectedColor, frameColor, actionColor, mouseClickColor, progressColor, glossColor, messageColor, tracingColor, pageTitleFont, artTitleFont, menuFont, messageFont, tracingFont, startThemeAction) {
                if (startThemeAction === void 0) { startThemeAction = null; }
                this.BackgroundColor = backgroundColor;
                this.BackgroundColorHighlight = backgroundColorHighlight;
                this.SectionBackgroundColor = sectionBackgroundColor;
                this.TitleColor = titleColor;
                this.SelectedColor = selectedColor;
                this.FrameColor = frameColor;
                this.ActionColor = actionColor;
                this.MouseClickColor = mouseClickColor;
                this.ProgressColor = progressColor;
                this.GlossColor = glossColor;
                this.MessageColor = messageColor;
                this.TracingColor = tracingColor;
                this.PageTitleFont = pageTitleFont;
                this.ArtTitleFont = artTitleFont;
                this.MenuFont = menuFont;
                this.MessageFont = messageFont;
                this.TracingFont = tracingFont;
                this.StartThemeAction = startThemeAction;
            }
            Theme.prototype.Clone = function () {
                var clone = new Theme(this.BackgroundColor.Clone(), this.BackgroundColorHighlight.Clone(), this.SectionBackgroundColor.Clone(), this.TitleColor.Clone(), this.SelectedColor.Clone(), this.FrameColor.Clone(), this.ActionColor.Clone(), this.MouseClickColor.Clone(), this.ProgressColor.Clone(), this.GlossColor.Clone(), this.MessageColor.Clone(), this.TracingColor.Clone(), this.PageTitleFont.Clone(), this.ArtTitleFont.Clone(), this.MenuFont.Clone(), this.MessageFont.Clone(), this.TracingFont.Clone(), this.StartThemeAction);
                return clone;
            };
            Theme.prototype.StartThemeTransition = function (newTheme) {
                this.newTheme = newTheme;
                this.oldTheme = this.Clone();
                if (newTheme.StartThemeAction != null) {
                    newTheme.StartThemeAction();
                }
            };
            Theme.prototype.ThemeTransition = function (frame, nrOfFrames) {
                if (this.oldTheme != null && this.newTheme != null) {
                    var newPercentage = frame / nrOfFrames;
                    var oldPercentage = (nrOfFrames - frame) / nrOfFrames;
                    Web.Color.Interpolate(this.BackgroundColor, this.oldTheme.BackgroundColor, this.newTheme.BackgroundColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.BackgroundColorHighlight, this.oldTheme.BackgroundColorHighlight, this.newTheme.BackgroundColorHighlight, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.SectionBackgroundColor, this.oldTheme.SectionBackgroundColor, this.newTheme.SectionBackgroundColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.TitleColor, this.oldTheme.TitleColor, this.newTheme.TitleColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.SelectedColor, this.oldTheme.SelectedColor, this.newTheme.SelectedColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.FrameColor, this.oldTheme.FrameColor, this.newTheme.FrameColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.ActionColor, this.oldTheme.ActionColor, this.newTheme.ActionColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.MouseClickColor, this.oldTheme.MouseClickColor, this.newTheme.MouseClickColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.ProgressColor, this.oldTheme.ProgressColor, this.newTheme.ProgressColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.GlossColor, this.oldTheme.GlossColor, this.newTheme.GlossColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.MessageColor, this.oldTheme.MessageColor, this.newTheme.MessageColor, oldPercentage, newPercentage);
                    Web.Color.Interpolate(this.TracingColor, this.oldTheme.TracingColor, this.newTheme.TracingColor, oldPercentage, newPercentage);
                    if (frame == 0) {
                        this.PageTitleFont = this.newTheme.PageTitleFont;
                        this.ArtTitleFont = this.newTheme.ArtTitleFont;
                        this.MenuFont = this.newTheme.MenuFont;
                        this.MessageFont = this.newTheme.MessageFont;
                        this.TracingFont = this.newTheme.TracingFont;
                        this.StartThemeAction = this.newTheme.StartThemeAction;
                    }
                }
            };
            return Theme;
        }());
        Web.Theme = Theme;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="Dictionary.ts"/>
/// <reference path="Theme.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var ThemeManager = /** @class */ (function () {
            function ThemeManager(currentTheme) {
                this.CurrentThemeName = ThemeManager.ThemeDefault;
                this.themeDictionary = new Web.Dictionary();
                this.TransitionNrOfFrames = 180;
                this.transitionFrame = this.TransitionNrOfFrames + 1;
                this.CurrentTheme = currentTheme;
                this.themeDictionary.Add(ThemeManager.ThemeDefault, currentTheme.Clone());
            }
            ThemeManager.prototype.AddTheme = function (themeName, theme) {
                if (!this.themeDictionary.ContainsKey(themeName)) {
                    this.themeDictionary.Add(themeName, theme);
                }
            };
            ThemeManager.prototype.ChangeTheme = function (themeName) {
                if (themeName != this.CurrentThemeName && this.themeDictionary.ContainsKey(themeName)) {
                    this.transitionFrame = 0;
                    var newTheme = this.themeDictionary.ValueOf(themeName);
                    this.CurrentTheme.StartThemeTransition(newTheme);
                    this.CurrentThemeName = themeName;
                }
            };
            ThemeManager.prototype.PerformThemeTransition = function () {
                if (this.transitionFrame <= this.TransitionNrOfFrames) {
                    this.CurrentTheme.ThemeTransition(this.transitionFrame, this.TransitionNrOfFrames);
                    this.transitionFrame++;
                }
            };
            ThemeManager.ThemeDefault = "Default";
            return ThemeManager;
        }());
        Web.ThemeManager = ThemeManager;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="Color.ts"/>
/// <reference path="Dictionary.ts"/>
/// <reference path="DockSide.ts"/>
/// <reference path="DockStack.ts"/>
/// <reference path="DockLayer.ts"/>
/// <reference path="enums.ts"/>
/// <reference path="KeyInfo.ts"/>
/// <reference path="Point.ts"/>
/// <reference path="FifoQueue.ts"/>
/// <reference path="Queue.ts"/>
/// <reference path="Rectangle.ts"/>
/// <reference path="Size.ts"/>
/// <reference path="ThemeManager.ts"/>
/// <reference path="Interfaces/IAutoDrawing.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Renderer = /** @class */ (function () {
            function Renderer() {
            }
            Object.defineProperty(Renderer, "Phi", {
                // Phi also known as the Golden Ratio
                get: function () {
                    return 1.6108;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "ColorBlack", {
                get: function () {
                    return Renderer.colorBlack.Clone();
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "ColorWhite", {
                get: function () {
                    return Renderer.colorWhite.Clone();
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "BackgroundColor", {
                get: function () {
                    return Renderer.themeManager.CurrentTheme.BackgroundColor;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "ThemeManager", {
                get: function () {
                    return Renderer.themeManager;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "HighlightColor", {
                get: function () {
                    return Renderer.highlightColor;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "Canvas", {
                get: function () {
                    return Renderer.canvas;
                },
                enumerable: true,
                configurable: true
            });
            Renderer.AddAutoDrawing = function (autoDrawing) {
                var dockSide;
                if (Renderer.drawingDictionary.ContainsKey(autoDrawing.Dock)) {
                    dockSide = Renderer.drawingDictionary.ValueOf(autoDrawing.Dock);
                }
                else {
                    dockSide = new Web.DockSide();
                    Renderer.drawingDictionary.Add(autoDrawing.Dock, dockSide);
                }
                var dockStack;
                if (!dockSide.Contains(autoDrawing.DockStack)) {
                    dockStack = dockSide.Add(autoDrawing.DockStack);
                    dockStack.AlignedToCenter = autoDrawing.AlignedToCenter;
                }
                else {
                    dockStack = dockSide.DockStackOf(autoDrawing.DockStack);
                }
                var dockLayer;
                if (!dockStack.Contains(autoDrawing.Layer)) {
                    dockLayer = dockStack.Add(autoDrawing.Layer);
                }
                else {
                    dockLayer = dockStack.DockLayerOf(autoDrawing.Layer);
                }
                dockLayer.AddAutoDrawing(autoDrawing);
            };
            Renderer.MousePointForControlInAutoDrawing = function (dock) {
                var mousePoint = new Web.Point(Renderer.MouseX, Renderer.MouseY);
                var dimensions = Renderer.DimensionsOf(dock);
                mousePoint.x = mousePoint.x - dimensions.X;
                mousePoint.y = mousePoint.y - dimensions.Y;
                return mousePoint;
            };
            Renderer.DimensionsOf = function (dock) {
                if (Renderer.drawingDictionary.ContainsKey(dock)) {
                    var dockSide = Renderer.drawingDictionary.ValueOf(dock);
                    return dockSide.Dimensions;
                }
                return new Web.Rectangle(0, 0, 0, 0);
            };
            Renderer.MouseToAutoDrawing = function (autoDrawing) {
                if (Renderer.drawingDictionary.ContainsKey(autoDrawing.Dock)) {
                    var dockSide = Renderer.drawingDictionary.ValueOf(autoDrawing.Dock);
                    if (dockSide.Contains(autoDrawing.DockStack)) {
                        var dockStack = dockSide.DockStackOf(autoDrawing.DockStack);
                        var dimensions = dockStack.Dimensions;
                        return new Web.Point(Renderer.MouseX - dimensions.X, Renderer.MouseY - dimensions.Y);
                    }
                }
                return new Web.Point(Renderer.MouseX, Renderer.MouseY);
            };
            Renderer.NextDockStack = function (autoDrawing) {
                var dockSide = Renderer.drawingDictionary.ValueOf(autoDrawing.Dock);
                if (dockSide != null) {
                    return dockSide.NextDockStack();
                }
                return 0;
            };
            Renderer.Initialize = function (document, window, canvas, themeManager) {
                Renderer.document = document;
                Renderer.window = window;
                Renderer.canvas = canvas;
                Renderer.context = canvas.getContext("2d");
                Renderer.themeManager = themeManager;
                var numberKeys = Web.EnumHelper.GetValues(Web.GraphDocking);
                for (var iNumber = 0; iNumber < numberKeys.length; iNumber++) {
                    var nr = numberKeys[iNumber];
                    Renderer.drawingDictionary.Add(nr, new Web.DockSide());
                }
                canvas.addEventListener("mousedown", Renderer.MouseDown, false);
                canvas.addEventListener("mouseup", Renderer.MouseUp, false);
                canvas.addEventListener("mousemove", Renderer.MouseAction, false);
                canvas.addEventListener("touchstart", Renderer.TouchStart, false);
                canvas.addEventListener("touchmove", Renderer.TouchMove, false);
                canvas.addEventListener("touchend", Renderer.TouchEnd, false);
                var keyInfo = Renderer.KeyInfo;
                //window.addEventListener("keypress", keyInfo.EventKeyPress, false);
                window.addEventListener("keydown", keyInfo.EventKeyDown, false);
                window.addEventListener("keyup", keyInfo.EventKeyUp, false);
            };
            Renderer.PressSpecialKey = function (specialKey) {
                var key = Web.EnumHelper.GetName(Web.SpecialKey, specialKey);
                Renderer.KeyInfo.TestSpecialKey(key);
                Renderer.KeyInfo.TriggerKeyDown();
            };
            Renderer.PressKey = function (key) {
                if (key.length === 1) {
                    var keyInfo = Renderer.KeyInfo;
                    keyInfo.ClearKeys();
                    keyInfo.KeyChar = key;
                    keyInfo.KeyCode = key;
                    keyInfo.TriggerKeyDown();
                }
            };
            Object.defineProperty(Renderer, "MouseEvent", {
                get: function () {
                    return Renderer.mouseEvent;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "TouchEvent", {
                get: function () {
                    return Renderer.touchEvent;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "SwipingRight", {
                get: function () {
                    return Renderer.swipingRight;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "SwipingLeft", {
                get: function () {
                    return Renderer.swipingLeft;
                },
                enumerable: true,
                configurable: true
            });
            Renderer.MouseAction = function (mouseEvent) {
                Renderer.mouseEvent = mouseEvent;
                Renderer.mouseX = mouseEvent.pageX;
                Renderer.mouseY = mouseEvent.pageY;
                var ellapsed = Date.now() - Renderer.mouseDownTime;
                if (ellapsed > Renderer.mouseClickedTreshold) {
                    Renderer.mouseClicked = false;
                }
            };
            Renderer.TouchStart = function (touchEvent) {
                Renderer.touchEvent = touchEvent;
                Renderer.swipedLeft = false;
                Renderer.swipedRight = false;
                if (touchEvent.touches.length == 1) {
                    var touch = touchEvent.touches[0];
                    Renderer.touchStartX = touch.pageX;
                }
            };
            Renderer.TouchMove = function (touchEvent) {
                Renderer.touchEvent = touchEvent;
                if (touchEvent.touches.length == 1) {
                    var touch = touchEvent.touches[0];
                    var moveX = touch.pageX - Renderer.touchStartX;
                    if (moveX == 0) {
                        Renderer.swipingLeft = false;
                        Renderer.swipingRight = false;
                    }
                    else if (moveX < 0) {
                        Renderer.swipingLeft = false;
                        Renderer.swipingRight = true;
                    }
                    else {
                        Renderer.swipingLeft = true;
                        Renderer.swipingRight = false;
                    }
                }
            };
            Renderer.TouchEnd = function (touchEvent) {
                Renderer.touchEvent = touchEvent;
                Renderer.swipedLeft = Renderer.swipingLeft;
                Renderer.swipedRight = Renderer.swipingRight;
                Renderer.swipingLeft = false;
                Renderer.swipingRight = false;
            };
            Renderer.MouseUp = function (mouseEvent) {
                Renderer.mouseEvent = mouseEvent;
                Renderer.mouseX = mouseEvent.pageX;
                Renderer.mouseY = mouseEvent.pageY;
                var ellapsed = Date.now() - Renderer.mouseDownTime;
                if (ellapsed < Renderer.mouseClickedTreshold) {
                    Renderer.mouseClicked = true;
                }
                else {
                    Renderer.mouseClicked = false;
                }
                Renderer.firstMouseDown = true;
            };
            Renderer.MouseDown = function (mouseEvent) {
                if (Renderer.firstMouseDown) {
                    Renderer.mouseDownTime = Date.now();
                }
                Renderer.mouseEvent = mouseEvent;
                Renderer.mouseX = mouseEvent.pageX;
                Renderer.mouseY = mouseEvent.pageY;
                Renderer.mouseClicked = false;
                Renderer.firstMouseDown = false;
            };
            Object.defineProperty(Renderer, "MouseX", {
                get: function () {
                    return Renderer.mouseX;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "MouseY", {
                get: function () {
                    return Renderer.mouseY;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "MouseClicked", {
                get: function () {
                    return this.mouseClicked;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "Width", {
                get: function () {
                    return Renderer.width;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "Height", {
                get: function () {
                    return Renderer.height;
                },
                enumerable: true,
                configurable: true
            });
            Renderer.ResizeCanvas = function (width, height) {
                Renderer.canvas.width = width;
                Renderer.canvas.height = height;
                Renderer.width = width;
                Renderer.height = height;
            };
            // Translates and clips the canvas so that any following drawing operations are done on this 'new' canvas, which is part of the big canvas
            Renderer.SetRenderTarget = function (dimensions) {
                var context = Renderer.context;
                // Save context (restored in EndDraw()).
                context.save();
                // Clip to the desired dimensions
                context.beginPath();
                context.rect(dimensions.X, dimensions.Y, dimensions.Width, dimensions.Height);
                context.clip();
                // Translate so that all following drawing operations are relative to the new clipping region.
                context.translate(dimensions.X, dimensions.Y);
            };
            Renderer.EndDraw = function () {
                Renderer.context.restore();
            };
            Renderer.GetFontByName = function (fontname) {
                return "normal normal 12px " + fontname;
            };
            Renderer.GetFontByNameAndSize = function (fontname, size) {
                return "normal normal " + size + "px " + fontname;
            };
            Renderer.GetFontByNameWeightSize = function (fontname, weight, size) {
                return "normal " + weight + " " + size + "px " + fontname;
            };
            Renderer.GetFontByNameStyleWeightSize = function (fontname, style, weight, size) {
                var fontStyle = Web.EnumHelper.GetName(Web.FontStyle, style);
                var fontWeight = Web.EnumHelper.GetName(Web.FontWeight, weight);
                return fontStyle + " " + fontWeight + " " + size + "px " + fontname;
            };
            Renderer.MeasureText = function (text, font) {
                var context = Renderer.context;
                context.font = font.FontString;
                return new Web.Size(context.measureText(text).width, font.Size);
            };
            Renderer.MeasureTextWidth = function (text, font) {
                var context = Renderer.context;
                context.font = font.FontString;
                return context.measureText(text).width;
            };
            Renderer.DrawText = function (text, font, x, y, color, filled, baseLine, textAlign, otherContext) {
                if (filled === void 0) { filled = true; }
                if (baseLine === void 0) { baseLine = Web.TextBaseline.top; }
                if (textAlign === void 0) { textAlign = Web.TextAlign.left; }
                if (otherContext === void 0) { otherContext = null; }
                var context = (otherContext == null) ? Renderer.context : otherContext;
                context.font = font.FontString;
                context.textAlign = Web.EnumHelper.GetName(Web.TextAlign, textAlign);
                context.textBaseline = Web.EnumHelper.GetName(Web.TextBaseline, baseLine);
                if (filled) {
                    context.fillStyle = color.Value;
                    context.fillText(text, x, y);
                }
                else {
                    context.strokeStyle = color.Value;
                    context.strokeText(text, x, y);
                }
            };
            Renderer.DrawTextCenteredOnXAndY = function (text, font, x, y, color, baseLine, textAlign, fill, alpha) {
                if (baseLine === void 0) { baseLine = Web.TextBaseline.top; }
                if (textAlign === void 0) { textAlign = Web.TextAlign.left; }
                if (fill === void 0) { fill = true; }
                if (alpha === void 0) { alpha = 1; }
                var context = Renderer.context;
                context.font = font.FontString;
                var textWidth = context.measureText(text).width;
                x -= (textWidth * .5);
                var halfFontHeight = font.Size * .5;
                y -= halfFontHeight;
                context.font = font.FontString;
                context.textAlign = Web.EnumHelper.GetName(Web.TextAlign, textAlign);
                context.textBaseline = Web.EnumHelper.GetName(Web.TextBaseline, baseLine);
                if (fill) {
                    context.fillStyle = color.ValueWithNewAlpha(alpha);
                    context.fillText(text, x, y);
                }
                else {
                    context.strokeStyle = color.ValueWithNewAlpha(alpha);
                    context.strokeText(text, x, y);
                }
            };
            Renderer.DrawLine = function (x1, y1, x2, y2, lineWidth, color, otherContext) {
                if (otherContext === void 0) { otherContext = null; }
                var context = (otherContext == null) ? Renderer.context : otherContext;
                context.beginPath();
                context.moveTo(x1, y1);
                context.lineTo(x2, y2);
                context.lineWidth = lineWidth;
                context.strokeStyle = color.Value;
                context.stroke();
            };
            Renderer.DrawLines = function (points, color, lineWidth) {
                if (lineWidth === void 0) { lineWidth = 1; }
                var context = Renderer.context;
                context.beginPath();
                var firstPoint = points[0];
                context.moveTo(firstPoint.x, firstPoint.y);
                for (var iPoint = 1; iPoint < points.length; iPoint++) {
                    var point = points[iPoint];
                    context.lineTo(point.x, point.y);
                }
                context.lineWidth = lineWidth;
                context.strokeStyle = color.Value;
                context.stroke();
            };
            Renderer.DrawSine = function (xStart, xEnd, yAxis, yAmplitude, frequency, startAngle, nrOfSegments, color, lineWidth) {
                if (lineWidth === void 0) { lineWidth = 1; }
                if (frequency > 0 && nrOfSegments > 1) {
                    var context = Renderer.context;
                    context.beginPath();
                    var width = xEnd - xStart + 1;
                    var nrSegmentPerRotation = Math.floor(nrOfSegments / frequency);
                    var angleStep = Renderer.TwoPi / nrSegmentPerRotation;
                    var angle = Renderer.ToRadians * startAngle;
                    var x = xStart;
                    var xStep = width / (nrSegmentPerRotation * frequency);
                    var y = yAxis + yAmplitude * Math.sin(angle);
                    context.moveTo(x, y);
                    angle += angleStep;
                    x += xStep;
                    for (var segment = 0; segment < nrOfSegments; segment++) {
                        y = yAxis + yAmplitude * Math.sin(angle);
                        context.lineTo(x, y);
                        angle += angleStep;
                        x += xStep;
                    }
                    context.lineWidth = lineWidth;
                    context.strokeStyle = color.Value;
                    context.stroke();
                }
            };
            Renderer.DrawArea = function (x, y, width, height, color) {
                var context = Renderer.context;
                context.strokeStyle = color.Value;
                context.strokeRect(x, y, width, height);
            };
            Renderer.FillArea = function (x, y, width, height, color) {
                var context = Renderer.context;
                context.fillStyle = color.Value;
                context.fillRect(x, y, width, height);
            };
            Renderer.DrawRectangle = function (rectangle, color, lineWidth) {
                if (lineWidth === void 0) { lineWidth = 1; }
                var context = Renderer.context;
                context.lineWidth = lineWidth;
                context.strokeStyle = color.Value;
                context.strokeRect(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height);
            };
            Renderer.FillRectangle = function (rectangle, color) {
                var context = Renderer.context;
                context.fillStyle = color.Value;
                context.fillRect(rectangle.X, rectangle.Y, rectangle.Width, rectangle.Height);
            };
            Renderer.FillEllipseGradient = function (centerX, centerY, radiusX, radiusY, color1, color2, point1, point2) {
                var context = Renderer.context;
                context.save(); // save state
                context.beginPath();
                context.translate(centerX - radiusX, centerY - radiusY);
                context.scale(radiusX, radiusY);
                context.arc(1, 1, 1, 0, Renderer.TwoPi, false);
                context.restore(); // restore to original state
                var gradient = context.createLinearGradient(point1.x, point1.y, point2.x, point2.y);
                gradient.addColorStop(0, color1.Value);
                gradient.addColorStop(1, color2.Value);
                context.fillStyle = gradient;
                context.fill();
            };
            Renderer.FillEllipseGradientXY = function (centerX, centerY, radiusX, radiusY, color1, color2, x1, y1, x2, y2) {
                var context = Renderer.context;
                context.save(); // save state
                context.beginPath();
                context.translate(centerX - radiusX, centerY - radiusY);
                context.scale(radiusX, radiusY);
                context.arc(1, 1, 1, 0, Renderer.TwoPi, false);
                context.restore(); // restore to original state
                //var gradient = context.createLinearGradient(x1, y1, x2, y2);
                var gradient = context.createRadialGradient(x1, y1, radiusX, x2, y2, radiusY);
                gradient.addColorStop(0, color1.Value);
                gradient.addColorStop(1, color2.Value);
                context.fillStyle = gradient;
                context.fill();
            };
            Renderer.DrawCircle = function (centerX, centerY, radius, lineWidth, color, otherContext) {
                if (otherContext === void 0) { otherContext = null; }
                var context = (otherContext == null) ? Renderer.context : otherContext;
                context.beginPath();
                context.arc(centerX, centerY, radius, 0, Renderer.TwoPi, false);
                context.strokeStyle = color.Value;
                context.closePath();
                context.lineWidth = lineWidth;
                context.stroke();
            };
            Renderer.FillCircle = function (centerX, centerY, radius, color, otherContext) {
                if (otherContext === void 0) { otherContext = null; }
                var context = (otherContext == null) ? Renderer.context : otherContext;
                context.beginPath();
                context.arc(centerX, centerY, radius, 0, Renderer.TwoPi, false);
                context.fillStyle = color.Value;
                context.closePath();
                context.fill();
            };
            Renderer.DrawStar = function (centerX, centerY, innerRadius, outerRadius, lineWidth, color, angle) {
                var points = [];
                var innerAngle = angle + 180;
                points.push(Renderer.PointOnCircle(centerX, centerY, outerRadius, angle));
                points.push(Renderer.PointOnCircle(centerX, centerY, innerRadius, innerAngle + 216));
                points.push(Renderer.PointOnCircle(centerX, centerY, outerRadius, angle + 72));
                points.push(Renderer.PointOnCircle(centerX, centerY, innerRadius, innerAngle + 288));
                points.push(Renderer.PointOnCircle(centerX, centerY, outerRadius, angle + 144));
                points.push(Renderer.PointOnCircle(centerX, centerY, innerRadius, innerAngle));
                points.push(Renderer.PointOnCircle(centerX, centerY, outerRadius, angle + 216));
                points.push(Renderer.PointOnCircle(centerX, centerY, innerRadius, innerAngle + 72));
                points.push(Renderer.PointOnCircle(centerX, centerY, outerRadius, angle + 288));
                points.push(Renderer.PointOnCircle(centerX, centerY, innerRadius, innerAngle + 144));
                Renderer.DrawPolygon(points, color, lineWidth);
            };
            Renderer.FillTriangleInCircle = function (centerX, centerY, radius, color, angle) {
                var points = [];
                points.push(Renderer.PointOnCircle(centerX, centerY, radius, angle));
                points.push(Renderer.PointOnCircle(centerX, centerY, radius, angle + 120));
                points.push(Renderer.PointOnCircle(centerX, centerY, radius, angle + 240));
                this.FillPolygon(points, color);
            };
            Renderer.DrawTriangleInCircle = function (centerX, centerY, radius, lineWidth, color, angle) {
                var point1 = Renderer.PointOnCircle(centerX, centerY, radius, angle);
                var point2 = Renderer.PointOnCircle(centerX, centerY, radius, angle + 120);
                var point3 = Renderer.PointOnCircle(centerX, centerY, radius, angle + 240);
                this.DrawLine(point1.x, point1.y, point2.x, point2.y, lineWidth, color);
                this.DrawLine(point2.x, point2.y, point3.x, point3.y, lineWidth, color);
                this.DrawLine(point3.x, point3.y, point1.x, point1.y, lineWidth, color);
            };
            Renderer.DrawTriangleMine = function (centerX, centerY, circleRadius, spikeRadius, spikeAngle, lineWidth, color, angle) {
                var trianglePoint1 = Renderer.PointOnCircle(centerX, centerY, spikeRadius, angle);
                var trianglePoint2 = Renderer.PointOnCircle(centerX, centerY, spikeRadius, angle + 120);
                var trianglePoint3 = Renderer.PointOnCircle(centerX, centerY, spikeRadius, angle + 240);
                var points = [];
                points.push(trianglePoint1);
                var nrOfPointsInSegment = 20;
                var startAngle = angle + spikeAngle * .5;
                var anglePerSegment = ((120 - spikeAngle) / nrOfPointsInSegment);
                for (var iPoint = 0; iPoint <= nrOfPointsInSegment; iPoint++) {
                    var pointAngle = startAngle + anglePerSegment * iPoint;
                    var circlePoint = Renderer.PointOnCircle(centerX, centerY, circleRadius, pointAngle);
                    points.push(circlePoint);
                }
                points.push(trianglePoint2);
                startAngle = angle + 120 + spikeAngle * .5;
                for (iPoint = 0; iPoint <= nrOfPointsInSegment; iPoint++) {
                    pointAngle = startAngle + anglePerSegment * iPoint;
                    circlePoint = Renderer.PointOnCircle(centerX, centerY, circleRadius, pointAngle);
                    points.push(circlePoint);
                }
                points.push(trianglePoint3);
                startAngle = angle + 240 + spikeAngle * .5;
                for (iPoint = 0; iPoint <= nrOfPointsInSegment; iPoint++) {
                    pointAngle = startAngle + anglePerSegment * iPoint;
                    circlePoint = Renderer.PointOnCircle(centerX, centerY, circleRadius, pointAngle);
                    points.push(circlePoint);
                }
                Renderer.DrawPolygon(points, color, lineWidth);
            };
            Renderer.DrawRoundedRectangle = function (x, y, width, height, radius, lineWidth, fill, stroke, fillColor, strokeColor) {
                var context = Renderer.context;
                context.fillStyle = fillColor.Value;
                context.strokeStyle = strokeColor.Value;
                context.beginPath();
                context.moveTo(x + radius, y);
                context.lineTo(x + width - radius, y);
                context.quadraticCurveTo(x + width, y, x + width, y + radius);
                context.lineTo(x + width, y + height - radius);
                context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
                context.lineTo(x + radius, y + height);
                context.quadraticCurveTo(x, y + height, x, y + height - radius);
                context.lineTo(x, y + radius);
                context.quadraticCurveTo(x, y, x + radius, y);
                context.closePath();
                if (fill) {
                    context.fill();
                }
                if (stroke) {
                    context.lineWidth = lineWidth;
                    context.stroke();
                }
            };
            Renderer.FillRoundedRectangle = function (x, y, width, height, radius, fillColor) {
                var context = Renderer.context;
                context.fillStyle = fillColor.Value;
                context.beginPath();
                context.moveTo(x + radius, y);
                context.lineTo(x + width - radius, y);
                context.quadraticCurveTo(x + width, y, x + width, y + radius);
                context.lineTo(x + width, y + height - radius);
                context.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
                context.lineTo(x + radius, y + height);
                context.quadraticCurveTo(x, y + height, x, y + height - radius);
                context.lineTo(x, y + radius);
                context.quadraticCurveTo(x, y, x + radius, y);
                context.closePath();
                context.fill();
            };
            Renderer.PointInsidePolygon = function (point, polygonPoints) {
                for (var c = false, i = -1, l = polygonPoints.length, j = l - 1; ++i < l; j = i)
                    ((polygonPoints[i].y <= point.y && point.y < polygonPoints[j].y)
                        || (polygonPoints[j].y <= point.y && point.y < polygonPoints[i].y))
                        && (point.x < (polygonPoints[j].x - polygonPoints[i].x) * (point.y - polygonPoints[i].y) / (polygonPoints[j].y - polygonPoints[i].y) + polygonPoints[i].x) && (c = !c);
                return c;
            };
            Renderer.CircleCircumference = function (radius) {
                return radius * Renderer.TwoPi;
            };
            Renderer.ArcDistanceOfOneDegreeAngle = function (radius) {
                var circumference = Renderer.CircleCircumference(radius);
                return circumference / 360;
            };
            Renderer.PointOnCircle = function (centerX, centerY, radius, angle) {
                var alphaRadians = Renderer.ToRadians * angle;
                var pointX = centerX + (radius * Math.cos(alphaRadians));
                var pointY = centerY - (radius * Math.sin(alphaRadians));
                return new Web.Point(pointX, pointY);
            };
            Renderer.CircleSegmentPoints = function (centerX, centerY, radius, startAngle, endAngle) {
                if (endAngle < startAngle) {
                    endAngle += 360;
                    if (startAngle == endAngle) {
                        // Complete circle.
                        startAngle -= 360;
                    }
                }
                var alphaRadians;
                var pointX;
                var pointY;
                if (startAngle == endAngle) {
                    alphaRadians = Renderer.ToRadians * startAngle;
                    pointX = centerX + (radius * Math.cos(alphaRadians));
                    pointY = centerY - (radius * Math.sin(alphaRadians));
                    return [new Web.Point(pointX, pointY)];
                }
                var arcAngleSpan = endAngle - startAngle;
                var nrOfSegments = Math.max(3, (Math.max(32, (radius * .666)) * (arcAngleSpan / 360)));
                var alphaStep = arcAngleSpan / nrOfSegments;
                var alpha = startAngle;
                var points = [];
                while (alpha < endAngle) {
                    alphaRadians = Renderer.ToRadians * alpha;
                    pointX = centerX + (radius * Math.cos(alphaRadians));
                    pointY = centerY - (radius * Math.sin(alphaRadians));
                    points.push(new Web.Point(pointX, pointY));
                    alpha += alphaStep;
                }
                alphaRadians = Renderer.ToRadians * endAngle;
                pointX = centerX + (radius * Math.cos(alphaRadians));
                pointY = centerY - (radius * Math.sin(alphaRadians));
                points.push(new Web.Point(pointX, pointY));
                return points;
            };
            Renderer.DrawPolygon = function (points, color, lineWidth) {
                if (points.length > 2) {
                    var context = Renderer.context;
                    context.fillStyle = color.Value;
                    context.beginPath();
                    var firstPoint = points[0];
                    context.moveTo(firstPoint.x, firstPoint.y);
                    for (var iPoint = 1; iPoint < points.length; iPoint++) {
                        var point = points[iPoint];
                        context.lineTo(point.x, point.y);
                    }
                    context.closePath();
                    context.lineWidth = lineWidth;
                    context.strokeStyle = color.Value;
                    context.stroke();
                }
            };
            Renderer.FillPolygon = function (points, color) {
                if (points.length > 2) {
                    var context = Renderer.context;
                    context.fillStyle = color.Value;
                    context.beginPath();
                    var firstPoint = points[0];
                    context.moveTo(firstPoint.x, firstPoint.y);
                    for (var iPoint = 1; iPoint < points.length; iPoint++) {
                        var point = points[iPoint];
                        context.lineTo(point.x, point.y);
                    }
                    context.closePath();
                    context.fill();
                }
            };
            Renderer.FillTriangle = function (point1, point2, point3, color) {
                var context = Renderer.context;
                context.fillStyle = color.Value;
                context.beginPath();
                context.moveTo(point1.x, point1.y);
                context.lineTo(point2.x, point2.y);
                context.lineTo(point3.x, point3.y);
                context.closePath();
                context.fill();
            };
            Renderer.FillTriangleByXY = function (point1X, point1Y, point2X, point2Y, point3X, point3Y, color) {
                var context = Renderer.context;
                context.fillStyle = color.Value;
                context.beginPath();
                context.moveTo(point1X, point1Y);
                context.lineTo(point2X, point2Y);
                context.lineTo(point3X, point3Y);
                context.closePath();
                context.fill();
            };
            Renderer.GetNewCanvasAndContext = function (width, height) {
                var canvas = document.createElement("canvas");
                canvas.width = width;
                canvas.height = height;
                var context = canvas.getContext("2d");
                return { canvas: canvas, context: context };
            };
            Renderer.DrawCanvas = function (canvas, x, y) {
                Renderer.context.drawImage(canvas, x, y);
            };
            Renderer.DrawImage = function (image, x, y) {
                Renderer.context.drawImage(image, x, y);
            };
            Renderer.DrawImageToSize = function (image, x, y, targetWidth, targetHeight, alpha) {
                x = Math.round(x);
                y = Math.round(y);
                targetWidth = Math.round(targetWidth);
                targetHeight = Math.round(targetHeight);
                var context = Renderer.context;
                var saveAlpha = context.globalAlpha;
                context.globalAlpha = alpha;
                context.drawImage(image, x, y, targetWidth, targetHeight);
                context.globalAlpha = saveAlpha;
            };
            Renderer.AngleToPositionCW = function (angle, radius, centerX, centerY) {
                var angleRadians = Renderer.ToRadians * angle;
                return new Web.Point((centerX + radius * Math.cos(angleRadians)), (centerY + radius * Math.sin(angleRadians)));
            };
            Renderer.DrawCurveThroughPoints = function (points, color, lineWidth, isClosed, tension) {
                if (lineWidth === void 0) { lineWidth = 1; }
                if (isClosed === void 0) { isClosed = false; }
                if (tension === void 0) { tension = .5; }
                var context = Renderer.context;
                context.beginPath();
                var numOfSegments = 16;
                var clonePoints = [];
                var result = [];
                var x;
                var y;
                var cardinal1;
                var cardinal2;
                var cardinal3;
                var cardinal4;
                // clone array so we don't change the original
                clonePoints = points.slice(0);
                if (isClosed) {
                    clonePoints.unshift(points[points.length - 1]);
                    clonePoints.unshift(points[points.length - 1]);
                    clonePoints.push(points[0]);
                }
                else {
                    clonePoints.unshift(points[0]);
                    clonePoints.push(points[points.length - 1]);
                }
                for (var i = 1; i < (clonePoints.length - 2); i++) {
                    var currPoint = clonePoints[i];
                    var prevPoint = clonePoints[i - 1];
                    var nextPoint = clonePoints[i + 1];
                    var nextNextPoint = clonePoints[i + 2];
                    for (var t = 0; t <= numOfSegments; t++) {
                        // calc tension vectors
                        var t1x = (nextPoint.x - prevPoint.x) * tension;
                        var t1y = (nextPoint.y - prevPoint.y) * tension;
                        var t2x = (nextNextPoint.x - currPoint.x) * tension;
                        var t2y = (nextNextPoint.y - currPoint.y) * tension;
                        // calc step
                        var step = t / numOfSegments;
                        var step2 = Math.pow(step, 2);
                        var step3 = Math.pow(step, 3);
                        // calc cardinals
                        cardinal1 = 2 * step3 - 3 * step2 + 1;
                        cardinal2 = -(2 * step3) + 3 * step2;
                        cardinal3 = step3 - 2 * step2 + step;
                        cardinal4 = step3 - step2;
                        // calc x and y coords with common control vectors
                        x = cardinal1 * currPoint.x + cardinal2 * nextPoint.x + cardinal3 * t1x + cardinal4 * t2x;
                        y = cardinal1 * currPoint.y + cardinal2 * nextPoint.y + cardinal3 * t1y + cardinal4 * t2y;
                        //store points in array
                        result.push(new Web.Point(x, y));
                    }
                }
                Renderer.DrawLines(result, color, lineWidth);
            };
            Renderer.DrawBezier = function (start, controlPoint1, controlPoint2, end, nrOfPoints, color, lineWidth) {
                if (lineWidth === void 0) { lineWidth = 1; }
                var points = Renderer.BezierPoints(start, controlPoint1, controlPoint2, end, nrOfPoints);
                Renderer.DrawLines(points, color, lineWidth);
            };
            Renderer.BezierPoints = function (a, b, c, d, nrOfPoints) {
                var points = [];
                var divider = nrOfPoints - 1;
                for (var iPoint = 0; iPoint < nrOfPoints; iPoint++) {
                    var step = iPoint / divider;
                    points.push(this.PointOnBezierCurve(a, b, c, d, step));
                }
                return points;
            };
            Renderer.PointOnBezierCurve = function (a, b, c, d, step) {
                var ab = this.LinearInterpolation(a, b, step);
                var bc = this.LinearInterpolation(b, c, step);
                var cd = this.LinearInterpolation(c, d, step);
                var abbc = this.LinearInterpolation(ab, bc, step);
                var bccd = this.LinearInterpolation(bc, cd, step);
                return this.LinearInterpolation(abbc, bccd, step);
            };
            Renderer.LinearInterpolation = function (p1, p2, step) {
                return new Web.Point(p1.x + (p2.x - p1.x) * step, p1.y + (p2.y - p1.y) * step);
            };
            Renderer.Interpolate = function (n1, n2, percent) {
                var otherPercent = 1 - percent;
                return n1 * percent + n2 * otherPercent;
            };
            Renderer.InterpolateXFastSlow = function (x1, x2, percent) {
                var pointIndex = Math.round(percent * 1000);
                if (pointIndex >= 0 && pointIndex <= 1000) {
                    var point = Renderer.fastSlowPoints[pointIndex];
                    return Renderer.Interpolate(x1, x2, point.y * .01);
                }
                return x2;
            };
            Object.defineProperty(Renderer, "AverageFrameRateOk", {
                get: function () {
                    return Renderer.AverageFrameRate > Renderer.DesiredMinimumFrameRate;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Renderer, "LastFrameRateOk", {
                get: function () {
                    return (this.frameRates.Count < Renderer.trackLastNFrames || Renderer.LastFrameRate > Renderer.DesiredMinimumFrameRate);
                },
                enumerable: true,
                configurable: true
            });
            Renderer.CheckFrameRate = function () {
                var now = Date.now();
                var renderDelta = now - Renderer.lastRender;
                Renderer.RenderDelta = renderDelta;
                Renderer.lastRender = now;
                Renderer.LastFrameRate = Math.round(1000 / renderDelta);
                if (this.frameRates.Count == Renderer.trackLastNFrames) {
                    var oldestFrameRate = this.frameRates.Pop();
                    this.frameRates.Push(renderDelta);
                    Renderer.totalFrameRate += renderDelta - oldestFrameRate;
                    Renderer.AverageFrameRate = Math.round(1000 / (Renderer.totalFrameRate / Renderer.trackLastNFrames));
                    if (Renderer.AverageFrameRate < Renderer.DesiredMinimumFrameRate) {
                        // Set some objects to invisible when performance is weak.
                        if (Renderer.SetLeastRequiredRenderedObjectVisibility(false)) {
                            // Clear the current last 'trackLastNFrames' frames and restart calculation to get a more accurate measure of the new situation
                            Renderer.frameRates.Clear();
                            Renderer.totalFrameRate = 0;
                        }
                    }
                    else if (Renderer.AverageFrameRate > Renderer.MoreThanEnoughGoodFrameRate) {
                        // Set more objects to visible when performance is very good.
                        if (Renderer.SetLeastRequiredRenderedObjectVisibility(true)) {
                            // Clear the current last 'trackLastNFrames' frames and restart calculation to get a more accurate measure of the new situation
                            Renderer.frameRates.Clear();
                            Renderer.totalFrameRate = 0;
                        }
                    }
                }
                else {
                    var nrOfFrames = this.frameRates.Push(renderDelta);
                    Renderer.totalFrameRate += renderDelta;
                    Renderer.AverageFrameRate = Math.round(1000 / (Renderer.totalFrameRate / nrOfFrames));
                }
            };
            Renderer.SetLeastRequiredRenderedObjectVisibility = function (setVisible) {
                var found = Renderer.SetOneLessRequiredObjectInvisible(Web.Requirement.Optional, setVisible);
                if (!found) {
                    return Renderer.SetOneLessRequiredObjectInvisible(Web.Requirement.NiceToHave, setVisible);
                }
                return found;
            };
            Renderer.SetOneLessRequiredObjectInvisible = function (requirement, setVisible) {
                var numberKeys = Web.EnumHelper.GetValues(Web.GraphDocking);
                for (var iNumber = numberKeys.length - 1; iNumber >= 0; iNumber--) {
                    var dock = numberKeys[iNumber];
                    var dockSide = Renderer.drawingDictionary.ValueOf(dock);
                    for (var iStack = 0; iStack < dockSide.DockStacks.length; iStack++) {
                        var dockStack = dockSide.DockStacks[iStack];
                        for (var iLayer = 0; iLayer < dockStack.DockLayers.length; iLayer++) {
                            var dockLayer = dockStack.DockLayers[iLayer];
                            for (var iDrawing = 0; iDrawing < dockLayer.AutoDrawings.length; iDrawing++) {
                                var autoDrawing = dockLayer.AutoDrawings[iDrawing];
                                if (autoDrawing.Visible != setVisible && autoDrawing.Requirement == requirement) {
                                    autoDrawing.Visible = setVisible;
                                    if (autoDrawing.RequiredReplacement != null) {
                                        autoDrawing.RequiredReplacement.Visible = !setVisible;
                                    }
                                    return true;
                                }
                            }
                        }
                    }
                }
                return false;
            };
            Renderer.Render = function () {
                Renderer.context.fillStyle = Renderer.BackgroundColor.Value;
                Renderer.context.fillRect(0, 0, Renderer.width, Renderer.height);
                Renderer.CheckFrameRate();
                Renderer.MeasureDrawingDictionary();
                Renderer.RenderDrawingDictionary();
                if (Renderer.MouseEvent != null) {
                    Renderer.RenderHitTesting();
                    Renderer.mouseClicked = false;
                }
                Renderer.ThemeManager.PerformThemeTransition();
                Renderer.window.requestAnimationFrame(Renderer.Render);
            };
            Renderer.RenderHitTesting = function () {
                // TODO: First hit test captured autoDrawing
                var numberKeys = Web.EnumHelper.GetValues(Web.GraphDocking);
                for (var iNumber = numberKeys.length - 1; iNumber >= 0; iNumber--) {
                    var dock = numberKeys[iNumber];
                    if (Renderer.RenderHitTest(dock)) {
                        return true;
                    }
                }
                return false;
            };
            Renderer.RenderHitTest = function (graphDock) {
                var dockSide = Renderer.drawingDictionary.ValueOf(graphDock);
                for (var iStack = 0; iStack < dockSide.DockStacks.length; iStack++) {
                    var dockStack = dockSide.DockStacks[iStack];
                    var dockStackDimensions = dockStack.Dimensions;
                    var width = dockStackDimensions.Width;
                    var height = dockStackDimensions.Height;
                    Renderer.SetRenderTarget(dockStackDimensions);
                    // Test in reverse order of rendering.
                    for (var iLayer = dockStack.DockLayers.length - 1; iLayer >= 0; iLayer--) {
                        var dockLayer = dockStack.DockLayers[iLayer];
                        for (var iDrawing = 0; iDrawing < dockLayer.AutoDrawings.length; iDrawing++) {
                            var autoDrawing = dockLayer.AutoDrawings[iDrawing];
                            if (autoDrawing.Visible) {
                                if (autoDrawing.HitTest(width, height, Renderer.mouseEvent)) {
                                    Renderer.EndDraw();
                                    return true;
                                }
                            }
                        }
                    }
                    Renderer.EndDraw();
                }
                return false;
            };
            Renderer.RenderDrawingDictionary = function () {
                Renderer.RenderBackgroundOrOverlay(Web.GraphDocking.Background);
                for (var iDock = 0; iDock < Renderer.dockingSideRenderingOrder.length; iDock++) {
                    var graphDocking = Renderer.dockingSideRenderingOrder[iDock];
                    switch (graphDocking) {
                        case Web.GraphDocking.Top:
                        case Web.GraphDocking.Bottom:
                        case Web.GraphDocking.Left:
                        case Web.GraphDocking.Right:
                            Renderer.RenderSideDockings(graphDocking);
                            break;
                    }
                }
                Renderer.RenderCenterDockings();
                Renderer.RenderBackgroundOrOverlay(Web.GraphDocking.Overlay);
            };
            Renderer.RenderBackgroundOrOverlay = function (graphDock) {
                if (graphDock == Web.GraphDocking.Background || graphDock == Web.GraphDocking.Overlay) {
                    var dockSide = Renderer.drawingDictionary.ValueOf(graphDock);
                    for (var iStack = 0; iStack < dockSide.DockStacks.length; iStack++) {
                        var dockStack = dockSide.DockStacks[iStack];
                        var width = dockStack.Dimensions.Width;
                        var height = dockStack.Dimensions.Height;
                        for (var iLayer = 0; iLayer < dockStack.DockLayers.length; iLayer++) {
                            var dockLayer = dockStack.DockLayers[iLayer];
                            for (var iDrawing = 0; iDrawing < dockLayer.AutoDrawings.length; iDrawing++) {
                                var autoDrawing = dockLayer.AutoDrawings[iDrawing];
                                if (autoDrawing.Visible) {
                                    autoDrawing.Render(width, height);
                                }
                            }
                        }
                    }
                }
            };
            Renderer.RenderSideDockings = function (graphDock) {
                var dockSide = Renderer.drawingDictionary.ValueOf(graphDock);
                for (var iStack = 0; iStack < dockSide.DockStacks.length; iStack++) {
                    var dockStack = dockSide.DockStacks[iStack];
                    var dockStackDimensions = dockStack.Dimensions;
                    var renderTargetWidth = dockStackDimensions.Width;
                    var renderTargetHeight = dockStackDimensions.Height;
                    if (renderTargetWidth >= 1 && renderTargetHeight >= 1) {
                        var renderedSomething = false;
                        // Begin Draw
                        Renderer.SetRenderTarget(dockStackDimensions);
                        // Render Layers.
                        for (var iLayer = 0; iLayer < dockStack.DockLayers.length; iLayer++) {
                            var dockLayer = dockStack.DockLayers[iLayer];
                            for (var iDrawing = 0; iDrawing < dockLayer.AutoDrawings.length; iDrawing++) {
                                var autoDrawing = dockLayer.AutoDrawings[iDrawing];
                                if (autoDrawing.Visible) {
                                    autoDrawing.Render(renderTargetWidth, renderTargetHeight);
                                    renderedSomething = true;
                                }
                            }
                        }
                        Renderer.EndDraw();
                        // Render the stacks to the main RenderTarget
                        if (renderedSomething) {
                            // Render layer 'bitmap' on dockstack
                        }
                    }
                }
            };
            Renderer.RenderCenterDockings = function () {
                for (var iDock = 0; iDock < Renderer.dockingCenterRenderingOrder.length; iDock++) {
                    var graphDocking = Renderer.dockingCenterRenderingOrder[iDock];
                    Renderer.RenderCenterDockingDock(graphDocking);
                }
            };
            Renderer.RenderCenterDockingDock = function (graphDock) {
                var dockSide = Renderer.drawingDictionary.ValueOf(graphDock);
                for (var iStack = 0; iStack < dockSide.DockStacks.length; iStack++) {
                    var dockStack = dockSide.DockStacks[iStack];
                    var dockStackDimensions = dockStack.Dimensions;
                    var renderTargetWidth = dockStackDimensions.Width;
                    var renderTargetHeight = dockStackDimensions.Height;
                    if (renderTargetWidth >= 1 && renderTargetHeight >= 1) {
                        var renderedSomething = false;
                        // Begin draw
                        Renderer.SetRenderTarget(dockStackDimensions);
                        // Render Layers.
                        for (var iLayer = 0; iLayer < dockStack.DockLayers.length; iLayer++) {
                            var dockLayer = dockStack.DockLayers[iLayer];
                            for (var iDrawing = 0; iDrawing < dockLayer.AutoDrawings.length; iDrawing++) {
                                var autoDrawing = dockLayer.AutoDrawings[iDrawing];
                                if (autoDrawing.Visible) {
                                    autoDrawing.Render(renderTargetWidth, renderTargetHeight);
                                    renderedSomething = true;
                                }
                            }
                        }
                        // End draw
                        Renderer.EndDraw();
                        if (renderedSomething) {
                            // Render the stacks to the main RenderTarget
                        }
                    }
                }
            };
            Renderer.MeasureDrawingDictionary = function () {
                Renderer.topDockHeight = 0;
                Renderer.leftDockWidth = 0;
                Renderer.rightDockWidth = 0;
                Renderer.bottomDockHeight = 0;
                Renderer.MeasureBackgroundOrOverlay(Web.GraphDocking.Background);
                for (var iDock = 0; iDock < Renderer.dockingSideRenderingOrder.length; iDock++) {
                    var graphDocking = Renderer.dockingSideRenderingOrder[iDock];
                    switch (graphDocking) {
                        case Web.GraphDocking.Top:
                            Renderer.MeasureTopBottomDockings(Web.GraphDocking.Top);
                            break;
                        case Web.GraphDocking.Bottom:
                            Renderer.MeasureTopBottomDockings(Web.GraphDocking.Bottom);
                            break;
                        case Web.GraphDocking.Left:
                            Renderer.MeasureSideDockings(Web.GraphDocking.Left);
                            break;
                        case Web.GraphDocking.Right:
                            Renderer.MeasureSideDockings(Web.GraphDocking.Right);
                            break;
                    }
                }
                Renderer.MeasureCenterDockings();
                Renderer.MeasureAdjustAlignedToCenter();
                Renderer.MeasureBackgroundOrOverlay(Web.GraphDocking.Overlay);
            };
            Renderer.MeasureBackgroundOrOverlay = function (graphDock) {
                if (graphDock == Web.GraphDocking.Background || graphDock == Web.GraphDocking.Overlay) {
                    var dockSide = Renderer.drawingDictionary.ValueOf(graphDock);
                    if (dockSide != null) {
                        var dimensions = dockSide.Dimensions;
                        dimensions.X = 0;
                        dimensions.Y = 0;
                        dimensions.Width = Renderer.width;
                        dimensions.Height = Renderer.height;
                        for (var iStack = 0; iStack < dockSide.DockStacks.length; iStack++) {
                            var dockStack = dockSide.DockStacks[iStack];
                            var dockStackDimensions = dockStack.Dimensions;
                            dockStackDimensions.X = 0;
                            dockStackDimensions.Y = 0;
                            dockStackDimensions.Width = Renderer.width;
                            dockStackDimensions.Height = Renderer.height;
                        }
                    }
                }
            };
            Renderer.MeasureTopBottomDockings = function (graphDock) {
                if (graphDock == Web.GraphDocking.Top || graphDock == Web.GraphDocking.Bottom) {
                    var dockSide = Renderer.drawingDictionary.ValueOf(graphDock);
                    if (dockSide != null) {
                        if (dockSide.DockStacks.length > 0) {
                            var totalWidth = Renderer.width - Renderer.leftDockWidth - Renderer.rightDockWidth;
                            for (var iStack = 0; iStack < dockSide.DockStacks.length; iStack++) {
                                var dockStack = dockSide.DockStacks[iStack];
                                var dockHeight = Renderer.MeasureDockStack(dockStack, graphDock);
                                var dimensions = dockStack.Dimensions;
                                dimensions.X = Renderer.leftDockWidth;
                                dimensions.Y = (graphDock == Web.GraphDocking.Top) ? Renderer.topDockHeight : Renderer.height - Renderer.bottomDockHeight - dockHeight;
                                dimensions.Width = totalWidth;
                                dimensions.Height = dockHeight;
                                if (graphDock == Web.GraphDocking.Top) {
                                    Renderer.topDockHeight += dockHeight;
                                }
                                else {
                                    Renderer.bottomDockHeight += dockHeight;
                                }
                            }
                            dimensions = dockSide.Dimensions;
                            dimensions.X = Renderer.leftDockWidth;
                            dimensions.Y = (graphDock == Web.GraphDocking.Top) ? 0 : Renderer.height - Renderer.bottomDockHeight;
                            dimensions.Width = totalWidth;
                            dimensions.Height = (graphDock == Web.GraphDocking.Top) ? Renderer.topDockHeight : Renderer.bottomDockHeight;
                        }
                        else {
                            dockSide.Dimensions.X = 0;
                            dockSide.Dimensions.Y = 0;
                            dockSide.Dimensions.Width = 0;
                            dockSide.Dimensions.Height = 0;
                        }
                    }
                }
            };
            Renderer.MeasureDockStack = function (dockStack, graphDock) {
                var topBottomWidth = Renderer.width - Renderer.leftDockWidth - Renderer.rightDockWidth;
                var leftRightHeight = Renderer.height - Renderer.topDockHeight - Renderer.bottomDockHeight;
                var otherSize = (graphDock == Web.GraphDocking.Bottom || graphDock == Web.GraphDocking.Top) ? topBottomWidth : leftRightHeight;
                var dockSize = 0;
                for (var iLayer = 0; iLayer < dockStack.DockLayers.length; iLayer++) {
                    var dockLayer = dockStack.DockLayers[iLayer];
                    var layerSize = 0;
                    for (var iDrawing = 0; iDrawing < dockLayer.AutoDrawings.length; iDrawing++) {
                        var autoDrawing = dockLayer.AutoDrawings[iDrawing];
                        if (autoDrawing.Visible) {
                            layerSize = Math.max(layerSize, autoDrawing.MeasureDock(otherSize));
                        }
                    }
                    if (graphDock == Web.GraphDocking.Top || graphDock == Web.GraphDocking.Bottom) {
                        var layerTopBottomDimensions = dockLayer.Dimensions;
                        layerTopBottomDimensions.Y = (graphDock == Web.GraphDocking.Top) ? Renderer.topDockHeight : Renderer.height - Renderer.topDockHeight - layerSize;
                        layerTopBottomDimensions.Width = topBottomWidth;
                        layerTopBottomDimensions.Height = layerSize;
                    }
                    else if (graphDock == Web.GraphDocking.Left || graphDock == Web.GraphDocking.Right) {
                        var layerLeftRightDimensions = dockLayer.Dimensions;
                        layerLeftRightDimensions.X = (graphDock == Web.GraphDocking.Left) ? Renderer.leftDockWidth : Renderer.width - Renderer.rightDockWidth - layerSize;
                        layerLeftRightDimensions.Width = layerSize;
                        layerLeftRightDimensions.Height = leftRightHeight;
                    }
                    dockSize = Math.max(dockSize, layerSize);
                }
                if (graphDock == Web.GraphDocking.Top || graphDock == Web.GraphDocking.Bottom) {
                    var topBottomDimensions = dockStack.Dimensions;
                    if (topBottomWidth > 0 && dockSize > 0) {
                        topBottomDimensions.Y = (graphDock == Web.GraphDocking.Top) ? 0 : Renderer.height - dockSize;
                        topBottomDimensions.Width = topBottomWidth;
                        topBottomDimensions.Height = dockSize;
                    }
                    else {
                        topBottomDimensions.Width = 0;
                        topBottomDimensions.Height = 0;
                    }
                }
                else if (graphDock == Web.GraphDocking.Left || graphDock == Web.GraphDocking.Right) {
                    var leftRightDimensions = dockStack.Dimensions;
                    if (dockSize > 0 && leftRightHeight > 0) {
                        leftRightDimensions.X = (graphDock == Web.GraphDocking.Left) ? 0 : Renderer.width - dockSize;
                        leftRightDimensions.Width = dockSize;
                        leftRightDimensions.Height = leftRightHeight;
                    }
                    else {
                        leftRightDimensions.Width = 0;
                        leftRightDimensions.Height = 0;
                    }
                }
                return dockSize;
            };
            Renderer.MeasureSideDockings = function (graphDock) {
                if (graphDock == Web.GraphDocking.Left || graphDock == Web.GraphDocking.Right) {
                    var dockSide = Renderer.drawingDictionary.ValueOf(graphDock);
                    if (dockSide != null) {
                        var dockSideDimensions = dockSide.Dimensions;
                        if (dockSide.DockStacks.length > 0) {
                            var totalHeight = Renderer.height - Renderer.bottomDockHeight - Renderer.topDockHeight;
                            for (var iStack = 0; iStack < dockSide.DockStacks.length; iStack++) {
                                var dockStack = dockSide.DockStacks[iStack];
                                var dockWidth = Renderer.MeasureDockStack(dockStack, graphDock);
                                var dockStackDimensions = dockStack.Dimensions;
                                dockStackDimensions.X = (graphDock == Web.GraphDocking.Left) ? Renderer.leftDockWidth : Renderer.width - Renderer.rightDockWidth - dockWidth;
                                dockStackDimensions.Y = Renderer.topDockHeight;
                                dockStackDimensions.Width = dockWidth;
                                dockStackDimensions.Height = totalHeight;
                                if (graphDock == Web.GraphDocking.Left) {
                                    Renderer.leftDockWidth += dockWidth;
                                }
                                else {
                                    Renderer.rightDockWidth += dockWidth;
                                }
                            }
                            dockSideDimensions.X = (graphDock == Web.GraphDocking.Left) ? 0 : Renderer.width - Renderer.rightDockWidth;
                            dockSideDimensions.Y = Renderer.topDockHeight;
                            dockSideDimensions.Width = (graphDock == Web.GraphDocking.Left) ? Renderer.leftDockWidth : Renderer.rightDockWidth;
                            dockSideDimensions.Height = totalHeight;
                        }
                        else {
                            dockSideDimensions.X = 0;
                            dockSideDimensions.Y = 0;
                            dockSideDimensions.Width = 0;
                            dockSideDimensions.Height = 0;
                        }
                    }
                }
            };
            Renderer.MeasureCenterDockings = function () {
                var dockCenter = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.Center);
                var dimensions = dockCenter.Dimensions;
                var centerDimensions = dimensions;
                dimensions.X = Renderer.leftDockWidth;
                dimensions.Y = Renderer.topDockHeight;
                dimensions.Width = Renderer.width - Renderer.leftDockWidth - Renderer.rightDockWidth;
                dimensions.Height = Renderer.height - Renderer.bottomDockHeight - Renderer.topDockHeight;
                Renderer.SetDockStackDimensions(dockCenter);
                var dockTopLeft = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterTopLeft);
                dimensions = dockTopLeft.Dimensions;
                dimensions.X = Renderer.leftDockWidth;
                dimensions.Y = Renderer.topDockHeight;
                dimensions.Width = centerDimensions.Width * .5;
                dimensions.Height = centerDimensions.Height * .5;
                Renderer.SetDockStackDimensions(dockTopLeft);
                var dockTopRight = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterTopRight);
                dimensions = dockTopRight.Dimensions;
                dimensions.X = Renderer.leftDockWidth + dockTopLeft.Dimensions.Width;
                dimensions.Y = Renderer.topDockHeight;
                dimensions.Width = dockTopLeft.Dimensions.Width;
                dimensions.Height = dockTopLeft.Dimensions.Height;
                Renderer.SetDockStackDimensions(dockTopRight);
                var dockBottomLeft = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterBottomLeft);
                dimensions = dockBottomLeft.Dimensions;
                dimensions.X = Renderer.leftDockWidth;
                dimensions.Y = Renderer.topDockHeight + dockTopLeft.Dimensions.Height;
                dimensions.Width = dockTopLeft.Dimensions.Width;
                dimensions.Height = dockTopLeft.Dimensions.Height;
                Renderer.SetDockStackDimensions(dockBottomLeft);
                var dockBottomRight = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterBottomRight);
                dimensions = dockBottomRight.Dimensions;
                dimensions.X = dockTopRight.Dimensions.X;
                dimensions.Y = dockBottomLeft.Dimensions.Y;
                dimensions.Width = dockTopLeft.Dimensions.Width;
                dimensions.Height = dockTopLeft.Dimensions.Height;
                Renderer.SetDockStackDimensions(dockBottomRight);
                var dockTop = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterTop);
                dimensions = dockTop.Dimensions;
                dimensions.X = Renderer.leftDockWidth;
                dimensions.Y = Renderer.topDockHeight;
                dimensions.Width = centerDimensions.Width;
                dimensions.Height = dockTopLeft.Dimensions.Height;
                Renderer.SetDockStackDimensions(dockTop);
                var dockBottom = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterBottom);
                dimensions = dockBottom.Dimensions;
                dimensions.X = Renderer.leftDockWidth;
                dimensions.Y = dockBottomLeft.Dimensions.Y;
                dimensions.Width = centerDimensions.Width;
                dimensions.Height = dockTopLeft.Dimensions.Height;
                Renderer.SetDockStackDimensions(dockBottom);
                var dockLeft = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterLeft);
                dimensions = dockLeft.Dimensions;
                dimensions.X = Renderer.leftDockWidth;
                dimensions.Y = Renderer.topDockHeight;
                dimensions.Width = dockTopLeft.Dimensions.Width;
                dimensions.Height = centerDimensions.Height;
                Renderer.SetDockStackDimensions(dockLeft);
                var dockRight = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterRight);
                dimensions = dockRight.Dimensions;
                dimensions.X = dockTopRight.Dimensions.X;
                dimensions.Y = Renderer.topDockHeight;
                dimensions.Width = dockTopRight.Dimensions.Width;
                dimensions.Height = centerDimensions.Height;
                Renderer.SetDockStackDimensions(dockRight);
                var numpadWidth = centerDimensions.Width / 3;
                var numpadHeight = centerDimensions.Height / 3;
                var col1X = Renderer.leftDockWidth;
                var col2X = col1X + numpadWidth;
                var col3X = col2X + numpadWidth;
                var row1Y = Renderer.topDockHeight;
                var row2Y = row1Y + numpadHeight;
                var row3Y = row2Y + numpadHeight;
                var dockNumpad7 = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterNumpad7);
                dimensions = dockNumpad7.Dimensions;
                dimensions.X = col1X;
                dimensions.Y = row1Y;
                dimensions.Width = numpadWidth;
                dimensions.Height = numpadHeight;
                Renderer.SetDockStackDimensions(dockNumpad7);
                var dockNumpad8 = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterNumpad8);
                dimensions = dockNumpad8.Dimensions;
                dimensions.X = col2X;
                dimensions.Y = row1Y;
                dimensions.Width = numpadWidth;
                dimensions.Height = numpadHeight;
                Renderer.SetDockStackDimensions(dockNumpad8);
                var dockNumpad9 = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterNumpad9);
                dimensions = dockNumpad9.Dimensions;
                dimensions.X = col3X;
                dimensions.Y = row1Y;
                dimensions.Width = numpadWidth;
                dimensions.Height = numpadHeight;
                Renderer.SetDockStackDimensions(dockNumpad9);
                var dockNumpad4 = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterNumpad4);
                dimensions = dockNumpad4.Dimensions;
                dimensions.X = col1X;
                dimensions.Y = row2Y;
                dimensions.Width = numpadWidth;
                dimensions.Height = numpadHeight;
                Renderer.SetDockStackDimensions(dockNumpad4);
                var dockNumpad5 = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterNumpad5);
                dimensions = dockNumpad5.Dimensions;
                dimensions.X = col2X;
                dimensions.Y = row2Y;
                dimensions.Width = numpadWidth;
                dimensions.Height = numpadHeight;
                Renderer.SetDockStackDimensions(dockNumpad5);
                var dockNumpad6 = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterNumpad6);
                dimensions = dockNumpad6.Dimensions;
                dimensions.X = col3X;
                dimensions.Y = row2Y;
                dimensions.Width = numpadWidth;
                dimensions.Height = numpadHeight;
                Renderer.SetDockStackDimensions(dockNumpad6);
                var dockNumpad1 = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterNumpad1);
                dimensions = dockNumpad1.Dimensions;
                dimensions.X = col1X;
                dimensions.Y = row3Y;
                dimensions.Width = numpadWidth;
                dimensions.Height = numpadHeight;
                Renderer.SetDockStackDimensions(dockNumpad1);
                var dockNumpad2 = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterNumpad2);
                dimensions = dockNumpad2.Dimensions;
                dimensions.X = col2X;
                dimensions.Y = row3Y;
                dimensions.Width = numpadWidth;
                dimensions.Height = numpadHeight;
                Renderer.SetDockStackDimensions(dockNumpad2);
                var dockNumpad3 = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.CenterNumpad3);
                dimensions = dockNumpad3.Dimensions;
                dimensions.X = col3X;
                dimensions.Y = row3Y;
                dimensions.Width = numpadWidth;
                dimensions.Height = numpadHeight;
                Renderer.SetDockStackDimensions(dockNumpad3);
            };
            Renderer.SetDockStackDimensions = function (dockSide) {
                for (var iStack = 0; iStack < dockSide.DockStacks.length; iStack++) {
                    var dockStack = dockSide.DockStacks[iStack];
                    dockStack.Dimensions = dockSide.Dimensions.Clone();
                    for (var iLayer = 0; iLayer < dockStack.DockLayers.length; iLayer++) {
                        var dockLayer = dockStack.DockLayers[iLayer];
                        dockLayer.Dimensions = dockStack.Dimensions.Clone();
                    }
                }
            };
            Renderer.MeasureAdjustAlignedToCenter = function () {
                var dockCenter = Renderer.drawingDictionary.ValueOf(Web.GraphDocking.Center);
                var dockCenterDimensions = dockCenter.Dimensions;
                for (var iDock = 0; iDock < Renderer.dockingSideRenderingOrder.length; iDock++) {
                    var graphDocking = Renderer.dockingSideRenderingOrder[iDock];
                    if (Renderer.drawingDictionary.ContainsKey(graphDocking)) {
                        var dimensions;
                        if (graphDocking == Web.GraphDocking.Top || graphDocking == Web.GraphDocking.Bottom) {
                            var topBottomDock = Renderer.drawingDictionary.ValueOf(graphDocking);
                            for (var iStack = 0; iStack < topBottomDock.DockStacks.length; iStack++) {
                                var topBottomdockStack = topBottomDock.DockStacks[iStack];
                                if (topBottomdockStack.AlignedToCenter) {
                                    dimensions = topBottomdockStack.Dimensions;
                                    dimensions.X = dockCenterDimensions.X;
                                    dimensions.Width = dockCenterDimensions.Width;
                                }
                                var dockStackX = topBottomdockStack.Dimensions.X;
                                for (var iLayer = 0; iLayer < topBottomdockStack.DockLayers.length; iLayer++) {
                                    var topBottomDockLayer = topBottomdockStack.DockLayers[iLayer];
                                    dimensions = topBottomDockLayer.Dimensions;
                                    dimensions.X = dockStackX;
                                    dimensions.Width = dockCenterDimensions.Width;
                                }
                            }
                        }
                        if (graphDocking == Web.GraphDocking.Left || graphDocking == Web.GraphDocking.Right) {
                            var leftRightDock = Renderer.drawingDictionary.ValueOf(graphDocking);
                            for (var iLeftRight = 0; iLeftRight < leftRightDock.DockStacks.length; iLeftRight++) {
                                var leftRightDockStack = leftRightDock.DockStacks[iLeftRight];
                                if (leftRightDockStack.AlignedToCenter) {
                                    dimensions = leftRightDockStack.Dimensions;
                                    dimensions.Y = dockCenterDimensions.Y;
                                    dimensions.Height = dockCenterDimensions.Height;
                                }
                                var dockStackY = leftRightDockStack.Dimensions.Y;
                                for (var iLeftRightLayer = 0; iLeftRightLayer < leftRightDockStack.DockLayers.length; iLeftRightLayer++) {
                                    var leftRightDockLayer = leftRightDockStack.DockLayers[iLeftRightLayer];
                                    dimensions = leftRightDockLayer.Dimensions;
                                    dimensions.Y = dockStackY;
                                    dimensions.Height = dockCenterDimensions.Height;
                                }
                            }
                        }
                    }
                }
            };
            Renderer.TwoPi = Math.PI * 2;
            Renderer.ToRadians = Math.PI / 180.0;
            Renderer.ToDegrees = 180 / Math.PI;
            Renderer.colorBlack = new Web.Color(0, 0, 0, 1);
            Renderer.colorWhite = new Web.Color(255, 255, 255, 1);
            Renderer.highlightColor = new Web.Color(255, 255, 255, .4);
            Renderer.TopLayer = 100;
            Renderer.UpperLayer = 75;
            Renderer.MiddleLayer = 50;
            Renderer.LowerLayer = 25;
            Renderer.BottomLayer = 0;
            Renderer.RequestedMouseCursor = Web.MouseCursor.Crosshair;
            Renderer.KeyInfo = new Web.KeyInfo();
            Renderer.drawingDictionary = new Web.Dictionary();
            Renderer.dockingSideRenderingOrder = [Web.GraphDocking.Top, Web.GraphDocking.Left, Web.GraphDocking.Right, Web.GraphDocking.Bottom];
            Renderer.firstMouseDown = true;
            Renderer.mouseClickedTreshold = 500; // ms
            Renderer.swipingRight = false;
            Renderer.swipingLeft = false;
            Renderer.mouseX = 30;
            Renderer.mouseY = 30;
            Renderer.mouseClicked = false;
            Renderer.swipedLeft = false;
            Renderer.swipedRight = false;
            Renderer.fastSlowP1 = new Web.Point(0, 100);
            Renderer.fastSlowC1 = new Web.Point(0, 0);
            Renderer.fastSlowP2 = new Web.Point(100, 0);
            Renderer.fastSlowC2 = new Web.Point(100, 0);
            Renderer.fastSlowPoints = Renderer.BezierPoints(Renderer.fastSlowP1, Renderer.fastSlowC1, Renderer.fastSlowC2, Renderer.fastSlowP2, 1001);
            Renderer.lastRender = Date.now();
            Renderer.DesiredMinimumFrameRate = 24;
            Renderer.MoreThanEnoughGoodFrameRate = 48;
            Renderer.trackLastNFrames = 50;
            Renderer.totalFrameRate = 0;
            Renderer.frameRates = new Web.FifoQueue(Renderer.trackLastNFrames);
            Renderer.dockingCenterRenderingOrder = [
                Web.GraphDocking.CenterLeft, Web.GraphDocking.CenterRight, Web.GraphDocking.CenterTop, Web.GraphDocking.CenterBottom, Web.GraphDocking.CenterTopLeft, Web.GraphDocking.CenterTopRight, Web.GraphDocking.CenterBottomLeft, Web.GraphDocking.CenterBottomRight, Web.GraphDocking.CenterNumpad7, Web.GraphDocking.CenterNumpad8, Web.GraphDocking.CenterNumpad9, Web.GraphDocking.CenterNumpad4, Web.GraphDocking.CenterNumpad5, Web.GraphDocking.CenterNumpad6, Web.GraphDocking.CenterNumpad1, Web.GraphDocking.CenterNumpad2, Web.GraphDocking.CenterNumpad3, Web.GraphDocking.Center
            ];
            return Renderer;
        }());
        Web.Renderer = Renderer;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="enums.ts"/>
/// <reference path="Renderer.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Font = /** @class */ (function () {
            function Font(name, size, style, weight) {
                if (style === void 0) { style = Web.FontStyle.normal; }
                if (weight === void 0) { weight = Web.FontWeight.normal; }
                this.name = name;
                this.size = size;
                this.style = style;
                this.weight = weight;
                this.fontString = Web.Renderer.GetFontByNameStyleWeightSize(this.name, this.style, this.weight, this.size);
            }
            Object.defineProperty(Font, "DefaultFontString", {
                get: function () { return "Arial"; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Font, "DefaultFont", {
                get: function () { return new Font("Arial", 12); },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Font.prototype, "Name", {
                get: function () { return this.name; },
                set: function (value) {
                    this.name = value;
                    this.fontString = Web.Renderer.GetFontByNameStyleWeightSize(this.name, this.style, this.weight, this.size);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Font.prototype, "Style", {
                get: function () { return this.style; },
                set: function (value) {
                    this.style = value;
                    this.fontString = Web.Renderer.GetFontByNameStyleWeightSize(this.name, this.style, this.weight, this.size);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Font.prototype, "Weight", {
                get: function () { return this.weight; },
                set: function (value) {
                    this.weight = value;
                    this.fontString = Web.Renderer.GetFontByNameStyleWeightSize(this.name, this.style, this.weight, this.size);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Font.prototype, "Size", {
                get: function () { return this.size; },
                set: function (value) {
                    this.size = value;
                    this.fontString = Web.Renderer.GetFontByNameStyleWeightSize(this.name, this.style, this.weight, this.size);
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Font.prototype, "FontString", {
                get: function () { return this.fontString; },
                enumerable: true,
                configurable: true
            });
            Font.prototype.Clone = function () {
                return new Font(this.name, this.size, this.Style, this.weight);
            };
            return Font;
        }());
        Web.Font = Font;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
/// <reference path="AutoDrawingBase.ts"/>
/// <reference path="../Color.ts"/>
/// <reference path="../Font.ts"/>
/// <reference path="../enums.ts"/>
/// <reference path="../Interfaces/Func.ts"/>
// FUCK 
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Digit = /** @class */ (function () {
            function Digit() {
            }
            return Digit;
        }());
        var BinaryRain = /** @class */ (function (_super) {
            __extends(BinaryRain, _super);
            function BinaryRain(requirement, minSpeed, maxSpeed, nrOfDigits, minFontSize, maxFontSize, getFont, getColor) {
                var _this = _super.call(this, 0, requirement) || this;
                _this.fading = false;
                _this.active = false;
                _this.animatingDigits = new Web.List();
                _this.minSpeed = minSpeed;
                _this.maxSpeed = maxSpeed;
                _this.nrOfDigits = nrOfDigits;
                _this.minFontSize = minFontSize;
                _this.maxFontSize = maxFontSize;
                _this.getFont = getFont;
                _this.getColor = getColor;
                return _this;
            }
            Object.defineProperty(BinaryRain.prototype, "Active", {
                get: function () { return this.active; },
                set: function (value) {
                    if (value != this.active) {
                        this.active = value;
                        this.fading = true;
                        if (this.active) {
                            // Was inactive, is now active => fade in.
                            this.fadeAlpha = 0;
                            this.fadeStep = .01;
                        }
                        else {
                            // Was active, is now inactive => fade out.
                            this.fadeAlpha = 1;
                            this.fadeStep = -.01;
                        }
                    }
                },
                enumerable: true,
                configurable: true
            });
            BinaryRain.prototype.FillDigits = function (width) {
                for (var iDigit = 0; iDigit < this.nrOfDigits; iDigit++) {
                    var digit = new Digit();
                    this.FillDigit(digit, width);
                    this.animatingDigits.Add(digit);
                }
            };
            BinaryRain.prototype.FillDigit = function (digit, width) {
                var rnd = Math.random();
                digit.text = (rnd < .5) ? "0" : "1";
                rnd = Math.random();
                digit.filled = (rnd < .5);
                rnd = Math.random();
                digit.alpha = Math.max(.05, rnd);
                rnd = Math.random();
                digit.speed = Math.max(this.minSpeed, rnd * this.maxSpeed);
                rnd = Math.random();
                digit.xPos = rnd * width;
                rnd = Math.random();
                digit.fontSize = Math.max(this.minFontSize, rnd * this.maxFontSize);
                digit.yPos = -digit.fontSize;
            };
            BinaryRain.prototype.Render = function (width, height) {
                if (this.Active || this.fading) {
                    if (this.animatingDigits.Count == 0) {
                        this.FillDigits(width);
                    }
                    var font = this.getFont();
                    var color = this.getColor();
                    var fade = (this.fading) ? this.fadeAlpha : 1;
                    for (var iDigit = 0; iDigit < this.nrOfDigits; iDigit++) {
                        var digit = this.animatingDigits.Index(iDigit);
                        font.Size = digit.fontSize;
                        color.Alpha = digit.alpha * fade;
                        Web.Renderer.DrawText(digit.text, font, digit.xPos, digit.yPos, color, digit.filled, Web.TextBaseline.middle);
                        digit.yPos = digit.yPos + digit.speed;
                        if (digit.yPos > height) {
                            this.FillDigit(digit, width);
                        }
                    }
                    if (this.fading) {
                        this.fadeAlpha += this.fadeStep;
                        if (this.fadeAlpha < 0 || this.fadeAlpha > 1) {
                            this.fading = false;
                        }
                    }
                }
            };
            return BinaryRain;
        }(Web.AutoDrawingBase));
        Web.BinaryRain = BinaryRain;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var ProgressCircle = /** @class */ (function (_super) {
            __extends(ProgressCircle, _super);
            function ProgressCircle(requirement, centerX, centerY, innerRadius, outerRadius, backgroundColor, foregroundColor) {
                var _this = _super.call(this, outerRadius * 2, requirement) || this;
                _this.centerX = centerX;
                _this.centerY = centerY;
                _this.innerRadius = innerRadius;
                _this.outerRadius = outerRadius;
                _this.backgroundColor = backgroundColor;
                _this.foregroundColor = foregroundColor;
                return _this;
            }
            ProgressCircle.prototype.Render = function (width, height) {
                // Render background
                var outerPoints = Web.Renderer.CircleSegmentPoints(this.centerX, this.centerY, this.outerRadius, 450, 90);
                var innerPoints = Web.Renderer.CircleSegmentPoints(this.centerX, this.centerY, this.innerRadius, 450, 90);
                for (var iPoint = innerPoints.length - 1; iPoint >= 0; iPoint--) {
                    outerPoints.push(innerPoints[iPoint]);
                }
                Web.Renderer.FillPolygon(outerPoints, this.backgroundColor);
                // Render progress
                if (this.runningValue > 0) {
                    var startAngle = this.PercentageToAngle(0);
                    var endAngle;
                    if (this.runningValue >= this.endValue) {
                        endAngle = startAngle + 360;
                    }
                    else {
                        var endPercentage = this.runningValue / this.endValue;
                        endAngle = this.PercentageToAngle(endPercentage);
                    }
                    outerPoints = Web.Renderer.CircleSegmentPoints(this.centerX, this.centerY, this.outerRadius, endAngle, startAngle);
                    innerPoints = Web.Renderer.CircleSegmentPoints(this.centerX, this.centerY, this.innerRadius, endAngle, startAngle);
                    for (iPoint = innerPoints.length - 1; iPoint >= 0; iPoint--) {
                        outerPoints.push(innerPoints[iPoint]);
                    }
                    Web.Renderer.FillPolygon(outerPoints, this.foregroundColor);
                }
            };
            ProgressCircle.prototype.PercentageToAngle = function (precentage) {
                // A 'normal' circle begins at 3 o'clock and goes counter clockwise,
                //   - we reverse the order (360 - ... ) 
                //   - and adjust the starting point (12'O clock = 90°) 
                var angle = 360 - (precentage * 360 - 90);
                if (angle < 0) {
                    angle += 360;
                }
                else if (angle >= 360) {
                    angle -= 360;
                }
                return angle;
            };
            return ProgressCircle;
        }(Web.AutoDrawingBase));
        Web.ProgressCircle = ProgressCircle;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Fps = /** @class */ (function (_super) {
            __extends(Fps, _super);
            function Fps(requirement, x, y, getColor, align, getFont) {
                var _this = _super.call(this, 0, requirement) || this;
                _this.xStart = 0;
                _this.getColor = getColor;
                _this.getFont = getFont;
                _this.x = x;
                _this.y = y;
                _this.align = align;
                return _this;
            }
            Fps.prototype.Render = function (width, height) {
                var color = this.getColor();
                this.font = this.getFont();
                var fontString = this.font.FontString;
                var frameRate = Web.Renderer.AverageFrameRate.toString();
                if (this.align == Web.Align.Floating || this.align == Web.Align.TopLeft) {
                    Web.Renderer.DrawText(frameRate, this.font, this.x, this.y, color, true);
                }
                else {
                    var textWidth = Web.Renderer.MeasureText(frameRate, this.font).Width;
                    var xPosition;
                    var yPosition;
                    if (this.align == Web.Align.BottomLeft) {
                        yPosition = height - this.font.Size - this.y;
                        Web.Renderer.DrawText(frameRate, this.font, this.x, yPosition, color, true);
                    }
                    else if (this.align == Web.Align.TopRight) {
                        xPosition = width - textWidth - this.x;
                        Web.Renderer.DrawText(frameRate, this.font, xPosition, this.y, color, true);
                    }
                    else if (this.align == Web.Align.BottomRight) {
                        xPosition = width - textWidth - this.x;
                        yPosition = height - this.font.Size - this.y;
                        Web.Renderer.DrawText(frameRate, this.font, xPosition, yPosition, color, true);
                    }
                }
            };
            return Fps;
        }(Web.AutoDrawingBase));
        Web.Fps = Fps;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
/// <reference path="../Font.ts"/>
/// <reference path="../enums.ts"/>
/// <reference path="../Interfaces/Func.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Wave = /** @class */ (function () {
            function Wave() {
            }
            return Wave;
        }());
        var Waves = /** @class */ (function (_super) {
            __extends(Waves, _super);
            function Waves(requirement, minSpeed, maxSpeed, nrOfWaves, getColor, paralax) {
                if (paralax === void 0) { paralax = false; }
                var _this = _super.call(this, 0, requirement) || this;
                _this.fading = false;
                _this.active = false;
                _this.Paralax = false;
                _this.animatingWaves = new Web.List();
                _this.maxFrequency = 8;
                _this.minAlpha = .05;
                _this.prevHeight = 0;
                _this.prevParalax = false;
                _this.minSpeed = minSpeed;
                _this.maxSpeed = maxSpeed;
                _this.nrOfWaves = nrOfWaves;
                _this.getColor = getColor;
                _this.Paralax = paralax;
                return _this;
            }
            Object.defineProperty(Waves.prototype, "Active", {
                get: function () { return this.active; },
                set: function (value) {
                    if (value != this.active) {
                        this.active = value;
                        this.fading = true;
                        if (this.active) {
                            // Was inactive, is now active => fade in.
                            this.fadeAlpha = 0;
                            this.fadeStep = .01;
                        }
                        else {
                            // Was active, is now inactive => fade out.
                            this.fadeAlpha = 1;
                            this.fadeStep = -.01;
                        }
                    }
                },
                enumerable: true,
                configurable: true
            });
            Waves.prototype.FillWaves = function (width, height) {
                this.animatingWaves.Clear();
                if (this.Paralax) {
                    var yStep = height / (this.nrOfWaves + 1);
                    var yPos = height - yStep;
                    var speed = this.maxSpeed;
                    var speedStep = speed * .33;
                    var minAmplitude = height / (3 * (this.nrOfWaves + 1));
                    var maxAmplitude = height / (this.nrOfWaves + 1);
                    var amplitude = maxAmplitude;
                    var amplitudeStep = (maxAmplitude - minAmplitude) / (this.nrOfWaves + 1);
                    var alpha = 1;
                    var alphaStep = (1 - this.minAlpha) / (this.nrOfWaves + 1);
                    var frequency = this.maxFrequency;
                    var frequencyStep = (this.maxFrequency - 2) / (this.nrOfWaves + 1);
                    var rnd;
                    for (var i = 0; i < this.nrOfWaves; i++) {
                        var paralaxWave = new Wave();
                        rnd = Math.random();
                        paralaxWave.startAngle = 360 * rnd;
                        paralaxWave.yPos = yPos;
                        paralaxWave.speed = speed;
                        paralaxWave.yAmplitude = amplitude;
                        paralaxWave.frequency = frequency;
                        paralaxWave.alpha = alpha;
                        this.animatingWaves.Add(paralaxWave);
                        yPos -= yStep;
                        speed -= speedStep;
                        speedStep *= .3;
                        amplitude -= amplitudeStep;
                        alpha -= alphaStep;
                        frequency -= frequencyStep;
                    }
                }
                else {
                    for (var iWave = 0; iWave < this.nrOfWaves; iWave++) {
                        var wave = new Wave();
                        this.FillWave(wave, width, height);
                        this.animatingWaves.Add(wave);
                    }
                }
            };
            Waves.prototype.FillWave = function (wave, width, height) {
                var rnd = Math.random();
                wave.startAngle = 360 * rnd;
                rnd = Math.random();
                wave.yPos = height * rnd;
                var minAmplitude = height / 12;
                var maxAmplitude = height / 6;
                rnd = Math.random();
                wave.yAmplitude = Math.max(minAmplitude, maxAmplitude * rnd);
                rnd = Math.random();
                wave.frequency = Math.max(2, rnd * this.maxFrequency);
                rnd = Math.random();
                wave.speed = Math.max(this.minSpeed, rnd * this.maxSpeed);
                rnd = Math.random();
                wave.alpha = Math.max(this.minAlpha, rnd);
            };
            Waves.prototype.Render = function (width, height) {
                if (this.Active || this.fading) {
                    var framerateRatio = 1 / Web.Renderer.LastFrameRate;
                    if (this.animatingWaves.Count == 0 || height != this.prevHeight || this.Paralax != this.prevParalax) {
                        this.FillWaves(width, height);
                        this.prevHeight = height;
                        this.prevParalax = this.Paralax;
                    }
                    var color = this.getColor();
                    var fade = (this.fading) ? this.fadeAlpha : 1;
                    for (var iWave = 0; iWave < this.nrOfWaves; iWave++) {
                        var wave = this.animatingWaves.Index(iWave);
                        color.Alpha = wave.alpha * fade;
                        Web.Renderer.DrawSine(0, width, wave.yPos, wave.yAmplitude, wave.frequency, wave.startAngle, Math.floor(width / 5), color);
                        wave.startAngle += (wave.speed * framerateRatio);
                        if (wave.startAngle > 360) {
                            wave.startAngle -= 360;
                        }
                    }
                    if (this.fading) {
                        this.fadeAlpha += this.fadeStep;
                        if (this.fadeAlpha < 0 || this.fadeAlpha > 1) {
                            this.fading = false;
                        }
                    }
                }
            };
            return Waves;
        }(Web.AutoDrawingBase));
        Web.Waves = Waves;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var XYText = /** @class */ (function (_super) {
            __extends(XYText, _super);
            function XYText(requirement, text, x, y, getColor, align, getFont, filled) {
                var _this = _super.call(this, 0, requirement) || this;
                _this.xStart = 0;
                _this.getColor = getColor;
                _this.Text = text;
                _this.getFont = getFont;
                _this.filled = filled;
                _this.x = x;
                _this.y = y;
                _this.align = align;
                return _this;
            }
            XYText.prototype.Render = function (width, height) {
                var font = this.getFont();
                var color = this.getColor();
                if (this.align == Web.Align.Floating || this.align == Web.Align.TopLeft) {
                    Web.Renderer.DrawText(this.Text, font, this.x, this.y, color, this.filled);
                }
                else {
                    var textWidth = Web.Renderer.MeasureText(this.Text, font).Width;
                    var xPosition;
                    var yPosition;
                    if (this.align == Web.Align.BottomLeft) {
                        yPosition = height - font.Size - this.y;
                        Web.Renderer.DrawText(this.Text, font, this.x, yPosition, color, this.filled);
                    }
                    else if (this.align == Web.Align.TopRight) {
                        xPosition = width - textWidth - this.x;
                        Web.Renderer.DrawText(this.Text, font, xPosition, this.y, color, this.filled);
                    }
                    else if (this.align == Web.Align.BottomRight) {
                        xPosition = width - textWidth - this.x;
                        yPosition = height - font.Size - this.y;
                        Web.Renderer.DrawText(this.Text, font, xPosition, yPosition, color, this.filled);
                    }
                }
            };
            return XYText;
        }(Web.AutoDrawingBase));
        Web.XYText = XYText;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var XYImage = /** @class */ (function (_super) {
            __extends(XYImage, _super);
            function XYImage(size, requirement, imagePath, x, y, align) {
                var _this = _super.call(this, size, requirement) || this;
                _this.xStart = 0;
                _this.x = x;
                _this.y = y;
                _this.align = align;
                _this.image = new Image();
                _this.image.src = imagePath;
                return _this;
            }
            XYImage.prototype.Render = function (width, height) {
                // Image loaded => imageWidth > 0
                if (this.image.width > 0) {
                    if (this.align == Web.Align.Floating || this.align == Web.Align.TopLeft) {
                        Web.Renderer.DrawImage(this.image, this.x, this.y);
                    }
                    else {
                        var xPosition;
                        var yPosition;
                        if (this.align == Web.Align.BottomLeft) {
                            yPosition = height - this.image.height - this.y;
                            Web.Renderer.DrawImage(this.image, this.x, yPosition);
                        }
                        else if (this.align == Web.Align.TopRight) {
                            xPosition = width - this.image.width - this.x;
                            Web.Renderer.DrawImage(this.image, xPosition, this.y);
                        }
                        else if (this.align == Web.Align.BottomRight) {
                            xPosition = width - this.image.width - this.x;
                            yPosition = height - this.image.height - this.y;
                            Web.Renderer.DrawImage(this.image, xPosition, yPosition);
                        }
                    }
                }
            };
            return XYImage;
        }(Web.AutoDrawingBase));
        Web.XYImage = XYImage;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Slideshow = /** @class */ (function (_super) {
            __extends(Slideshow, _super);
            function Slideshow(size, requirement, numberOfSeconds, progressCircle, nextImage, nextMenuItem, color, getFont) {
                var _this = _super.call(this, size) || this;
                _this.running = false;
                _this.playPauseX = 15;
                _this.playPauseY = 13;
                _this.playPauseWidth = 25;
                _this.playPauseHeight = 26;
                _this.playPauseRectangle = new Web.Rectangle(_this.playPauseX - 10, _this.playPauseY - 10, _this.playPauseWidth + 20, _this.playPauseHeight + 20); // fuzzy test for mobile device. 
                _this.playPoint1 = new Web.Point(_this.playPauseX, _this.playPauseY);
                _this.playPoint2 = new Web.Point(_this.playPauseX, _this.playPauseY + _this.playPauseHeight);
                _this.playPoint3 = new Web.Point(_this.playPauseX + _this.playPauseWidth, _this.playPauseY + _this.playPauseHeight * .5);
                _this.playPolygon = [_this.playPoint1, _this.playPoint2, _this.playPoint3];
                _this.pauseRectangle = new Web.Rectangle(_this.playPauseX, _this.playPauseY, _this.playPauseWidth, _this.playPauseHeight);
                _this.numberOfMilliSeconds = numberOfSeconds * 1000;
                _this.progressCircle = progressCircle;
                _this.progressCircle.Visible = false;
                _this.nextImage = nextImage;
                _this.nextMenuItem = nextMenuItem;
                _this.color = color;
                _this.getFont = getFont;
                _this.font = getFont();
                return _this;
            }
            Object.defineProperty(Slideshow.prototype, "Color", {
                get: function () { return this.color; },
                set: function (value) { this.color = value; },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(Slideshow.prototype, "Running", {
                get: function () { return this.running; },
                enumerable: true,
                configurable: true
            });
            Slideshow.prototype.Start = function () {
                this.startedAt = Date.now();
                this.running = true;
                this.progressCircle.runningValue = 0;
                this.progressCircle.endValue = this.numberOfMilliSeconds;
                this.progressCircle.Visible = true;
            };
            Slideshow.prototype.Stop = function () {
                this.running = false;
                this.progressCircle.Visible = false;
            };
            Slideshow.prototype.Render = function (width, height) {
                this.font = this.getFont();
                Web.Renderer.DrawText("Slideshow", this.font, this.playPauseX, this.progressCircle.centerY + this.progressCircle.outerRadius + 5, this.Color, true, Web.TextBaseline.hanging);
                if (this.running) {
                    var now = Date.now();
                    var difference = now - this.startedAt;
                    this.progressCircle.runningValue = difference;
                    if (difference > this.numberOfMilliSeconds) {
                        if (!Web.SetupControl.ImageStrip.AnimationInProgress) {
                            var nextImageSelected = this.nextImage(Web.SetupControl.ImageStrip);
                            if (!nextImageSelected) {
                                this.nextMenuItem(Web.SetupControl.Menu);
                            }
                            this.progressCircle.runningValue = 0;
                            this.startedAt = now;
                        }
                    }
                    // Render pause button
                    var barWidth = this.pauseRectangle.Width * .5 - 4;
                    Web.Renderer.FillArea(this.pauseRectangle.X, this.pauseRectangle.Y, barWidth, this.pauseRectangle.Height, this.Color);
                    Web.Renderer.FillArea(this.pauseRectangle.CenterX + 4, this.pauseRectangle.Y, barWidth, this.pauseRectangle.Height, this.Color);
                }
                else {
                    // Render play button.
                    Web.Renderer.FillTriangle(this.playPoint1, this.playPoint2, this.playPoint3, this.color);
                }
            };
            Slideshow.prototype.HitTest = function (width, height, mouseEvent) {
                var mousePoint = Web.Renderer.MouseToAutoDrawing(this);
                if (this.running) {
                    // Test pause button
                    if (this.pauseRectangle.PointInside(mousePoint.x, mousePoint.y)) {
                        var barWidth = this.pauseRectangle.Width * .5 - 5;
                        Web.Renderer.FillArea(this.pauseRectangle.X, this.pauseRectangle.Y, barWidth, this.pauseRectangle.Height, Web.Renderer.HighlightColor);
                        Web.Renderer.FillArea(this.pauseRectangle.CenterX + 5, this.pauseRectangle.Y, barWidth, this.pauseRectangle.Height, Web.Renderer.HighlightColor);
                        if (Web.Renderer.MouseClicked) {
                            this.Stop();
                        }
                    }
                    else if (Web.Renderer.MouseClicked && this.playPauseRectangle.PointInside(mousePoint.x, mousePoint.y)) {
                        this.Stop();
                    }
                }
                else {
                    // Test play button
                    if (Web.Renderer.PointInsidePolygon(mousePoint, this.playPolygon)) {
                        Web.Renderer.FillTriangle(this.playPoint1, this.playPoint2, this.playPoint3, Web.Renderer.HighlightColor);
                        if (Web.Renderer.MouseClicked) {
                            this.Start();
                        }
                    }
                    else if (Web.Renderer.MouseClicked && this.playPauseRectangle.PointInside(mousePoint.x, mousePoint.y)) {
                        this.Start();
                    }
                }
                return false;
            };
            return Slideshow;
        }(Web.AutoDrawingBase));
        Web.Slideshow = Slideshow;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var BackgroundImage = /** @class */ (function (_super) {
            __extends(BackgroundImage, _super);
            function BackgroundImage(size, requirement, imagePath, xPosition, yPosition) {
                var _this = _super.call(this, size, requirement) || this;
                _this.backgroundImage = null;
                _this.xPosition = xPosition;
                _this.yPosition = yPosition;
                _this.backgroundImage = new Image();
                _this.backgroundImage.src = imagePath;
                return _this;
            }
            BackgroundImage.prototype.Render = function (width, height) {
                if (this.backgroundImage.width > 0) {
                    var targetWidth = this.backgroundImage.width;
                    var targetHeight = this.backgroundImage.height;
                    var availableWidth = width - this.xPosition;
                    var availableHeight = height - this.yPosition;
                    if (targetWidth > availableWidth || targetHeight > availableHeight) {
                        var widthRatio = availableWidth / targetWidth;
                        var heightRatio = availableHeight / targetHeight;
                        var sizeRatio = Math.min(widthRatio, heightRatio);
                        targetWidth *= sizeRatio;
                        targetHeight *= sizeRatio;
                    }
                    Web.Renderer.DrawImageToSize(this.backgroundImage, this.xPosition, this.yPosition, targetWidth, targetHeight, 1);
                }
            };
            return BackgroundImage;
        }(Web.AutoDrawingBase));
        Web.BackgroundImage = BackgroundImage;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var MenuItem = /** @class */ (function () {
            function MenuItem(menuText, subMenuItems, clickedMenu) {
                this.parentMenu = null;
                this.menuText = menuText;
                this.subMenuItems = subMenuItems;
                this.clickedMenu = clickedMenu;
                if (subMenuItems.length > 0) {
                    for (var sub = 0; sub < subMenuItems.length; sub++) {
                        subMenuItems[sub].parentMenu = this;
                    }
                }
            }
            return MenuItem;
        }());
        Web.MenuItem = MenuItem;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Menu = /** @class */ (function (_super) {
            __extends(Menu, _super);
            function Menu(size, requirement, getFont, getFontColor, getSelectedFontColor, menuItems) {
                var _this = _super.call(this, size, requirement) || this;
                _this.selectedMenuIndex = 0;
                _this.selectedSubMenuIndex = 0;
                _this.startY = 2;
                _this.maxMenuSpacing = 20;
                _this.prevRenderWidth = 0;
                _this.prevRenderHeight = 0;
                _this.hitTestRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.getFont = getFont;
                _this.getFontColor = getFontColor;
                _this.getSelectedFontColor = getSelectedFontColor;
                _this.menuItems = menuItems;
                return _this;
            }
            Menu.prototype.PrevMenuItem = function (menu) {
                var mainMenuItem = menu.menuItems[menu.selectedMenuIndex];
                if (mainMenuItem.subMenuItems.length > 0) {
                    menu.selectedSubMenuIndex--;
                    if (menu.selectedSubMenuIndex < 0) {
                        menu.SetPrevSelectedMenuIndex();
                    }
                }
                else {
                    menu.SetPrevSelectedMenuIndex();
                }
                menu.ActivateSelectedMenuItem();
            };
            Menu.prototype.NextMenuItem = function (menu) {
                var mainMenuItem = menu.menuItems[menu.selectedMenuIndex];
                if (mainMenuItem.subMenuItems.length > 0) {
                    menu.selectedSubMenuIndex++;
                    if (menu.selectedSubMenuIndex > mainMenuItem.subMenuItems.length - 1) {
                        menu.SetNextSelectedMenuIndex();
                    }
                }
                else {
                    menu.SetNextSelectedMenuIndex();
                }
                menu.ActivateSelectedMenuItem();
            };
            Menu.prototype.SetPrevSelectedMenuIndex = function () {
                this.selectedMenuIndex--;
                if (this.selectedMenuIndex < 0) {
                    this.selectedMenuIndex = this.menuItems.length - 1;
                }
                this.selectedSubMenuIndex = 0;
            };
            Menu.prototype.SetNextSelectedMenuIndex = function () {
                this.selectedMenuIndex++;
                if (this.selectedMenuIndex > this.menuItems.length - 1) {
                    this.selectedMenuIndex = 0;
                }
                this.selectedSubMenuIndex = 0;
            };
            Menu.prototype.ActivateSelectedMenuItem = function () {
                var mainMenu = this.menuItems[this.selectedMenuIndex];
                if (mainMenu.subMenuItems.length > 0) {
                    var subMenuItem = mainMenu.subMenuItems[this.selectedSubMenuIndex];
                    subMenuItem.clickedMenu(subMenuItem);
                }
                else {
                    mainMenu.clickedMenu(mainMenu);
                }
            };
            Menu.prototype.SetSelectedMenu = function (menuItem) {
                this.selectedMenuIndex = 0;
                this.selectedSubMenuIndex = 0;
                for (var iMenu = 0; iMenu < this.menuItems.length; iMenu++) {
                    var mainMenuItem = this.menuItems[iMenu];
                    if (menuItem == mainMenuItem) {
                        this.selectedMenuIndex = iMenu;
                        break;
                    }
                    var found = false;
                    for (var iSubMenu = 0; iSubMenu < mainMenuItem.subMenuItems.length; iSubMenu++) {
                        var subMenuItem = mainMenuItem.subMenuItems[iSubMenu];
                        if (menuItem == subMenuItem) {
                            this.selectedMenuIndex = iMenu;
                            this.selectedSubMenuIndex = iSubMenu;
                            found = true;
                            break;
                        }
                    }
                    if (found) {
                        break;
                    }
                }
            };
            Menu.prototype.Render = function (width, height) {
                this.font = this.getFont();
                this.SetMenuCanvasAndFontSize(width, height);
                Web.Renderer.DrawCanvas(this.menuCanvas, 0, 0);
                var y = this.startY;
                this.RenderMenuItems(width, this.menuItems, y, this.selectedMenuIndex, true);
                var selectedMenu = this.menuItems[this.selectedMenuIndex];
                y += this.font.Size;
                this.RenderMenuItems(width, selectedMenu.subMenuItems, y, this.selectedSubMenuIndex, true);
            };
            Menu.prototype.RenderMenuItems = function (width, menuItems, menuY, selectedIndex, selectedOnes) {
                if (selectedOnes === void 0) { selectedOnes = false; }
                var selectedFontColor = this.getSelectedFontColor();
                var fontColor = this.getFontColor();
                var menuWidth = this.MeasureMenuItems(menuItems);
                var runningX = (width * .5) - (menuWidth * .5);
                for (var iMenu = 0; iMenu < menuItems.length; iMenu++) {
                    var menuItem = menuItems[iMenu];
                    if (selectedOnes) {
                        if (iMenu == selectedIndex) {
                            Web.Renderer.DrawText(menuItem.menuText, this.font, runningX, menuY, selectedFontColor, true);
                        }
                    }
                    else {
                        Web.Renderer.DrawText(menuItem.menuText, this.font, runningX, menuY, fontColor, true, Web.TextBaseline.top, Web.TextAlign.left, this.menuContext);
                    }
                    var textWidth = Web.Renderer.MeasureText(menuItem.menuText, this.font).Width;
                    runningX += textWidth;
                    runningX += this.menuXSpacing;
                }
            };
            Menu.prototype.SetMenuCanvasAndFontSize = function (renderWidth, renderHeight) {
                this.menuXSpacing = this.maxMenuSpacing;
                var mainMenuWidth = this.MeasureMenuItems(this.menuItems);
                var selectedMenu = this.menuItems[this.selectedMenuIndex];
                var subMenuWidth = this.MeasureMenuItems(selectedMenu.subMenuItems);
                var menuWidth = Math.max(mainMenuWidth, subMenuWidth);
                if (menuWidth > renderWidth) {
                    var ratio = renderWidth / menuWidth;
                    this.font.Size = ratio * this.font.Size;
                    this.menuXSpacing = 8;
                }
                //if (renderWidth != this.prevRenderWidth || renderHeight != this.prevRenderHeight)
                //{
                var canvasContext = Web.Renderer.GetNewCanvasAndContext(renderWidth, renderHeight);
                this.menuCanvas = canvasContext.canvas;
                this.menuContext = canvasContext.context;
                this.prevRenderWidth = renderWidth;
                this.prevRenderHeight = renderHeight;
                // Render menu once
                var y = this.startY;
                this.RenderMenuItems(renderWidth, this.menuItems, y, this.selectedMenuIndex, false);
                y += this.font.Size;
                this.RenderMenuItems(renderWidth, selectedMenu.subMenuItems, y, this.selectedSubMenuIndex, false);
                //}
            };
            Menu.prototype.MeasureMenuItems = function (menuItems) {
                var width = 0;
                for (var iMenu = 0; iMenu < menuItems.length; iMenu++) {
                    var menuItem = menuItems[iMenu];
                    width += Web.Renderer.MeasureText(menuItem.menuText, this.font).Width;
                }
                width += (this.menuXSpacing * (menuItems.length - 1));
                return width;
            };
            Menu.prototype.HitTest = function (width, height, mouseEvent) {
                if (!Web.SetupControl.SlideshowRunning && this.menuItems.length > 0) {
                    var mousePoint = Web.Renderer.MouseToAutoDrawing(this);
                    var y = this.startY;
                    var hitMenu = this.HitTestMenuItems(mousePoint, width, this.menuItems, y);
                    if (hitMenu) {
                        return true;
                    }
                    var selectedMenu = this.menuItems[this.selectedMenuIndex];
                    y += this.font.Size;
                    hitMenu = this.HitTestMenuItems(mousePoint, width, selectedMenu.subMenuItems, y);
                    if (hitMenu) {
                        return true;
                    }
                }
                return false;
            };
            Menu.prototype.HitTestMenuItems = function (mousePoint, width, menuItems, menuY) {
                var menuWidth = this.MeasureMenuItems(menuItems);
                var runningX = (width * .5) - (menuWidth * .5);
                for (var iMenu = 0; iMenu < menuItems.length; iMenu++) {
                    var menuItem = menuItems[iMenu];
                    var textWidth = Web.Renderer.MeasureText(menuItem.menuText, this.font).Width;
                    this.hitTestRectangle.X = runningX;
                    this.hitTestRectangle.Y = menuY;
                    this.hitTestRectangle.Width = textWidth;
                    this.hitTestRectangle.Height = this.font.Size;
                    if (this.hitTestRectangle.PointInside(mousePoint.x, mousePoint.y)) {
                        Web.Renderer.FillRectangle(this.hitTestRectangle, Web.Renderer.HighlightColor);
                        if (Web.Renderer.MouseClicked) {
                            var nrOfSubMenus = menuItem.subMenuItems.length;
                            if (nrOfSubMenus > 0) {
                                var subMenu = menuItem.subMenuItems[0];
                                this.SetSelectedMenu(subMenu);
                                subMenu.clickedMenu(subMenu);
                                return true;
                            }
                            else {
                                menuItem.clickedMenu(menuItem);
                                this.SetSelectedMenu(menuItem);
                            }
                        }
                    }
                    runningX += textWidth;
                    runningX += this.menuXSpacing;
                }
                return false;
            };
            return Menu;
        }(Web.AutoDrawingBase));
        Web.Menu = Menu;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Clock = /** @class */ (function (_super) {
            __extends(Clock, _super);
            function Clock(requirement, radius, positionX, positionY, getBackgroundColor, getHighlightColor, getHandColor, getSecondsHandColor, getRingColor, getCenterColor, getDivisionColor, getSubDivisionColor, positionOnSideOf) {
                var _this = _super.call(this, radius * 2, requirement) || this;
                _this.gradientPoint1 = new Web.Point(0, 0);
                _this.gradientPoint2 = new Web.Point(0, 0);
                _this.prevBackgroundRadius = 0;
                _this.radius = radius;
                _this.centerX = positionX + radius;
                _this.centerY = positionY + radius;
                _this.offsetX = positionX;
                _this.offsetY = positionY;
                _this.getBackgroundColor = getBackgroundColor;
                _this.getHighlightColor = getHighlightColor;
                _this.getHandColor = getHandColor;
                _this.getSecondsHandColor = getSecondsHandColor;
                _this.getRingColor = getRingColor;
                _this.getCenterColor = getCenterColor;
                _this.getDivisionColor = getDivisionColor;
                _this.getSubDivisionColor = getSubDivisionColor;
                _this.positionOnSideOf = positionOnSideOf;
                return _this;
            }
            Clock.prototype.Render = function (width, height) {
                this.backgroundColor = this.getBackgroundColor();
                this.highlightColor = this.getHighlightColor();
                this.handColor = this.getHandColor();
                this.secondsHandColor = this.getSecondsHandColor();
                this.ringColor = this.getRingColor();
                this.centerColor = this.getCenterColor();
                this.divisionColor = this.getDivisionColor();
                this.subDivisionColor = this.getSubDivisionColor();
                var transparentColor = this.highlightColor.Clone();
                transparentColor.Alpha = 0;
                var windowSize = Math.min(Web.Renderer.Width, Web.Renderer.Height);
                var maxRadius = windowSize * .05;
                var radius = (this.radius > maxRadius) ? maxRadius : this.radius;
                if (radius > 15) {
                    if (this.prevBackgroundRadius != radius) {
                        var backgroundSize = 2 + 2 * radius;
                        var canvasContext = Web.Renderer.GetNewCanvasAndContext(backgroundSize, backgroundSize);
                        this.backgroundCanvas = canvasContext.canvas;
                        this.backgroundContext = canvasContext.context;
                        this.DrawBackground(radius);
                        this.prevBackgroundRadius = radius;
                    }
                    var centerX = this.centerX;
                    var centerY = this.centerY;
                    if (this.positionOnSideOf == Web.GraphDocking.Bottom) {
                        var dimensions = Web.Renderer.DimensionsOf(this.positionOnSideOf);
                        centerY = dimensions.Y;
                        centerX = dimensions.Width - radius - this.offsetX;
                    }
                    Web.Renderer.DrawCanvas(this.backgroundCanvas, centerX - radius, centerY - radius);
                    var hourOuterRadius = radius - 1;
                    // Seconds hand
                    var now = new Date();
                    var seconds = now.getSeconds();
                    var secondsAngle = seconds * 6;
                    secondsAngle -= 90;
                    var secondsPoint = Web.Renderer.AngleToPositionCW(secondsAngle, hourOuterRadius, centerX, centerY);
                    Web.Renderer.DrawLine(secondsPoint.x, secondsPoint.y, centerX, centerY, 1, this.secondsHandColor);
                    // Minutes hand
                    var minutes = now.getMinutes();
                    var minutesAngle = minutes * 6;
                    minutesAngle -= 90;
                    var minutesPoint = Web.Renderer.AngleToPositionCW(minutesAngle, hourOuterRadius - 2, centerX, centerY);
                    Web.Renderer.DrawLine(minutesPoint.x, minutesPoint.y, centerX, centerY, 2, this.handColor);
                    // Hour hand.
                    var hours = now.getHours();
                    if (hours >= 12) {
                        hours -= 12;
                    }
                    hours += minutes / 60;
                    hourOuterRadius -= (radius * .5);
                    var hoursAngle = hours * 30;
                    hoursAngle -= 90;
                    var hoursPoint = Web.Renderer.AngleToPositionCW(hoursAngle, hourOuterRadius, centerX, centerY);
                    Web.Renderer.DrawLine(hoursPoint.x, hoursPoint.y, centerX, centerY, 2, this.handColor);
                    // Center
                    Web.Renderer.FillCircle(centerX, centerY, 5, this.centerColor);
                    Web.Renderer.DrawCircle(centerX, centerY, 5, 1, Web.Renderer.ColorBlack);
                    // Gloss
                    var glossCenterY = centerY - radius / 3;
                    var glossRadiusX = radius * .85;
                    var glossRadiusY = radius - (centerY - glossCenterY);
                    this.gradientPoint1.x = centerX;
                    this.gradientPoint1.y = glossCenterY - glossRadiusY;
                    this.gradientPoint2.x = centerX;
                    this.gradientPoint2.y = glossCenterY + glossRadiusY;
                    Web.Renderer.FillEllipseGradient(centerX, glossCenterY, glossRadiusX, glossRadiusY, this.highlightColor, transparentColor, this.gradientPoint1, this.gradientPoint2);
                }
            };
            Clock.prototype.DrawBackground = function (radius) {
                var center = radius + 1;
                Web.Renderer.FillCircle(center, center, radius, this.backgroundColor, this.backgroundContext);
                Web.Renderer.DrawCircle(center, center, radius, 1, this.ringColor, this.backgroundContext);
                // Draw Divisions
                var hourStep = 30; //    360/12
                var hourAngle = -60; // Circle starts at 3'o clock, -90 is hour 12, hour 1 is 360/12 more
                var hourOuterRadius = radius - 1;
                var hourInnerRadius = hourOuterRadius - 3;
                for (var iHour = 1; iHour <= 12; iHour++) {
                    var hourOuterPoint = Web.Renderer.AngleToPositionCW(hourAngle, hourOuterRadius, center, center);
                    var hourInnerPoint = Web.Renderer.AngleToPositionCW(hourAngle, hourInnerRadius, center, center);
                    Web.Renderer.DrawLine(hourOuterPoint.x, hourOuterPoint.y, hourInnerPoint.x, hourInnerPoint.y, 1, this.divisionColor, this.backgroundContext);
                    for (var iSecond = 1; iSecond <= 4; iSecond++) {
                        var hour = iHour - 1;
                        var secondAngle = -90 + (hour * hourStep) + (iSecond * 6);
                        var secondOuterPoint = Web.Renderer.AngleToPositionCW(secondAngle, hourOuterRadius, center, center);
                        var secondInnerPoint = Web.Renderer.AngleToPositionCW(secondAngle, hourInnerRadius, center, center);
                        Web.Renderer.DrawLine(secondOuterPoint.x, secondOuterPoint.y, secondInnerPoint.x, secondInnerPoint.y, 1, this.subDivisionColor, this.backgroundContext);
                    }
                    hourAngle += hourStep;
                }
            };
            return Clock;
        }(Web.AutoDrawingBase));
        Web.Clock = Clock;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Title = /** @class */ (function (_super) {
            __extends(Title, _super);
            function Title(size, requirement, getColor, text, getFont, filled, marginY, spacing, speed) {
                var _this = _super.call(this, size, requirement) || this;
                _this.marginY = 0;
                _this.smallerFontSet = false;
                _this.startAlpha = .35;
                _this.animationProgress = 1;
                _this.animationStopped = false;
                _this.maxSize = size;
                _this.getColor = getColor;
                _this.text = text;
                _this.getFont = getFont;
                _this.font = getFont();
                _this.fontSizeRatio = (size != 0) ? _this.font.Size / size : 5;
                _this.filled = filled;
                _this.marginY = marginY;
                _this.spacing = spacing;
                _this.speed = speed;
                return _this;
            }
            Object.defineProperty(Title.prototype, "Text", {
                get: function () { return this.text; },
                set: function (value) {
                    this.text = value;
                    this.animationProgress = 1;
                    this.animationStopped = false;
                },
                enumerable: true,
                configurable: true
            });
            Title.prototype.MeasureDock = function (otherSize) {
                if (this.Dock == Web.GraphDocking.Bottom || this.Dock == Web.GraphDocking.Top) {
                    var maxHeight = Web.Renderer.Height * .05;
                    if (maxHeight < this.maxSize) {
                        this.font.Size = maxHeight * this.fontSizeRatio;
                        this.smallerFontSet = true;
                        return maxHeight;
                    }
                    else if (this.smallerFontSet) {
                        this.smallerFontSet = false;
                    }
                }
                else if (this.Dock == Web.GraphDocking.Left || this.Dock == Web.GraphDocking.Right) {
                    var maxWidth = Web.Renderer.Width * .05;
                    if (maxWidth < this.maxSize) {
                        this.font.Size = maxWidth * this.fontSizeRatio;
                        this.smallerFontSet = true;
                        return maxWidth;
                    }
                    else if (this.smallerFontSet) {
                        this.smallerFontSet = false;
                    }
                }
                return this.marginY + this.font.Size + this.marginY;
            };
            Title.prototype.Render = function (width, height) {
                this.font = this.getFont();
                var centerX = width * .5;
                var centerY = height * .5;
                var leftX = centerX;
                var rightX = centerX;
                var leftIndex;
                var rightIndex;
                var color = this.getColor();
                color.Alpha = Web.Renderer.Interpolate(this.startAlpha, 1, this.animationProgress);
                var evenNumberOfLetters = (this.text.length % 2 == 0);
                if (evenNumberOfLetters) {
                    rightIndex = this.text.length / 2;
                    leftIndex = rightIndex - 1;
                }
                else {
                    var centerIndex = (this.text.length + 1) / 2;
                    var centerLetter = this.text[centerIndex];
                    var centerLetterHalfWidth = .5 * Web.Renderer.MeasureText(centerLetter, this.font).Width;
                    Web.Renderer.DrawText(centerLetter, this.font, centerX - centerLetterHalfWidth, centerY, color, this.filled, Web.TextBaseline.middle);
                    leftX -= centerLetterHalfWidth;
                    rightX += centerLetterHalfWidth;
                    leftIndex = centerIndex - 1;
                    rightIndex = centerIndex + 1;
                }
                var spacing = Web.Renderer.Interpolate(0, this.spacing, this.animationProgress);
                for (var iLeft = leftIndex; iLeft >= 0; iLeft--) {
                    if (iLeft == leftIndex && evenNumberOfLetters) {
                        leftX -= (spacing * .5);
                    }
                    else {
                        leftX -= spacing;
                    }
                    var leftLetter = this.text[iLeft];
                    var leftWidth = Web.Renderer.MeasureText(leftLetter, this.font).Width;
                    leftX -= leftWidth;
                    Web.Renderer.DrawText(leftLetter, this.font, leftX, centerY, color, this.filled, Web.TextBaseline.middle);
                }
                for (var iRight = rightIndex; iRight < this.text.length; iRight++) {
                    if (iRight == rightIndex && evenNumberOfLetters) {
                        rightX += (spacing * .5);
                    }
                    else {
                        rightX += spacing;
                    }
                    var rightLetter = this.text[iRight];
                    var rightWidth = Web.Renderer.MeasureText(rightLetter, this.font).Width;
                    Web.Renderer.DrawText(rightLetter, this.font, rightX, centerY, color, this.filled, Web.TextBaseline.middle);
                    rightX += rightWidth;
                }
                // Stop animation when going off screen
                if (leftX < 0 || rightX > width) {
                    this.animationProgress += this.speed;
                    this.animationStopped = true;
                }
                else if (!this.animationStopped) {
                    var speed = this.speed - Web.Renderer.InterpolateXFastSlow(this.speed, 0, this.animationProgress);
                    this.animationProgress -= speed;
                    if (this.animationProgress < 0) {
                        this.animationProgress = 0;
                    }
                }
            };
            return Title;
        }(Web.AutoDrawingBase));
        Web.Title = Title;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var ImageStrip = /** @class */ (function (_super) {
            __extends(ImageStrip, _super);
            function ImageStrip(size, requirement, imagePaths, imageTitles, imageClickActions, yCenterPositionPerctange, getFrameColor, getButtonBackgroundColor, getButtonForegroundColor, getFont, getFontColor, speed, nextMenuItem, prevMenuItem) {
                var _this = _super.call(this, size, requirement) || this;
                _this.imageWidth = 0;
                _this.prevImage = null;
                _this.currImage = null;
                _this.nextImage = null;
                _this.newImage = null;
                _this.currIndex = 0;
                _this.xStart = 0;
                _this.yTopMargin = 20;
                _this.yBottomMargin = 40;
                _this.prevNextMargin = 200;
                _this.buttonWidth = 70;
                _this.halfButtonWidth = _this.buttonWidth * .5;
                _this.buttonHeight = _this.buttonWidth * Web.Renderer.Phi;
                _this.halfButtonHeight = _this.buttonHeight * .5;
                _this.buttonTriangleWidth = _this.buttonWidth / Web.Renderer.Phi;
                _this.halfButtonTriangleWidth = _this.buttonTriangleWidth * .5;
                _this.buttonTriangleHeight = _this.buttonHeight / Web.Renderer.Phi;
                _this.halfButtonTriangleHeight = _this.buttonTriangleHeight * .5;
                _this.buttonXMargin = 25;
                _this.sideMargin = 10;
                _this.prevButtonRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.nextButtonRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.buttonMouseDetectMargin = 100;
                _this.alphaPrevNext = .5;
                _this.currRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.prevRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.nextRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.newNextRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.newPreviousRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.animationProgress = -1;
                _this.animatingToPrevious = false;
                _this.animatingToNext = false;
                _this.animationFadeOut = false;
                _this.animationFadeIn = false;
                _this.fadeSpeed = .05;
                _this.animationPrevRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.animationCurrRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.animationNewCurrRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.animationNextRectangle = new Web.Rectangle(0, 0, 0, 0);
                _this.yCenterPositionPerctange = (yCenterPositionPerctange >= 0 && yCenterPositionPerctange <= 1) ? yCenterPositionPerctange : .5;
                _this.ApplyNewImages(imagePaths, imageTitles, imageClickActions);
                _this.getFrameColor = getFrameColor;
                _this.getButtonBackgroundColor = getButtonBackgroundColor;
                _this.getButtonForegroundColor = getButtonForegroundColor;
                _this.getFont = getFont;
                _this.getFontColor = getFontColor;
                _this.speed = speed;
                _this.nextMenuItem = nextMenuItem;
                _this.prevMenuItem = prevMenuItem;
                return _this;
            }
            ImageStrip.prototype.SetNewImages = function (imagePaths, imageTitles, imageClickActions) {
                if (imageClickActions === void 0) { imageClickActions = null; }
                this.newImagePaths = imagePaths;
                this.newImageTitles = imageTitles;
                this.newImageClickActions = imageClickActions;
                // Start fade-out of old collection, at end ApplyNewImages() will be done and a fade-in will start
                if (this.currImage == null) {
                    this.ApplyNewImages(this.newImagePaths, this.newImageTitles, this.newImageClickActions);
                }
                else {
                    this.animationProgress = 1;
                    this.animationFadeOut = true;
                }
            };
            ImageStrip.prototype.ApplyNewImages = function (imagePaths, imageTitles, imageClickActions) {
                if (imageClickActions === void 0) { imageClickActions = null; }
                this.currIndex = 0;
                this.imagePaths = imagePaths;
                this.imageTitles = imageTitles;
                this.imageClickActions = imageClickActions;
                this.prevImage = null;
                if (this.imagePaths.length > 0) {
                    this.currImage = new Image();
                    this.currImage.src = this.imagePaths[0];
                    if (this.imagePaths.length > 1) {
                        this.nextImage = new Image();
                        this.nextImage.src = this.imagePaths[1];
                    }
                    else {
                        this.nextImage = null;
                    }
                }
            };
            ImageStrip.prototype.Render = function (width, height) {
                this.frameColor = this.getFrameColor();
                this.width = width;
                this.height = height;
                if (this.animationProgress < 0 || this.animationFadeOut || this.animationFadeIn) {
                    var buttonBackgroundColor = this.getButtonBackgroundColor();
                    var buttonForegroundColor = this.getButtonForegroundColor();
                    var currAlpha = 1;
                    var prevNextAlpha = .5;
                    if (this.animationFadeOut) {
                        currAlpha = Web.Renderer.Interpolate(1, 0, this.animationProgress);
                        prevNextAlpha = Web.Renderer.Interpolate(.5, 0, this.animationProgress);
                    }
                    else if (this.animationFadeIn) {
                        currAlpha = Web.Renderer.Interpolate(0, 1, this.animationProgress);
                        prevNextAlpha = Web.Renderer.Interpolate(0, .5, this.animationProgress);
                    }
                    var currImage = this.currImage;
                    var currImageWidth = currImage.width;
                    if (currImageWidth > 0) {
                        this.CalculateCurrRectangle(this.currRectangle, width, height, currImage);
                        var prevImage = this.prevImage;
                        var nextImage = this.nextImage;
                        // Only draw previous and next image if there is place
                        if (this.currRectangle.Width < width) {
                            if (prevImage != null && prevImage.width > 0) {
                                this.CalculatePrevRectangle(this.prevRectangle, width, height, prevImage, currImage);
                                if (Web.Renderer.AverageFrameRateOk) {
                                    Web.Renderer.DrawImageToSize(prevImage, this.prevRectangle.X, this.prevRectangle.Y, this.prevRectangle.Width, this.prevRectangle.Height, prevNextAlpha);
                                    this.frameColor.Alpha = this.alphaPrevNext;
                                    Web.Renderer.DrawRectangle(this.prevRectangle, this.frameColor);
                                }
                            }
                            if (nextImage != null && nextImage.width > 0) {
                                this.CalculateNextRectangle(this.nextRectangle, width, height, currImage, nextImage);
                                if (Web.Renderer.AverageFrameRateOk) {
                                    Web.Renderer.DrawImageToSize(nextImage, this.nextRectangle.X, this.nextRectangle.Y, this.nextRectangle.Width, this.nextRectangle.Height, prevNextAlpha);
                                    this.frameColor.Alpha = this.alphaPrevNext;
                                    Web.Renderer.DrawRectangle(this.nextRectangle, this.frameColor);
                                }
                            }
                        }
                        var mousePoint = Web.Renderer.MouseToAutoDrawing(this);
                        var font = this.getFont();
                        // Draw the current image on top of the previous and next.
                        Web.Renderer.DrawImageToSize(currImage, this.currRectangle.X, this.currRectangle.Y, this.currRectangle.Width, this.currRectangle.Height, currAlpha);
                        this.frameColor.Alpha = currAlpha;
                        Web.Renderer.DrawRectangle(this.currRectangle, this.frameColor, 3);
                        var imageTitle = this.imageTitles[this.currIndex];
                        this.currImageClickAction = (this.imageClickActions != null) ? this.imageClickActions[this.currIndex] : null;
                        var titleWidth = Web.Renderer.MeasureText(imageTitle, font).Width;
                        var fontColor = this.getFontColor();
                        fontColor.Alpha = currAlpha;
                        Web.Renderer.DrawText(imageTitle, font, this.currRectangle.CenterX - (titleWidth * .5), this.currRectangle.Bottom + 2, fontColor, true);
                        // Draw previous button if mouse is in the vicinity and no animation is in progress.
                        if (!Web.SetupControl.SlideshowRunning) {
                            if (prevImage != null && this.animationProgress < 0) {
                                var xPrevButton = this.currRectangle.X - this.buttonXMargin - this.buttonWidth;
                                if (xPrevButton < this.sideMargin) {
                                    xPrevButton = this.sideMargin;
                                }
                                var yPrevButton = this.currRectangle.CenterY - this.halfButtonHeight;
                                this.prevButtonRectangle.X = xPrevButton;
                                this.prevButtonRectangle.Y = yPrevButton;
                                this.prevButtonRectangle.Width = this.buttonWidth;
                                this.prevButtonRectangle.Height = this.buttonHeight;
                                if (this.prevButtonRectangle.PointNearby(mousePoint.x, mousePoint.y, this.buttonMouseDetectMargin)) {
                                    Web.Renderer.FillRectangle(this.prevButtonRectangle, buttonBackgroundColor);
                                    var prevTriangleStartX = xPrevButton + this.halfButtonWidth - this.halfButtonTriangleWidth;
                                    var prevTriangleStartY = yPrevButton + this.halfButtonHeight - this.halfButtonTriangleHeight;
                                    Web.Renderer.FillTriangleByXY(prevTriangleStartX + this.buttonTriangleWidth, prevTriangleStartY, prevTriangleStartX, prevTriangleStartY + this.halfButtonTriangleHeight, prevTriangleStartX + this.buttonTriangleWidth, prevTriangleStartY + this.buttonTriangleHeight, buttonForegroundColor);
                                }
                            }
                            else {
                                this.prevButtonRectangle.X = 0;
                                this.prevButtonRectangle.Y = 0;
                                this.prevButtonRectangle.Width = 0;
                                this.prevButtonRectangle.Height = 0;
                            }
                            // Draw next button if mouse is in the vicinity and no animation is in progress.
                            if (nextImage != null && this.animationProgress < 0) {
                                var xNextButton = this.currRectangle.X + this.currRectangle.Width + this.buttonXMargin;
                                if (xNextButton + this.buttonWidth > width - this.sideMargin) {
                                    xNextButton = width - this.sideMargin - this.buttonWidth;
                                }
                                var yNextButton = this.currRectangle.CenterY - this.halfButtonHeight;
                                this.nextButtonRectangle.X = xNextButton;
                                this.nextButtonRectangle.Y = yNextButton;
                                this.nextButtonRectangle.Width = this.buttonWidth;
                                this.nextButtonRectangle.Height = this.buttonHeight;
                                if (this.nextButtonRectangle.PointNearby(mousePoint.x, mousePoint.y, this.buttonMouseDetectMargin)) {
                                    Web.Renderer.FillRectangle(this.nextButtonRectangle, buttonBackgroundColor);
                                    var nextTriangleStartX = xNextButton + this.halfButtonWidth - this.halfButtonTriangleWidth;
                                    var nextTriangleStartY = yNextButton + this.halfButtonHeight - this.halfButtonTriangleHeight;
                                    Web.Renderer.FillTriangleByXY(nextTriangleStartX, nextTriangleStartY, nextTriangleStartX + this.buttonTriangleWidth, nextTriangleStartY + this.halfButtonTriangleHeight, nextTriangleStartX, nextTriangleStartY + this.buttonTriangleHeight, buttonForegroundColor);
                                }
                            }
                            else {
                                this.nextButtonRectangle.X = 0;
                                this.nextButtonRectangle.Y = 0;
                                this.nextButtonRectangle.Width = 0;
                                this.nextButtonRectangle.Height = 0;
                            }
                        }
                    }
                    if (this.animationFadeIn || this.animationFadeOut) {
                        this.animationProgress -= this.fadeSpeed;
                        if (this.animationProgress < 0) {
                            if (this.animationFadeIn) {
                                this.animationFadeIn = false;
                            }
                            else if (this.animationFadeOut) {
                                this.ApplyNewImages(this.newImagePaths, this.newImageTitles, this.newImageClickActions);
                                this.animationProgress = 1;
                                this.animationFadeOut = false;
                                this.animationFadeIn = true;
                            }
                        }
                    }
                }
                else {
                    this.RenderAnimation();
                }
            };
            ImageStrip.prototype.RenderAnimation = function () {
                var fadeInAlpha = Web.Renderer.Interpolate(0, .5, this.animationProgress);
                var toCurrAlpha = Web.Renderer.Interpolate(this.alphaPrevNext, 1, this.animationProgress);
                var toPrevNextAlpha = Web.Renderer.Interpolate(1, this.alphaPrevNext, this.animationProgress);
                if (this.animatingToNext) {
                    if (this.newImage != null && this.newImage.width > 0) {
                        this.CalculateNextRectangle(this.newNextRectangle, this.width, this.height, this.nextImage, this.newImage);
                        Web.Renderer.DrawImageToSize(this.newImage, this.newNextRectangle.X, this.newNextRectangle.Y, this.newNextRectangle.Width, this.newNextRectangle.Height, fadeInAlpha);
                    }
                    // Animate curr to prev
                    var currX = Web.Renderer.Interpolate(this.animationCurrRectangle.X, this.animationPrevRectangle.X, this.animationProgress);
                    var currY = Web.Renderer.Interpolate(this.animationCurrRectangle.Y, this.animationPrevRectangle.Y, this.animationProgress);
                    var currWidth = Web.Renderer.Interpolate(this.animationCurrRectangle.Width, this.animationPrevRectangle.Width, this.animationProgress);
                    var currHeight = Web.Renderer.Interpolate(this.animationCurrRectangle.Height, this.animationPrevRectangle.Height, this.animationProgress);
                    Web.Renderer.DrawImageToSize(this.currImage, currX, currY, currWidth, currHeight, toPrevNextAlpha);
                    this.frameColor.Alpha = toPrevNextAlpha;
                    Web.Renderer.DrawArea(currX, currY, currWidth, currHeight, this.frameColor);
                    // Animate next to new curr
                    var nextX = Web.Renderer.Interpolate(this.animationNextRectangle.X, this.animationNewCurrRectangle.X, this.animationProgress);
                    var nextY = Web.Renderer.Interpolate(this.animationNextRectangle.Y, this.animationNewCurrRectangle.Y, this.animationProgress);
                    var nextWidth = Web.Renderer.Interpolate(this.animationNextRectangle.Width, this.animationNewCurrRectangle.Width, this.animationProgress);
                    var nextHeight = Web.Renderer.Interpolate(this.animationNextRectangle.Height, this.animationNewCurrRectangle.Height, this.animationProgress);
                    Web.Renderer.DrawImageToSize(this.nextImage, nextX, nextY, nextWidth, nextHeight, toCurrAlpha);
                    this.frameColor.Alpha = toCurrAlpha;
                    Web.Renderer.DrawArea(nextX, nextY, nextWidth, nextHeight, this.frameColor);
                }
                else if (this.animatingToPrevious) {
                    if (this.newImage != null && this.newImage.width > 0) {
                        this.CalculatePrevRectangle(this.newPreviousRectangle, this.width, this.height, this.newImage, this.prevImage);
                        Web.Renderer.DrawImageToSize(this.newImage, this.newPreviousRectangle.X, this.newPreviousRectangle.Y, this.newPreviousRectangle.Width, this.newPreviousRectangle.Height, fadeInAlpha);
                    }
                    // Animate prev to new curr
                    var prevX = Web.Renderer.Interpolate(this.animationPrevRectangle.X, this.animationNewCurrRectangle.X, this.animationProgress);
                    var prevY = Web.Renderer.Interpolate(this.animationPrevRectangle.Y, this.animationNewCurrRectangle.Y, this.animationProgress);
                    var prevWidth = Web.Renderer.Interpolate(this.animationPrevRectangle.Width, this.animationNewCurrRectangle.Width, this.animationProgress);
                    var prevHeight = Web.Renderer.Interpolate(this.animationPrevRectangle.Height, this.animationNewCurrRectangle.Height, this.animationProgress);
                    Web.Renderer.DrawImageToSize(this.prevImage, prevX, prevY, prevWidth, prevHeight, toCurrAlpha);
                    this.frameColor.Alpha = toCurrAlpha;
                    Web.Renderer.DrawArea(prevX, prevY, prevWidth, prevHeight, this.frameColor);
                    // Animate current to next
                    var toNextX = Web.Renderer.Interpolate(this.animationCurrRectangle.X, this.animationNextRectangle.X, this.animationProgress);
                    var toNextY = Web.Renderer.Interpolate(this.animationCurrRectangle.Y, this.animationNextRectangle.Y, this.animationProgress);
                    var toNextWidth = Web.Renderer.Interpolate(this.animationCurrRectangle.Width, this.animationNextRectangle.Width, this.animationProgress);
                    var toNextHeight = Web.Renderer.Interpolate(this.animationCurrRectangle.Height, this.animationNextRectangle.Height, this.animationProgress);
                    Web.Renderer.DrawImageToSize(this.currImage, toNextX, toNextY, toNextWidth, toNextHeight, toPrevNextAlpha);
                    this.frameColor.Alpha = toPrevNextAlpha;
                    Web.Renderer.DrawArea(toNextX, toNextY, toNextWidth, toNextHeight, this.frameColor);
                }
                this.animationProgress -= this.speed;
                if (this.animationProgress < 0) {
                    if (this.animatingToPrevious) {
                        this.EndAnimationPrev();
                    }
                    else if (this.animatingToNext) {
                        this.EndAnimationNext();
                    }
                }
            };
            ImageStrip.prototype.NextImage = function (imageStrip) {
                if (imageStrip.nextImage != null && imageStrip.nextImage.width > 0) {
                    imageStrip.NextButtonClicked();
                    return true;
                }
                return false;
            };
            ImageStrip.prototype.HitTest = function (width, height, mouseEvent) {
                if (!Web.SetupControl.SlideshowRunning) {
                    if (this.animationProgress < 0) {
                        if (Web.Renderer.swipedLeft) {
                            if (this.prevImage != null && this.prevImage.width > 0) {
                                this.PreviousButtonClicked();
                            }
                            else {
                                this.prevMenuItem(Web.SetupControl.Menu);
                            }
                            // Handled
                            Web.Renderer.swipedLeft = false;
                        }
                        else if (Web.Renderer.swipedRight) {
                            if (this.nextImage != null && this.nextImage.width > 0) {
                                this.NextButtonClicked();
                            }
                            else {
                                this.nextMenuItem(Web.SetupControl.Menu);
                            }
                            // Handled
                            Web.Renderer.swipedRight = false;
                        }
                        else {
                            var mousePoint = Web.Renderer.MouseToAutoDrawing(this);
                            if (this.prevButtonRectangle.Width > 0 && this.prevButtonRectangle.PointInside(mousePoint.x, mousePoint.y)) {
                                Web.Renderer.FillRectangle(this.prevButtonRectangle, Web.Renderer.HighlightColor);
                                // which (0=nothing, 1=left, 2=wheel, 3=right)
                                if (Web.Renderer.MouseClicked) {
                                    this.PreviousButtonClicked();
                                }
                            }
                            else if (this.nextButtonRectangle.Width > 0 && this.nextButtonRectangle.PointInside(mousePoint.x, mousePoint.y)) {
                                Web.Renderer.FillRectangle(this.nextButtonRectangle, Web.Renderer.HighlightColor);
                                // which (0=nothing, 1=left, 2=wheel, 3=right)
                                if (Web.Renderer.MouseClicked) {
                                    this.NextButtonClicked();
                                }
                            }
                            else if (this.currImageClickAction != null) {
                                if (this.currRectangle.PointInside(mousePoint.x, mousePoint.y)) {
                                    Web.Renderer.FillRectangle(this.currRectangle, Web.Renderer.HighlightColor);
                                    if (Web.Renderer.MouseClicked) {
                                        this.currImageClickAction();
                                        //SetupControl.SendMail();
                                    }
                                }
                            }
                        }
                    }
                }
                return false;
            };
            ImageStrip.prototype.CalculateCurrRectangle = function (rectangle, width, height, currImage) {
                var currImageHeight = currImage.height;
                var centerX = width * .5;
                var availableHeight = height - this.yTopMargin - this.yBottomMargin;
                var centerY = this.yTopMargin + (availableHeight * this.yCenterPositionPerctange);
                var targetWidth = currImage.width;
                var targetHeight = currImageHeight;
                if (targetWidth > width || targetHeight > availableHeight) {
                    var widthRatio = width / targetWidth;
                    var heightRatio = availableHeight / targetHeight;
                    var sizeRatio = Math.min(widthRatio, heightRatio);
                    targetWidth *= sizeRatio;
                    targetHeight *= sizeRatio;
                }
                var x = centerX - (targetWidth * .5);
                var y = centerY - (targetHeight * .5);
                rectangle.X = x;
                rectangle.Y = y;
                rectangle.Width = targetWidth;
                rectangle.Height = targetHeight;
            };
            // Calculate the x/y position of a previous image for a given set of previous and current image
            ImageStrip.prototype.CalculatePrevRectangle = function (rectangle, width, height, prevImage, currImage) {
                if (prevImage == null || currImage == null) {
                    rectangle.X = 0;
                    rectangle.Y = 0;
                    rectangle.Width = 0;
                    rectangle.Height = 0;
                }
                else {
                    var currImageWidth = currImage.width;
                    var currImageHeight = currImage.height;
                    var centerX = width * .5;
                    var availableHeight = height - this.yTopMargin - this.yBottomMargin;
                    var centerY = this.yTopMargin + (availableHeight * this.yCenterPositionPerctange);
                    var targetWidth = currImageWidth;
                    var targetHeight = currImageHeight;
                    if (targetWidth > width || targetHeight > availableHeight) {
                        var widthRatio = width / targetWidth;
                        var heightRatio = availableHeight / targetHeight;
                        var sizeRatio = Math.min(widthRatio, heightRatio);
                        targetWidth *= sizeRatio;
                        targetHeight *= sizeRatio;
                    }
                    var x = centerX - (targetWidth * .5);
                    var currEndx = x + targetWidth;
                    var prevNextTargetHeight = targetHeight * .75;
                    var prevImageWidth = prevImage.width;
                    var prevImageHeight = prevImage.height;
                    var prevHeight = (prevImageHeight > prevNextTargetHeight) ? prevNextTargetHeight : prevImageHeight;
                    var prevSizeRatio = prevHeight / prevImageHeight;
                    var prevWidth = prevImageWidth * prevSizeRatio;
                    var prevX = x - this.prevNextMargin;
                    if (prevX + prevWidth > currEndx) {
                        var adjustSize = (targetWidth + this.prevNextMargin) / prevWidth;
                        prevHeight *= adjustSize;
                        prevWidth *= adjustSize;
                    }
                    var prevY = centerY - (prevHeight * .5);
                    rectangle.X = prevX;
                    rectangle.Y = prevY;
                    rectangle.Width = prevWidth;
                    rectangle.Height = prevHeight;
                }
            };
            // Calculate the x/y position of a next image for a given set of current and next image
            ImageStrip.prototype.CalculateNextRectangle = function (rectangle, width, height, currImage, nextImage) {
                if (nextImage == null || currImage == null) {
                    rectangle.X = 0;
                    rectangle.Y = 0;
                    rectangle.Width = 0;
                    rectangle.Height = 0;
                }
                else {
                    var currImageWidth = currImage.width;
                    var currImageHeight = currImage.height;
                    var centerX = width * .5;
                    var availableHeight = height - this.yTopMargin - this.yBottomMargin;
                    var centerY = this.yTopMargin + (availableHeight * this.yCenterPositionPerctange);
                    var targetWidth = currImageWidth;
                    var targetHeight = currImageHeight;
                    if (targetWidth > width || targetHeight > availableHeight) {
                        var widthRatio = width / targetWidth;
                        var heightRatio = availableHeight / targetHeight;
                        var sizeRatio = Math.min(widthRatio, heightRatio);
                        targetWidth *= sizeRatio;
                        targetHeight *= sizeRatio;
                    }
                    var x = centerX - (targetWidth * .5);
                    var currEndx = x + targetWidth;
                    var prevNextTargetHeight = targetHeight * .75;
                    var nextImageWidth = nextImage.width;
                    var nextImageHeight = nextImage.height;
                    var nextHeight = (nextImageHeight > prevNextTargetHeight) ? prevNextTargetHeight : nextImageHeight;
                    var nextSizeRatio = nextHeight / nextImageHeight;
                    var nextWidth = nextImageWidth * nextSizeRatio;
                    var nextX = currEndx + this.prevNextMargin - nextWidth;
                    if (nextX < x) {
                        var resize = (targetWidth + this.prevNextMargin) / nextWidth;
                        nextWidth *= resize;
                        nextHeight *= resize;
                        nextX = x;
                    }
                    var nextY = centerY - (nextHeight * .5);
                    rectangle.X = nextX;
                    rectangle.Y = nextY;
                    rectangle.Width = nextWidth;
                    rectangle.Height = nextHeight;
                }
            };
            Object.defineProperty(ImageStrip.prototype, "AnimationInProgress", {
                get: function () {
                    return this.animationProgress > 0;
                },
                enumerable: true,
                configurable: true
            });
            ImageStrip.prototype.PreviousButtonClicked = function () {
                if (this.prevImage != null && this.prevImage.width > 0) {
                    var newIndex = this.currIndex - 2;
                    if (newIndex >= 0) {
                        this.newImage = new Image();
                        this.newImage.src = this.imagePaths[newIndex];
                    }
                    else {
                        this.newImage = null;
                    }
                    if (Web.Renderer.AverageFrameRateOk) {
                        this.animationProgress = 1;
                        this.animatingToPrevious = true;
                        this.CalculatePrevRectangle(this.animationPrevRectangle, this.width, this.height, this.prevImage, this.currImage);
                        this.CalculateCurrRectangle(this.animationCurrRectangle, this.width, this.height, this.currImage);
                        this.CalculateCurrRectangle(this.animationNewCurrRectangle, this.width, this.height, this.prevImage);
                        this.CalculateNextRectangle(this.animationNextRectangle, this.width, this.height, this.prevImage, this.currImage);
                    }
                    else {
                        this.EndAnimationPrev();
                    }
                }
            };
            ImageStrip.prototype.NextButtonClicked = function () {
                if (this.nextImage != null && this.nextImage.width > 0) {
                    var newIndex = this.currIndex + 2;
                    if (newIndex < this.imagePaths.length) {
                        this.newImage = new Image();
                        this.newImage.src = this.imagePaths[newIndex];
                    }
                    else {
                        this.newImage = null;
                    }
                    if (Web.Renderer.AverageFrameRateOk) {
                        this.animationProgress = 1;
                        this.animatingToNext = true;
                        this.CalculatePrevRectangle(this.animationPrevRectangle, this.width, this.height, this.currImage, this.nextImage);
                        this.CalculateCurrRectangle(this.animationCurrRectangle, this.width, this.height, this.currImage);
                        this.CalculateCurrRectangle(this.animationNewCurrRectangle, this.width, this.height, this.nextImage);
                        this.CalculateNextRectangle(this.animationNextRectangle, this.width, this.height, this.currImage, this.nextImage);
                    }
                    else {
                        this.EndAnimationNext();
                    }
                }
            };
            ImageStrip.prototype.EndAnimationPrev = function () {
                this.currIndex--;
                this.nextImage = this.currImage;
                this.currImage = this.prevImage;
                this.prevImage = this.newImage;
                this.animatingToPrevious = false;
            };
            ImageStrip.prototype.EndAnimationNext = function () {
                this.currIndex++;
                this.prevImage = this.currImage;
                this.currImage = this.nextImage;
                this.nextImage = this.newImage;
                this.animatingToNext = false;
            };
            return ImageStrip;
        }(Web.AutoDrawingBase));
        Web.ImageStrip = ImageStrip;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var MouseClicks = /** @class */ (function (_super) {
            __extends(MouseClicks, _super);
            function MouseClicks(size, requirement, color, speed) {
                var _this = _super.call(this, size) || this;
                _this.clickedPoints = [];
                _this.animationProgress = [];
                _this.clickMaxRadius = 100;
                _this.color = color;
                _this.speed = speed;
                return _this;
            }
            Object.defineProperty(MouseClicks.prototype, "Color", {
                get: function () { return this.color; },
                set: function (value) { this.color = value; },
                enumerable: true,
                configurable: true
            });
            MouseClicks.prototype.Render = function (width, height) {
                //this.speed * Renderer.RenderDelta;
                var animatingColor = this.color.Clone();
                for (var iPoint = 0; iPoint < this.clickedPoints.length; iPoint++) {
                    var centerPoint = this.clickedPoints[iPoint];
                    var animProgress = this.animationProgress[iPoint];
                    var radius = Web.Renderer.Interpolate(0, this.clickMaxRadius, animProgress);
                    animatingColor.Alpha = Web.Renderer.Interpolate(1, 0, animProgress);
                    Web.Renderer.DrawCircle(centerPoint.x, centerPoint.y, radius, 2, animatingColor);
                    animProgress -= this.speed;
                    if (animProgress < 0) {
                        this.clickedPoints.splice(iPoint, 1);
                        this.animationProgress.splice(iPoint, 1);
                        iPoint--; // the next index will be the same as this one, since this one is deleted.
                    }
                    else {
                        this.animationProgress[iPoint] = animProgress;
                    }
                }
            };
            MouseClicks.prototype.HitTest = function (width, height, mouseEvent) {
                if (mouseEvent.buttons > 0 && mouseEvent.which == 1) {
                    var newPoint = new Web.Point(Web.Renderer.MouseX, Web.Renderer.MouseY);
                    if (this.clickedPoints.length == 0 || !this.clickedPoints[this.clickedPoints.length - 1].Equals(newPoint)) {
                        // Start a new animation, when the animationProgress reaches 0 the corresponding point and progress are removed.
                        this.clickedPoints.push(newPoint);
                        this.animationProgress.push(1);
                    }
                }
                return false;
            };
            return MouseClicks;
        }(Web.AutoDrawingBase));
        Web.MouseClicks = MouseClicks;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var ScrollImage = /** @class */ (function (_super) {
            __extends(ScrollImage, _super);
            function ScrollImage(size, requirement, imagePath, yCenterPositionPerctange, speed) {
                var _this = _super.call(this, size, requirement) || this;
                _this.imageWidth = 0;
                _this.xStart = 0;
                _this.yCenterPositionPerctange = (yCenterPositionPerctange >= 0 && yCenterPositionPerctange <= 1) ? yCenterPositionPerctange : .5;
                _this.speed = speed;
                _this.image = new Image();
                _this.image.onload = function () { return _this.ImageReady(); };
                _this.image.src = imagePath;
                return _this;
            }
            ScrollImage.prototype.ImageReady = function () {
                this.imageWidth = this.image.width;
            };
            ScrollImage.prototype.Render = function (width, height) {
                // Image loaded => imageWidth > 0
                if (this.imageWidth > 0) {
                    var centerY = height * this.yCenterPositionPerctange;
                    var halfWidth = this.imageWidth * .5;
                    var yPosition = centerY - halfWidth;
                    var x = width - this.xStart;
                    Web.Renderer.DrawImage(this.image, x, yPosition);
                    var xStep = this.speed * Web.Renderer.RenderDelta;
                    this.xStart += xStep;
                    x = width - this.xStart;
                    if (x + this.imageWidth < 0) {
                        this.xStart = 0; // Scroll went off screen and can restart
                    }
                }
            };
            return ScrollImage;
        }(Web.AutoDrawingBase));
        Web.ScrollImage = ScrollImage;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var ScrollText = /** @class */ (function (_super) {
            __extends(ScrollText, _super);
            function ScrollText(size, requirement, getColor, text, getFont, filled, yPositionPercentage, speed) {
                var _this = _super.call(this, size, requirement) || this;
                _this.smallerFontSet = false;
                _this.xStart = 0;
                _this.maxSize = size;
                _this.getColor = getColor;
                _this.text = text;
                _this.getFont = getFont;
                _this.font = getFont();
                _this.originalFontSize = _this.font.Size;
                _this.fontSizeRatio = (size != 0) ? _this.font.Size / size : 5;
                _this.filled = filled;
                _this.yPositionPercentage = (yPositionPercentage >= 0 && yPositionPercentage <= 1) ? yPositionPercentage : .5;
                _this.speed = speed;
                return _this;
            }
            ScrollText.prototype.MeasureDock = function (otherSize) {
                if (this.Dock == Web.GraphDocking.Bottom || this.Dock == Web.GraphDocking.Top) {
                    var maxHeight = Web.Renderer.Height * .05;
                    if (maxHeight < this.maxSize) {
                        this.font.Size = maxHeight * this.fontSizeRatio;
                        this.smallerFontSet = true;
                        return maxHeight;
                    }
                    else if (this.smallerFontSet) {
                        this.font.Size = this.originalFontSize;
                        this.smallerFontSet = false;
                    }
                }
                else if (this.Dock == Web.GraphDocking.Left || this.Dock == Web.GraphDocking.Right) {
                    var maxWidth = Web.Renderer.Width * .05;
                    if (maxWidth < this.maxSize) {
                        this.font.Size = maxWidth * this.fontSizeRatio;
                        this.smallerFontSet = true;
                        return maxWidth;
                    }
                    else if (this.smallerFontSet) {
                        this.font.Size = this.originalFontSize;
                        this.smallerFontSet = false;
                    }
                }
                return this.font.Size;
            };
            ScrollText.prototype.Render = function (width, height) {
                var x = width - this.xStart;
                var y = height * .5;
                var color = this.getColor();
                var textWidth = Web.Renderer.MeasureText(this.text, this.font).Width;
                Web.Renderer.DrawText(this.text, this.font, x, y, color, this.filled, Web.TextBaseline.middle);
                var xStep = this.speed * Web.Renderer.RenderDelta;
                this.xStart += xStep;
                if (x + textWidth < 0) {
                    this.xStart = 0; // Scroll went off screen and can restart
                }
            };
            return ScrollText;
        }(Web.AutoDrawingBase));
        Web.ScrollText = ScrollText;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var ArrayHelper = /** @class */ (function () {
            function ArrayHelper() {
            }
            ArrayHelper.Sum = function (values) {
                var total = 0;
                for (var iValue = 0; iValue < values.length; iValue++) {
                    total += values[iValue];
                }
                return total;
            };
            ArrayHelper.SumOf = function (values, getValue) {
                var total = 0;
                for (var iValue = 0; iValue < values.length; iValue++) {
                    total += getValue(values[iValue]);
                }
                return total;
            };
            ArrayHelper.Any = function (values, check) {
                for (var iValue = 0; iValue < values.length; iValue++) {
                    if (check(values[iValue])) {
                        return true;
                    }
                }
                return false;
            };
            ArrayHelper.Reverse = function (values) {
                var returnValues = [];
                for (var iValue = values.length - 1; iValue >= 0; iValue--) {
                    returnValues.push(values[iValue]);
                }
                return returnValues;
            };
            ArrayHelper.Copy = function (values) {
                var returnValues = [];
                for (var iValue = 0; iValue < values.length; iValue++) {
                    returnValues.push(values[iValue]);
                }
                return returnValues;
            };
            return ArrayHelper;
        }());
        Web.ArrayHelper = ArrayHelper;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var QuickSort = /** @class */ (function () {
            function QuickSort() {
            }
            QuickSort.Sort = function (array, less) {
                function Swap(i, j) {
                    var t = array[i];
                    array[i] = array[j];
                    array[j] = t;
                }
                function Quicksort(left, right) {
                    if (left < right) {
                        var pivot = array[left + Math.floor((right - right) / 2)];
                        var left_new = left;
                        var right_new = right;
                        do {
                            while (less(array[left_new], pivot)) {
                                left_new += 1;
                            }
                            while (less(pivot, array[right_new])) {
                                right_new -= 1;
                            }
                            if (left_new <= right_new) {
                                Swap(left_new, right_new);
                                left_new += 1;
                                right_new -= 1;
                            }
                        } while (left_new <= right_new);
                        Quicksort(left, right_new);
                        Quicksort(left_new, right);
                    }
                }
                Quicksort(0, array.length - 1);
            };
            QuickSort.SortDictionaryKeys = function (dictionary, less) {
                function Swap(i, j) {
                    var tkey = keys[i];
                    keys[i] = keys[j];
                    keys[j] = tkey;
                    var tvalue = values[i];
                    values[i] = values[j];
                    values[j] = tvalue;
                }
                function Quicksort(left, right) {
                    if (left < right) {
                        var pivot = keys[left + Math.floor((right - right) / 2)];
                        var left_new = left;
                        var right_new = right;
                        do {
                            while (less(keys[left_new], pivot)) {
                                left_new += 1;
                            }
                            while (less(pivot, keys[right_new])) {
                                right_new -= 1;
                            }
                            if (left_new <= right_new) {
                                Swap(left_new, right_new);
                                left_new += 1;
                                right_new -= 1;
                            }
                        } while (left_new <= right_new);
                        Quicksort(left, right_new);
                        Quicksort(left_new, right);
                    }
                }
                var keys = dictionary.Keys;
                var values = dictionary.Values;
                Quicksort(0, keys.length - 1);
            };
            QuickSort.SortDictionaryValues = function (dictionary, less) {
                function Swap(i, j) {
                    var tkey = keys[i];
                    keys[i] = keys[j];
                    keys[j] = tkey;
                    var tvalue = values[i];
                    values[i] = values[j];
                    values[j] = tvalue;
                }
                function Quicksort(left, right) {
                    if (left < right) {
                        var pivot = values[left + Math.floor((right - right) / 2)];
                        var left_new = left;
                        var right_new = right;
                        do {
                            while (less(values[left_new], pivot)) {
                                left_new += 1;
                            }
                            while (less(pivot, values[right_new])) {
                                right_new -= 1;
                            }
                            if (left_new <= right_new) {
                                Swap(left_new, right_new);
                                left_new += 1;
                                right_new -= 1;
                            }
                        } while (left_new <= right_new);
                        Quicksort(left, right_new);
                        Quicksort(left_new, right);
                    }
                }
                var keys = dictionary.Keys;
                var values = dictionary.Values;
                Quicksort(0, values.length - 1);
            };
            return QuickSort;
        }());
        Web.QuickSort = QuickSort;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="ArrayHelper.ts" />
/// <reference path="QuickSort.ts" />
/// <reference path="Interfaces/Action.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var List = /** @class */ (function () {
            function List() {
                this.values = [];
            }
            Object.defineProperty(List.prototype, "Count", {
                get: function () { return this.values.length; },
                enumerable: true,
                configurable: true
            });
            List.prototype.ToArray = function () {
                return Web.ArrayHelper.Copy(this.values);
            };
            List.prototype.Index = function (i) {
                return (i >= 0 && i < this.values.length) ? this.values[i] : null;
            };
            List.prototype.Add = function (value) {
                this.values.push(value);
            };
            List.prototype.AddRange = function (values) {
                for (var iValue = 0; iValue < values.length; iValue++) {
                    this.values.push(values[iValue]);
                }
            };
            List.prototype.Remove = function (value) {
                var index = this.values.indexOf(value, 0);
                if (index >= 0) {
                    this.values.splice(index, 1);
                }
            };
            List.prototype.Last = function () {
                return (this.values.length > 0) ? this.values[this.values.length - 1] : null;
            };
            List.prototype.Clear = function () {
                this.values = [];
            };
            List.prototype.Contains = function (value) {
                var index = this.values.indexOf(value, 0);
                return (index >= 0);
            };
            List.prototype.Sum = function (selector) {
                var total = 0;
                for (var iValue = 0; iValue < this.values.length; iValue++) {
                    total += selector(this.values[iValue]);
                }
                return total;
            };
            List.prototype.Sort = function (less) {
                Web.QuickSort.Sort(this.values, less);
            };
            List.prototype.Exists = function (check) {
                for (var iValue = 0; iValue < this.values.length; iValue++) {
                    var value = this.values[iValue];
                    if (check(value)) {
                        return true;
                    }
                }
                return false;
            };
            List.prototype.First = function (check) {
                for (var iValue = 0; iValue < this.values.length; iValue++) {
                    var value = this.values[iValue];
                    if (check(value)) {
                        return value;
                    }
                }
                return null;
            };
            List.prototype.Where = function (check) {
                var matchedValues = [];
                for (var iValue = 0; iValue < this.values.length; iValue++) {
                    var value = this.values[iValue];
                    if (check(value)) {
                        matchedValues.push(value);
                    }
                }
                return matchedValues;
            };
            List.prototype.Any = function (check) {
                for (var iValue = 0; iValue < this.values.length; iValue++) {
                    var value = this.values[iValue];
                    if (check(value)) {
                        return true;
                    }
                }
                return false;
            };
            List.prototype.ForEach = function (action) {
                for (var iValue = 0; iValue < this.values.length; iValue++) {
                    var value = this.values[iValue];
                    action(value);
                }
            };
            return List;
        }());
        Web.List = List;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var SetupControl = /** @class */ (function () {
            function SetupControl() {
            }
            Object.defineProperty(SetupControl, "ImageStrip", {
                get: function () {
                    return SetupControl.imageStrip;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SetupControl, "Slideshow", {
                set: function (value) {
                    SetupControl.slideshow = value;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SetupControl, "SlideshowRunning", {
                get: function () {
                    return (SetupControl.slideshow != null) ? SetupControl.slideshow.Running : false;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SetupControl, "Menu", {
                get: function () {
                    return SetupControl.menu;
                },
                enumerable: true,
                configurable: true
            });
            Object.defineProperty(SetupControl, "Document", {
                get: function () { return SetupControl.document; },
                enumerable: true,
                configurable: true
            });
            SetupControl.SendMail = function () {
                document.location.href = "mailto:erlend@erroba.be?subject="
                    + encodeURIComponent("Information request")
                    + "&body=" + encodeURIComponent("");
            };
            SetupControl.DownloadFile = function (path) {
                window.open(path);
            };
            SetupControl.Initialize = function (window, document) {
                //if (window.scrollbars != null)
                //{
                //    window.scrollbars.visible = false;
                //}
                var clientWidth = window.innerWidth;
                var clientHeight = window.innerHeight;
                var defaultTheme = new Web.Theme(new Web.Color(45, 45, 48, 1), new Web.Color(55, 55, 57, 1), new Web.Color(37, 37, 38, .9), new Web.Color(142, 142, 146, .9), new Web.Color(240, 200, 100, 1), Web.Renderer.ColorBlack, new Web.Color(255, 150, 0, 1), new Web.Color(200, 100, 0, 1), new Web.Color(0, 180, 0, 1), new Web.Color(240, 200, 100, 1), new Web.Color(230, 230, 230, .80), Web.Renderer.ColorWhite, new Web.Font("Montez", 30, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Montez", 24, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Arial", 15, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 24, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 12, Web.FontStyle.normal, Web.FontWeight.bold));
                var softwareTheme = new Web.Theme(new Web.Color(45, 85, 48, 1), new Web.Color(55, 95, 57, 1), new Web.Color(37, 87, 38, .9), new Web.Color(142, 192, 146, .9), new Web.Color(240, 250, 100, 1), Web.Renderer.ColorBlack, new Web.Color(150, 255, 0, 1), new Web.Color(100, 200, 0, 1), new Web.Color(0, 180, 0, 1), new Web.Color(100, 240, 100, 1), new Web.Color(230, 255, 230, .80), Web.Renderer.ColorWhite, new Web.Font("Exo", 30, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 24, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 15, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 24, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 12, Web.FontStyle.normal, Web.FontWeight.bold));
                var mathTheme = new Web.Theme(new Web.Color(40, 40, 40, 1), new Web.Color(47, 47, 47, 1), new Web.Color(80, 80, 80, .9), new Web.Color(130, 130, 130, .9), new Web.Color(220, 220, 220, 1), Web.Renderer.ColorBlack, new Web.Color(255, 155, 0, 1), new Web.Color(200, 100, 0, 1), new Web.Color(180, 100, 0, 1), new Web.Color(220, 220, 220, 1), new Web.Color(0, 0, 0, 1), Web.Renderer.ColorWhite, new Web.Font("Exo", 30, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 24, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 15, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 24, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 12, Web.FontStyle.normal, Web.FontWeight.bold));
                var contactTheme = new Web.Theme(new Web.Color(45, 48, 85, 1), new Web.Color(55, 55, 97, 1), new Web.Color(37, 38, 87, .9), new Web.Color(142, 146, 192, .9), new Web.Color(100, 240, 255, 1), Web.Renderer.ColorBlack, new Web.Color(0, 150, 255, 1), new Web.Color(0, 100, 200, 1), new Web.Color(0, 0, 180, 1), new Web.Color(100, 100, 240, 1), new Web.Color(230, 230, 255, .80), Web.Renderer.ColorWhite, new Web.Font("Montez", 30, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Montez", 24, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Exo", 15, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Montez", 24, Web.FontStyle.normal, Web.FontWeight.bold), new Web.Font("Montez", 12, Web.FontStyle.normal, Web.FontWeight.bold));
                var radiate = new Web.Radiate(0, Web.Requirement.Optional, function () { return Web.Renderer.ThemeManager.CurrentTheme.BackgroundColorHighlight; }, 12, .005);
                radiate.Dock = Web.GraphDocking.Background;
                radiate.DockStack = Web.Renderer.NextDockStack(radiate);
                Web.Renderer.AddAutoDrawing(radiate);
                var binaryRain = new Web.BinaryRain(Web.Requirement.Optional, .05, 3, 142, 7, 40, function () { return Web.Renderer.ThemeManager.CurrentTheme.MessageFont; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.MessageColor; });
                binaryRain.Dock = Web.GraphDocking.Background;
                binaryRain.DockStack = Web.Renderer.NextDockStack(binaryRain);
                binaryRain.Active = false;
                Web.Renderer.AddAutoDrawing(binaryRain);
                var waves = new Web.Waves(Web.Requirement.Optional, 2, 80, 12, function () { return Web.Renderer.ThemeManager.CurrentTheme.MessageColor; }, true);
                waves.Dock = Web.GraphDocking.Background;
                waves.DockStack = Web.Renderer.NextDockStack(waves);
                waves.Active = false;
                Web.Renderer.AddAutoDrawing(waves);
                mathTheme.StartThemeAction = function () {
                    waves.Active = true;
                    binaryRain.Active = false;
                };
                softwareTheme.StartThemeAction = function () {
                    binaryRain.Active = true;
                    waves.Active = false;
                };
                defaultTheme.StartThemeAction = function () {
                    binaryRain.Active = false;
                    waves.Active = false;
                };
                contactTheme.StartThemeAction = function () {
                    binaryRain.Active = false;
                    waves.Active = false;
                };
                var themeManager = new Web.ThemeManager(defaultTheme);
                themeManager.AddTheme(SetupControl.ThemeSoftware, softwareTheme);
                themeManager.AddTheme(SetupControl.ThemeContact, contactTheme);
                themeManager.AddTheme(SetupControl.ThemeMath, mathTheme);
                var canvas = document.getElementById('MainCanvas');
                Web.Renderer.Initialize(document, window, canvas, themeManager);
                Web.Renderer.ResizeCanvas(clientWidth, clientHeight);
                var topArea = new Web.Area(50, Web.Requirement.Mandatory, function () { return Web.Renderer.ThemeManager.CurrentTheme.SectionBackgroundColor; });
                topArea.Dock = Web.GraphDocking.Top;
                topArea.DockStack = Web.Renderer.NextDockStack(topArea);
                Web.Renderer.AddAutoDrawing(topArea);
                var topMenuArea = new Web.Area(40, Web.Requirement.Mandatory, function () { return Web.Renderer.ThemeManager.CurrentTheme.SectionBackgroundColor; });
                topMenuArea.Dock = Web.GraphDocking.Top;
                topMenuArea.DockStack = Web.Renderer.NextDockStack(topMenuArea);
                Web.Renderer.AddAutoDrawing(topMenuArea);
                this.title = new Web.Title(40, Web.Requirement.Mandatory, function () { return Web.Renderer.ThemeManager.CurrentTheme.TitleColor; }, "Space, the final frontier...", function () { return Web.Renderer.ThemeManager.CurrentTheme.PageTitleFont; }, true, 0, 30, .002);
                this.title.Dock = Web.GraphDocking.Top;
                this.title.DockStack = topArea.DockStack;
                this.title.Layer = 1;
                Web.Renderer.AddAutoDrawing(this.title);
                var menuItems = [];
                var subMenuItems = [];
                subMenuItems.push(new Web.MenuItem("People", [], SetupControl.SetMenuPeople));
                subMenuItems.push(new Web.MenuItem("Weddings", [], SetupControl.SetMenuWeddings));
                subMenuItems.push(new Web.MenuItem("Animals", [], SetupControl.SetMenuAnimals));
                subMenuItems.push(new Web.MenuItem("Cityscapes", [], SetupControl.SetMenuCityscapes));
                subMenuItems.push(new Web.MenuItem("Landscapes", [], SetupControl.SetMenuLandscapes));
                subMenuItems.push(new Web.MenuItem("Macro", [], SetupControl.SetMenuMacro));
                subMenuItems.push(new Web.MenuItem("Special-fx", [], SetupControl.SetMenuSpecialFx));
                menuItems.push(new Web.MenuItem("Photography", subMenuItems, SetupControl.SetMenuPhotography));
                menuItems.push(new Web.MenuItem("Math", [], SetupControl.SetMenuMath));
                var artMenuItems = [];
                artMenuItems.push(new Web.MenuItem("Spirals", [], SetupControl.SetMenuSpirals));
                artMenuItems.push(new Web.MenuItem("Mdf-Cutouts", [], SetupControl.SetMenuMdf));
                artMenuItems.push(new Web.MenuItem("Paintings", [], SetupControl.SetMenuPaintings));
                artMenuItems.push(new Web.MenuItem("Wall-Art", [], SetupControl.SetMenuWallArt));
                menuItems.push(new Web.MenuItem("Art", artMenuItems, SetupControl.SetMenuArt));
                menuItems.push(new Web.MenuItem("Logos", [], SetupControl.SetMenuLogos));
                menuItems.push(new Web.MenuItem("Software", [], SetupControl.SetMenuSoftware));
                menuItems.push(new Web.MenuItem("Contact", [], SetupControl.SetMenuContact));
                SetupControl.menu = new Web.Menu(40, Web.Requirement.Mandatory, function () { return Web.Renderer.ThemeManager.CurrentTheme.MenuFont; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.TitleColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.SelectedColor; }, menuItems);
                SetupControl.menu.Dock = Web.GraphDocking.Top;
                SetupControl.menu.DockStack = topMenuArea.DockStack;
                SetupControl.menu.Layer = topMenuArea.Layer + 1;
                Web.Renderer.AddAutoDrawing(SetupControl.menu);
                var bottom = new Web.Area(40, Web.Requirement.Mandatory, function () { return Web.Renderer.ThemeManager.CurrentTheme.SectionBackgroundColor; });
                bottom.Dock = Web.GraphDocking.Bottom;
                bottom.DockStack = Web.Renderer.NextDockStack(bottom);
                Web.Renderer.AddAutoDrawing(bottom);
                var someText = new Web.ScrollText(35, Web.Requirement.NiceToHave, function () { return Web.Renderer.ThemeManager.CurrentTheme.MessageColor; }, "© Copyright 2015-2021, Coding, Design & all content by Erlend Robaye, all rights reserved.", function () { return Web.Renderer.ThemeManager.CurrentTheme.MenuFont; }, true, .15, .02);
                someText.Dock = Web.GraphDocking.Bottom;
                someText.DockStack = bottom.DockStack;
                someText.Layer = Web.Renderer.TopLayer;
                Web.Renderer.AddAutoDrawing(someText);
                var backgroundImage = new Web.BackgroundImage(0, Web.Requirement.Optional, "Images/Erroba.png", 0, 0);
                backgroundImage.Dock = Web.GraphDocking.CenterNumpad1;
                backgroundImage.DockStack = 0;
                Web.Renderer.AddAutoDrawing(backgroundImage);
                var clock = new Web.Clock(Web.Requirement.Optional, 30, 10, 0, function () { return Web.Renderer.ThemeManager.CurrentTheme.BackgroundColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.GlossColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.TitleColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.ActionColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.MessageColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.BackgroundColorHighlight; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.MessageColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.TitleColor; }, Web.GraphDocking.Bottom);
                clock.Dock = Web.GraphDocking.Overlay;
                clock.DockStack = 0;
                Web.Renderer.AddAutoDrawing(clock);
                var mouseClicks = new Web.MouseClicks(0, Web.Requirement.Optional, new Web.Color(200, 100, 0, 1), .005);
                mouseClicks.Dock = Web.GraphDocking.Overlay;
                mouseClicks.DockStack = 0;
                Web.Renderer.AddAutoDrawing(mouseClicks);
                var imageUrls = [];
                var imageTitles = [];
                SetupControl.imageStrip = new Web.ImageStrip(0, Web.Requirement.Mandatory, imageUrls, imageTitles, null, .5, function () { return Web.Renderer.ThemeManager.CurrentTheme.FrameColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.BackgroundColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.FrameColor; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.ArtTitleFont; }, function () { return Web.Renderer.ThemeManager.CurrentTheme.FrameColor; }, .01, SetupControl.menu.NextMenuItem, SetupControl.menu.PrevMenuItem);
                SetupControl.imageStrip.Dock = Web.GraphDocking.Center;
                SetupControl.imageStrip.DockStack = 0;
                SetupControl.imageStrip.Layer = Web.Renderer.TopLayer;
                // Set first menu that sets imageStrip
                subMenuItems[0].clickedMenu(subMenuItems[0]);
                Web.Renderer.AddAutoDrawing(SetupControl.imageStrip);
                var progressCircle = new Web.ProgressCircle(Web.Requirement.Mandatory, 27, 27, 25, 20, Web.Renderer.ColorBlack, new Web.Color(0, 180, 0, 1));
                progressCircle.Dock = Web.GraphDocking.Center;
                progressCircle.DockStack = 0;
                progressCircle.Layer = Web.Renderer.TopLayer;
                Web.Renderer.AddAutoDrawing(progressCircle);
                var slideshow = new Web.Slideshow(0, Web.Requirement.Mandatory, 5, progressCircle, SetupControl.imageStrip.NextImage, SetupControl.menu.NextMenuItem, new Web.Color(255, 150, 0, 1), function () { return Web.Renderer.ThemeManager.CurrentTheme.MenuFont; });
                slideshow.Dock = Web.GraphDocking.Center;
                slideshow.DockStack = 0;
                slideshow.Layer = Web.Renderer.TopLayer;
                Web.Renderer.AddAutoDrawing(slideshow);
                SetupControl.Slideshow = slideshow;
                //var fps = new Fps(Requirement.NiceToHave, 3, 3, Renderer.ColorWhite, Align.BottomLeft, "Exo", "normal", "bold", 12);
                //fps.Dock = GraphDocking.Center;
                //fps.DockStack = 0;
                //fps.Layer = Renderer.TopLayer;
                //Renderer.AddAutoDrawing(fps);
            };
            SetupControl.SetMenuPhotography = function (menuItem) {
                if (menuItem.subMenuItems.length > 0) {
                    var subMenuItem = menuItem.subMenuItems[0];
                    subMenuItem.clickedMenu(subMenuItem);
                }
                SetupControl.title.Text = menuItem.menuText;
            };
            SetupControl.SetMenuAnimals = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Photography/Animals/RedFlamigoPeekaboo.jpg");
                imageUrls.push("Images/Photography/Animals/WhiteTigerYawn.jpg");
                imageUrls.push("Images/Photography/Animals/PelicanCloseup.jpg");
                imageUrls.push("Images/Photography/Animals/Zebra_hug.jpg");
                imageUrls.push("Images/Photography/Animals/GreenYellowParakeet.jpg");
                imageUrls.push("Images/Photography/Animals/MexicanMilataryMacawsGossip.jpg");
                imageUrls.push("Images/Photography/Animals/Parakeet.jpg");
                imageUrls.push("Images/Photography/Animals/Pelican.jpg");
                imageUrls.push("Images/Photography/Animals/RingstaartMakiCloseup.jpg");
                imageUrls.push("Images/Photography/Animals/ZebraBacks.jpg");
                imageUrls.push("Images/Photography/Animals/ZebraPano.jpg");
                imageUrls.push("Images/Photography/Animals/ZebraTwinsDrinking.jpg");
                imageUrls.push("Images/Photography/Animals/Cheetah.jpg");
                imageUrls.push("Images/Photography/Animals/ElephantDrinking.jpg");
                imageUrls.push("Images/Photography/Animals/ElephantTail.jpg");
                imageUrls.push("Images/Photography/Animals/IncaSternInFlight.jpg");
                imageUrls.push("Images/Photography/Animals/KoalaLook.jpg");
                imageUrls.push("Images/Photography/Animals/Boliviaans doodshoofdaapje_duo_TwistedTails.jpg");
                imageUrls.push("Images/Photography/Animals/ElephantsHeadToHead.jpg");
                imageUrls.push("Images/Photography/Animals/Takin.jpg");
                imageUrls.push("Images/Photography/Animals/ZebraLook.jpg");
                imageUrls.push("Images/Photography/Animals/lionness.jpg");
                imageUrls.push("Images/Photography/Animals/Venice_SmallWhiteHeron.jpg");
                imageUrls.push("Images/Photography/Animals/RhinoEye.jpg");
                imageTitles.push("Red Flamigo Peekaboo");
                imageTitles.push("White Tiger Yawn");
                imageTitles.push("Pelican closeup");
                imageTitles.push("Zebra hug");
                imageTitles.push("Green Yellow Parakeet");
                imageTitles.push("Mexican Milatary Macaws Gossip");
                imageTitles.push("Parakeet");
                imageTitles.push("Pelican");
                imageTitles.push("Ring tailed lemur");
                imageTitles.push("Zebra backs");
                imageTitles.push("Zebra Pano");
                imageTitles.push("Zebra Twins");
                imageTitles.push("Cheetah");
                imageTitles.push("Elephant drinking");
                imageTitles.push("Elephant tail");
                imageTitles.push("Inca stern in flight");
                imageTitles.push("Koala look");
                imageTitles.push("Saimiri boliviensis");
                imageTitles.push("Elephants head to head");
                imageTitles.push("Takin");
                imageTitles.push("Zebra look");
                imageTitles.push("Lionness");
                imageTitles.push("White Heron");
                imageTitles.push("Rhino Eye");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuCityscapes = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Photography/Cityscapes/BerlinDomeTop.jpg");
                imageUrls.push("Images/Photography/Cityscapes/BerlinCartier206.jpg");
                imageUrls.push("Images/Photography/Cityscapes/BelfortVanopRozenhoedkaaiMiniPano.jpg");
                imageUrls.push("Images/Photography/Cityscapes/Venice_BoatInSunsetOnCanalDiCannaregio.jpg");
                imageUrls.push("Images/Photography/Cityscapes/Venice_CanalDiCannaregio_Sunset_Speedboat.jpg");
                imageUrls.push("Images/Photography/Cityscapes/Venice_LanternLionAndSanGeorgiosTower.jpg");
                imageUrls.push("Images/Photography/Cityscapes/Venice_NightViewFromRialtoBridge_Squared.jpg");
                imageUrls.push("Images/Photography/Cityscapes/Venice_PonteDellaConstituzione_WalkingToTheSky.jpg");
                imageUrls.push("Images/Photography/Cityscapes/Venice_SanGeorgioWithGondolaVertorama.jpg");
                imageUrls.push("Images/Photography/Cityscapes/Venice_SantaMariaDellaSaluteCloseUpAsSeenFromTheCampanilleSmallPanorama.jpg");
                imageUrls.push("Images/Photography/Cityscapes/VeniceViewFromTheHotelTerras.jpg");
                imageUrls.push("Images/Photography/Cityscapes/GroteMarktKatedraal.jpg");
                imageUrls.push("Images/Photography/Cityscapes/MechelenGroteMarkt21Juli_2.jpg");
                imageUrls.push("Images/Photography/Cityscapes/MechelenStadhuis.jpg");
                imageUrls.push("Images/Photography/Cityscapes/TunnelUnderE19.jpg");
                imageUrls.push("Images/Photography/Cityscapes/RedMysteryInBruges.jpg");
                imageUrls.push("Images/Photography/Cityscapes/BruggeTowardsTheWindmill_1.jpg");
                imageUrls.push("Images/Photography/Cityscapes/GrasleiEveningLight.jpg");
                imageUrls.push("Images/Photography/Cityscapes/GrasleiKorenLeiTowardsHooiaard.jpg");
                imageUrls.push("Images/Photography/Cityscapes/SintMichielsKerkAtNight.jpg");
                imageUrls.push("Images/Photography/Cityscapes/SintNiklaaskerkFromTheBelfry.jpg");
                imageUrls.push("Images/Photography/Cityscapes/DriveMeThroughParisPlease.jpg");
                imageUrls.push("Images/Photography/Cityscapes/EiffelTowerFromTrocaderoInTheRain.jpg");
                imageUrls.push("Images/Photography/Cityscapes/EiffelTowerPontdLena.jpg");
                imageUrls.push("Images/Photography/Cityscapes/EiffelTowerViewTowardsTourMontparnasse.jpg");
                imageUrls.push("Images/Photography/Cityscapes/GaleriesLafayetteDome_I.jpg");
                imageUrls.push("Images/Photography/Cityscapes/TraforoUmbertoI.jpg");
                imageUrls.push("Images/Photography/Cityscapes/TopOfTheCentralDomeOfSaintPietersBasilica.jpg");
                imageUrls.push("Images/Photography/Cityscapes/SantAgneseInAgone.jpg");
                imageUrls.push("Images/Photography/Cityscapes/MetropolParasol_VII.jpg");
                imageUrls.push("Images/Photography/Cityscapes/BattleStarGallactica.jpg");
                imageUrls.push("Images/Photography/Cityscapes/ColourfulRibs.jpg");
                imageUrls.push("Images/Photography/Cityscapes/FlyOver.jpg");
                imageUrls.push("Images/Photography/Cityscapes/KraanbrugViewOnLamot.jpg");
                imageUrls.push("Images/Photography/Cityscapes/LamotReprocessed_II.jpg");
                imageUrls.push("Images/Photography/Cityscapes/UnderTheBridgeReworked.jpg");
                imageTitles.push("Berlin Reichstag dome");
                imageTitles.push("Berlin Cartier 206");
                imageTitles.push("Belfort of Bruges");
                imageTitles.push("Venice - Boat sunset on Canal Di Cannaregio");
                imageTitles.push("Venice - Canal Di Cannaregio, speedboat sunset");
                imageTitles.push("Venice - Lantern, Lion and San Georgios tower");
                imageTitles.push("Venice - Night view from Rialto bridge.");
                imageTitles.push("Venice - Ponte della Constituzione - Walking in the Sky");
                imageTitles.push("Venice - San Georgio with gondola.");
                imageTitles.push("Venice - Santa Maria della Salute.");
                imageTitles.push("Venice - View from a hotel terras.");
                imageTitles.push("Grand Place and Cathedral, Mechelen - Belgium.");
                imageTitles.push("Fireworks on Grand Place and Cathedral, Mechelen - Belgium");
                imageTitles.push("City Hall, Mechelen - Belgium");
                imageTitles.push("Tunnel under the highway.");
                imageTitles.push("Red mystery in Bruges");
                imageTitles.push("Towards the Windmill, Bruges");
                imageTitles.push("Graslei, evening light, Ghent - Belgium");
                imageTitles.push("Graslei-Korenlei towards Hooiaard, Ghent - Belgium");
                imageTitles.push("Saint Michael's church at night, Ghent - Belgium");
                imageTitles.push("Church of Saint Nicolas as seen from the belfry, , Ghent - Belgium");
                imageTitles.push("Drive me trough Paris");
                imageTitles.push("Eiffel tower as see from the Trocadero.");
                imageTitles.push("Eiffel tower - Pont d'Lena");
                imageTitles.push("Eiffel tower - View towards Tour Montparnasse");
                imageTitles.push("Galeries Lafayette");
                imageTitles.push("Traforo Umberto I, Rome");
                imageTitles.push("Top of the central dome of Saint Pieters Basilica");
                imageTitles.push("Sant Agnese In Agone, Rome");
                imageTitles.push("Metropol Parasol, Sevilla");
                imageTitles.push("Battle Star Gallactica, Liège - Belgium");
                imageTitles.push("Colourful ribs, Liège - Belgium");
                imageTitles.push("Fly Over");
                imageTitles.push("Kraanbrug view on Lamot, Mechelen - Belgium.");
                imageTitles.push("Lamot");
                imageTitles.push("Under the bridge");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuLandscapes = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_036.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_044.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_046.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_085.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_088.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_116.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_118.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_120.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_125.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_147.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_150.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_153.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_159.jpg");
                imageUrls.push("Images/Photography/Landscapes/Terschelling2021_161.jpg");
                imageUrls.push("Images/Photography/Landscapes/Kreta_MilkySunriseAtTheJetty.jpg");
                imageUrls.push("Images/Photography/Landscapes/Kreta_SunriseAtTheJetty.jpg");
                imageUrls.push("Images/Photography/Landscapes/Kreta_SunriseAtTheRocks.jpg");
                imageUrls.push("Images/Photography/Landscapes/KretaGolfVanMirabelloRoad.jpg");
                imageUrls.push("Images/Photography/Landscapes/MistySunriseCornfieldTracks.jpg");
                imageUrls.push("Images/Photography/Landscapes/Etretat.jpg");
                imageUrls.push("Images/Photography/Landscapes/LineInTheGrassSunriseReprocessed.jpg");
                imageUrls.push("Images/Photography/Landscapes/SunriseAboveTheBrookUnderTheTrees.jpg");
                imageUrls.push("Images/Photography/Landscapes/MistySunriseLineOfTreesReflection.jpg");
                imageUrls.push("Images/Photography/Landscapes/MistySunriseLineOfWillowsAndRiver.jpg");
                imageUrls.push("Images/Photography/Landscapes/MistySunriseRiverBendHorizontal.jpg");
                imageUrls.push("Images/Photography/Landscapes/MistySunriseRiverFence.jpg");
                imageUrls.push("Images/Photography/Landscapes/MistySunriseTheLonelyTree.jpg");
                imageUrls.push("Images/Photography/Landscapes/DiagonalSunset.jpg");
                imageUrls.push("Images/Photography/Landscapes/Twins.jpg");
                imageUrls.push("Images/Photography/Landscapes/EnchantedForest.jpg");
                imageUrls.push("Images/Photography/Landscapes/HallerbosCroporamaAt2.8.jpg");
                imageUrls.push("Images/Photography/Landscapes/HallerbosFallen.jpg");
                imageUrls.push("Images/Photography/Landscapes/HallerbosTranendal_ZigZag.jpg");
                imageUrls.push("Images/Photography/Landscapes/MalakoffTowerAndTree.jpg");
                imageUrls.push("Images/Photography/Landscapes/ShedThatWinterDress.jpg");
                imageUrls.push("Images/Photography/Landscapes/Hallerbos2015_Sunlight_DigitalBlend.jpg");
                imageUrls.push("Images/Photography/Landscapes/Hallerbos2015_ThePathHorizontal.jpg");
                imageUrls.push("Images/Photography/Landscapes/sunriseoversnowypath.jpg");
                imageUrls.push("Images/Photography/Landscapes/lockedinwinter.jpg");
                imageUrls.push("Images/Photography/Landscapes/DePlasSunsetLights.jpg");
                imageUrls.push("Images/Photography/Landscapes/LeuvensVaartReworked_II.jpg");
                imageUrls.push("Images/Photography/Landscapes/sunshinethroughtrees_Reprocessed.jpg");
                imageTitles.push("Terschelling Wet Beach");
                imageTitles.push("Terschelling Sunset Reflections");
                imageTitles.push("Terschelling Sunset beach lines");
                imageTitles.push("Terschelling Sheep, 3 different ones");
                imageTitles.push("Terschelling Bakfiets");
                imageTitles.push("Terschelling Tracks in the sand");
                imageTitles.push("Terschelling Lifeguard");
                imageTitles.push("Terschelling Sail carts");
                imageTitles.push("Terschelling Clouds");
                imageTitles.push("Terschelling Windy beach");
                imageTitles.push("Terschelling Wet shore line");
                imageTitles.push("Terschelling Driftwood");
                imageTitles.push("Terschelling Clouds above the harbour");
                imageTitles.push("Terschelling Clouds above the harbour B&W");
                imageTitles.push("Milky sunrise at the jetty - Crete");
                imageTitles.push("Sunrise at the jetty - Crete");
                imageTitles.push("Sunrise at the rocks - Crete");
                imageTitles.push("Golf of Mirabello Road - Crete");
                imageTitles.push("MistySunrise in a cornfield");
                imageTitles.push("Etretat");
                imageTitles.push("Line in the grass");
                imageTitles.push("Sunrise under the trees");
                imageTitles.push("Line of trees");
                imageTitles.push("Line of willows");
                imageTitles.push("River bend");
                imageTitles.push("River fence");
                imageTitles.push("The lonely tree");
                imageTitles.push("Diagonal sunset");
                imageTitles.push("Twins");
                imageTitles.push("Enchanted forest");
                imageTitles.push("Hallerbos croporama");
                imageTitles.push("Fallen");
                imageTitles.push("Hallerbos - Valley of tears");
                imageTitles.push("Malakoff tower and tree");
                imageTitles.push("Shed that winter dress");
                imageTitles.push("Hallerbos sunlight");
                imageTitles.push("Hallerbos - The path");
                imageTitles.push("Sunrise over snowy path");
                imageTitles.push("Locked in winter");
                imageTitles.push("Sunset Lights");
                imageTitles.push("Perspective");
                imageTitles.push("Sunshine through the trees");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuMacro = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Photography/Macro/SliceOfYellowKiwi.jpg");
                imageUrls.push("Images/Photography/Macro/BirthOfTheMultiverse.jpg");
                imageUrls.push("Images/Photography/Macro/GlassDots.jpg");
                imageUrls.push("Images/Photography/Macro/DandelionDewDrops.jpg");
                imageUrls.push("Images/Photography/Macro/MicroLedBulb.jpg");
                imageUrls.push("Images/Photography/Macro/MyEyeBW.jpg");
                imageUrls.push("Images/Photography/Macro/Duvelscape.jpg");
                imageUrls.push("Images/Photography/Macro/Duvel_2.jpg");
                imageUrls.push("Images/Photography/Macro/Glowing.jpg");
                imageUrls.push("Images/Photography/Macro/BigDropWithLittleFly.jpg");
                imageUrls.push("Images/Photography/Macro/Ignition_III.jpg");
                imageUrls.push("Images/Photography/Macro/MeiKever.jpg");
                imageUrls.push("Images/Photography/Macro/beeonlavenderflower.jpg");
                imageTitles.push("Slice of Kiwi");
                imageTitles.push("Birth of the Multiverse");
                imageTitles.push("Glass Dots");
                imageTitles.push("Dandelion Dew Drops");
                imageTitles.push("Micro-Led Bulb");
                imageTitles.push("My eye");
                imageTitles.push("Duvelscape");
                imageTitles.push("Duvel");
                imageTitles.push("Glowing");
                imageTitles.push("Where is my morning drink?");
                imageTitles.push("Ignition");
                imageTitles.push("Cockchafer");
                imageTitles.push("Bee on lavender flower");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuPeople = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Photography/People/YanaBlueEyes.jpg");
                imageTitles.push("Yana's blue eyes");
                imageUrls.push("Images/Photography/People/EllaAndYana.jpg");
                imageTitles.push("Ella & Yana");
                imageUrls.push("Images/Photography/People/YanaSunhat.jpg");
                imageTitles.push("Yana with sun hat");
                imageUrls.push("Images/Photography/People/ShaunyCabrio.jpg");
                imageTitles.push("Shauny in Cabrio");
                imageUrls.push("Images/Photography/People/EllaIcecream.jpg");
                imageTitles.push("Ella with icecream");
                imageUrls.push("Images/Photography/People/ShaunyBlossem.jpg");
                imageTitles.push("Shauny with tree blossem");
                imageUrls.push("Images/Photography/People/YanaWetLook.jpg");
                imageTitles.push("Yana's wet look");
                imageUrls.push("Images/Photography/People/ShaunyUmbrella.jpg");
                imageTitles.push("Shauny with umbrella");
                imageUrls.push("Images/Photography/People/EllaMermaid.jpg");
                imageTitles.push("Ella as Daryl Hannah");
                imageUrls.push("Images/Photography/People/ShaunyRedFlowers.jpg");
                imageTitles.push("Shauny with red flowers");
                imageUrls.push("Images/Photography/People/YanaAndMMs.jpg");
                imageTitles.push("Yana and M&M's");
                imageUrls.push("Images/Photography/People/EllasLovesStrawberries.jpg");
                imageTitles.push("Ellas Loves Strawberries");
                imageUrls.push("Images/Photography/People/YanaAndHerTablet.jpg");
                imageTitles.push("Yana and her tablet");
                imageUrls.push("Images/Photography/People/EllaEveningSun.jpg");
                imageTitles.push("Ella in evening sun");
                imageUrls.push("Images/Photography/People/YanaFlowers.jpg");
                imageTitles.push("Yana in a bed of flowers");
                imageUrls.push("Images/Photography/People/YanaRoses.jpg");
                imageTitles.push("Yana with roses");
                imageUrls.push("Images/Photography/People/YanaPoppies.jpg");
                imageTitles.push("Yana with poppies");
                imageUrls.push("Images/Photography/People/YanaYellowFlowers.jpg");
                imageTitles.push("Yana with yellow flowers");
                imageUrls.push("Images/Photography/People/EllaWhiteFlower.jpg");
                imageTitles.push("Ella with white flowers");
                imageUrls.push("Images/Photography/People/EllaBamboo.jpg");
                imageTitles.push("Ella in Bamboo field");
                imageUrls.push("Images/Photography/People/EllaSwing.jpg");
                imageTitles.push("Ella swings her hair");
                imageUrls.push("Images/Photography/People/EllaYellowFlowers.jpg");
                imageTitles.push("Ella with yellow flowers");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuWeddings = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0119.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0191.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0211.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0474.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0507.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0519.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0560.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0567.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0575.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0584.jpg");
                imageUrls.push("Images/Photography/Weddings/Karlien_Marijn_0690.jpg");
                imageUrls.push("Images/Photography/Weddings/Sharah_Tom_085.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_003.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_027.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_107.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_120.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_153.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_186.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_221.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_233.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_252.jpg");
                imageUrls.push("Images/Photography/Weddings/Nele_Pieter_254.jpg");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Karlien & Marijn");
                imageTitles.push("Sharah & Tom");
                imageTitles.push("Nele & Pieter");
                imageTitles.push("Nele & Pieter");
                imageTitles.push("Nele & Pieter");
                imageTitles.push("Nele & Pieter");
                imageTitles.push("Nele & Pieter");
                imageTitles.push("Nele & Pieter");
                imageTitles.push("Nele & Pieter");
                imageTitles.push("Nele & Pieter");
                imageTitles.push("Nele & Pieter");
                imageTitles.push("Nele & Pieter");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuSpecialFx = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Photography/SpecialFx/ThumbleDryer.jpg");
                imageUrls.push("Images/Photography/SpecialFx/bendingthespoonii.jpg");
                imageUrls.push("Images/Photography/SpecialFx/FireCroporama.jpg");
                imageUrls.push("Images/Photography/SpecialFx/Amnesia.jpg");
                imageUrls.push("Images/Photography/SpecialFx/AnyShapeYouLike.jpg");
                imageUrls.push("Images/Photography/SpecialFx/BigBenTiltShift.jpg");
                imageUrls.push("Images/Photography/SpecialFx/closeencountersii.jpg");
                imageUrls.push("Images/Photography/SpecialFx/counting_sheep.jpg");
                imageUrls.push("Images/Photography/SpecialFx/delicateLungs.jpg");
                imageUrls.push("Images/Photography/SpecialFx/deliciousbalance.jpg");
                imageUrls.push("Images/Photography/SpecialFx/DewDream.jpg");
                imageUrls.push("Images/Photography/SpecialFx/FrozenInTime.jpg");
                imageUrls.push("Images/Photography/SpecialFx/Fusing.jpg");
                imageUrls.push("Images/Photography/SpecialFx/GhostTrain_GradientMaps.jpg");
                imageUrls.push("Images/Photography/SpecialFx/MakeMeBreath.jpg");
                imageUrls.push("Images/Photography/SpecialFx/practisingmyknifeskills_balancing.jpg");
                imageUrls.push("Images/Photography/SpecialFx/themysterydrink.jpg");
                imageUrls.push("Images/Photography/SpecialFx/ufo.jpg");
                imageUrls.push("Images/Photography/SpecialFx/WhatGoodIsAPhoneCallIfYouAreUnableToSpeak.jpg");
                imageUrls.push("Images/Photography/SpecialFx/Zebraman.jpg");
                imageUrls.push("Images/Photography/SpecialFx/BrightIdea_II.jpg");
                imageTitles.push("Thumble Dryer");
                imageTitles.push("Bending the spoon.");
                imageTitles.push("Fire croporama");
                imageTitles.push("Amnesia");
                imageTitles.push("Bake'em any shape you like");
                imageTitles.push("Big Ben - Tilt shift");
                imageTitles.push("Close encounters (2)");
                imageTitles.push("Counting sheep");
                imageTitles.push("Delicate lungs");
                imageTitles.push("Delicious balance");
                imageTitles.push("Dew dream");
                imageTitles.push("Frozen in time");
                imageTitles.push("She & Me fusing");
                imageTitles.push("Ghost train");
                imageTitles.push("Make me breath");
                imageTitles.push("Practising my knife skills");
                imageTitles.push("The mystery drink");
                imageTitles.push("U.F.O.");
                imageTitles.push("What good is a phone call if you are unable to speak");
                imageTitles.push("Zebraman");
                imageTitles.push("Bright idea");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuMath = function (menuItem) {
                SetupControl.title.Text = menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Math/SintRoumboutsNisSpiralSpaceEightAndTwoSmall.jpg");
                imageUrls.push("Images/Math/SintRoumboutsNisDoubleSpiralOne.jpg");
                imageUrls.push("Images/Math/SatanSimpleSpiral.jpg");
                imageUrls.push("Images/Math/SintRomboutsNisHolomorphicSixFold.jpg");
                imageUrls.push("Images/Math/SatansPit.jpg");
                imageUrls.push("Images/Math/SintRomboutsNisGlassRosetteAndCorridors.jpg");
                imageUrls.push("Images/Math/SatansPentagram.jpg");
                imageUrls.push("Images/Math/LeuvenWindowCircularSkyscraper.jpg");
                imageUrls.push("Images/Math/LeuvenWindowSpiralRosette.jpg");
                imageUrls.push("Images/Math/NewEyeLayeredCeiling.jpg");
                imageUrls.push("Images/Math/NewEyeExplosion.jpg");
                imageUrls.push("Images/Math/NewEyeLayeredDoubleCircleSwirl.jpg");
                imageUrls.push("Images/Math/LeuvenWindowSpiralWithSpirals.jpg");
                imageUrls.push("Images/Math/NewEyePowerFour.jpg");
                imageUrls.push("Images/Math/LeuvenDoorGlassDream.jpg");
                imageUrls.push("Images/Math/LeuvenWindowDoubleStar.jpg");
                imageUrls.push("Images/Math/MechelenStadhuisMobiusOne.jpg");
                imageUrls.push("Images/Math/MechelenStadhuisCloverSpiral.jpg");
                imageUrls.push("Images/Math/TheMagnificentTreeNightSpiral.jpg");
                imageUrls.push("Images/Math/MechelenStadhuisGlassRosette.jpg");
                imageUrls.push("Images/Math/MushroomDoubleClover.jpg");
                imageUrls.push("Images/Math/SermioneHyperbolica.jpg");
                imageUrls.push("Images/Math/SpiralMix.jpg");
                imageUrls.push("Images/Math/MechelenStadhuisSpiralMadness.jpg");
                imageUrls.push("Images/Math/TheMagnificentTreeNightMobius.jpg");
                imageUrls.push("Images/Math/MushroomDoubleFlower.jpg");
                imageUrls.push("Images/Math/TheMagnificentTreeSpiral.jpg");
                imageUrls.push("Images/Math/ThirdEyeCircle.jpg");
                imageUrls.push("Images/Math/LeuvenWindowsSquare.jpg");
                imageUrls.push("Images/Math/ThirdEyeMenSpiral.jpg");
                imageUrls.push("Images/Math/MushroomFlower.jpg");
                imageUrls.push("Images/Math/LosMeurtos.jpg");
                imageUrls.push("Images/Math/LeuvenWindowSpirals.jpg");
                imageUrls.push("Images/Math/DreamOfForfathers.jpg");
                imageUrls.push("Images/Math/MushroomTrinity.jpg");
                imageUrls.push("Images/Math/ThirdEyeCathedral.jpg");
                imageUrls.push("Images/Math/MushroomTrip.jpg");
                imageUrls.push("Images/Math/EyeTrailSpiralGathering.jpg");
                imageUrls.push("Images/Math/FortySixAndTwo.jpg");
                imageUrls.push("Images/Math/ThirdEyeParabola.jpg");
                imageUrls.push("Images/Math/EyeTrailAttractorEleven.jpg");
                imageUrls.push("Images/Math/EyesFlowerExplosion.jpg");
                imageUrls.push("Images/Math/ToolStarSeven.jpg");
                imageUrls.push("Images/Math/ToolStarTwirlSpiral.jpg");
                imageUrls.push("Images/Math/JaggedSpiralCoralBall.jpg");
                imageUrls.push("Images/Math/MushroomTriangle.jpg");
                imageUrls.push("Images/Math/MushroomCollision.jpg");
                imageUrls.push("Images/Math/MushroomLook.jpg");
                imageUrls.push("Images/Math/EyeTrailSpiralSpiral.jpg");
                imageUrls.push("Images/Math/EyeSpiralBall.jpg");
                imageUrls.push("Images/Math/ToolStarSpiderWeb.jpg");
                imageUrls.push("Images/Math/ToolStarCircleSeven.jpg");
                imageUrls.push("Images/Math/ToolStarExtreme.jpg");
                imageUrls.push("Images/Math/EyeStarMobius.jpg");
                imageUrls.push("Images/Math/EyeStarDoubleSpiral.jpg");
                imageUrls.push("Images/Math/Panspermia.jpg");
                imageUrls.push("Images/Math/Paranoia.jpg");
                imageUrls.push("Images/Math/MushroomFairyCircle.jpg");
                imageUrls.push("Images/Math/MushroomSixEyes.jpg");
                imageUrls.push("Images/Math/EyeFlowerNineThirteen.jpg");
                imageUrls.push("Images/Math/EyeStarDoubleMobius.jpg");
                imageUrls.push("Images/Math/EyeSpiralsThirteenAndOne.jpg");
                imageUrls.push("Images/Math/RustedTBoxTessellationMobius.jpg");
                imageUrls.push("Images/Math/WelcomeBackHAL.jpg");
                imageUrls.push("Images/Math/SauronTwist.jpg");
                imageUrls.push("Images/Math/ThirdEye.jpg");
                imageUrls.push("Images/Math/EyeByWire.jpg");
                imageUrls.push("Images/Math/InfinityStare.jpg");
                imageUrls.push("Images/Math/RadiantEyes.jpg");
                imageUrls.push("Images/Math/DigitalEspionage.jpg");
                imageUrls.push("Images/Math/Introspection.jpg");
                imageUrls.push("Images/Math/SpiralOut.jpg");
                imageUrls.push("Images/Math/SpiralNirvana.jpg");
                imageUrls.push("Images/Math/VanGoghsFlowerDream.jpg");
                imageUrls.push("Images/Math/CopperCoilSpiral.jpg");
                imageUrls.push("Images/Math/NewtonsEgg.jpg");
                imageUrls.push("Images/Math/SpiralZoom.jpg");
                imageUrls.push("Images/Math/OneMillionSpirals.jpg");
                imageUrls.push("Images/Math/RockBurst.jpg");
                imageUrls.push("Images/Math/NailVirus.jpg");
                imageUrls.push("Images/Math/TriangularMiniralDeposits.jpg");
                imageUrls.push("Images/Math/IcyWorldsCore.jpg");
                imageUrls.push("Images/Math/LostCivilizations.jpg");
                imageUrls.push("Images/Math/WorldsFromWithin.jpg");
                imageUrls.push("Images/Math/AncientSpaceCities.jpg");
                imageUrls.push("Images/Math/HalNewton.jpg");
                imageUrls.push("Images/Math/VonoroiSpace_3.jpg");
                imageUrls.push("Images/Math/SpookySnakesCateyes.jpg");
                imageUrls.push("Images/Math/GlassCoilFatou.jpg");
                imageUrls.push("Images/Math/SpiralWorld.jpg");
                imageUrls.push("Images/Math/SnakeMagic.jpg");
                imageUrls.push("Images/Math/TwistedSnakeSimpleSpiral.jpg");
                imageUrls.push("Images/Math/TwistedSnake3Spirals.jpg");
                imageUrls.push("Images/Math/TwistedSnakeMobius.jpg");
                imageUrls.push("Images/Math/SnakeWorld_3.jpg");
                imageUrls.push("Images/Math/GothicSkyscraper.jpg");
                imageUrls.push("Images/Math/TheUltimateParticle.jpg");
                imageUrls.push("Images/Math/FresnelTunnel.jpg");
                imageUrls.push("Images/Math/FlowerPowerTwirls.jpg");
                imageUrls.push("Images/Math/SpiralRa.jpg");
                imageUrls.push("Images/Math/CountingSheep.jpg");
                imageUrls.push("Images/Math/BlackYellowTubeMagic.jpg");
                imageUrls.push("Images/Math/KelticSnakeKnot.jpg");
                imageUrls.push("Images/Math/GigeresqueSpiral.jpg");
                imageUrls.push("Images/Math/BlackYellowConnections.jpg");
                imageUrls.push("Images/Math/HexagonalArrowTessellationSpirals.jpg");
                imageUrls.push("Images/Math/GoldenSnakeAttractiveBassinSpiral.jpg");
                imageUrls.push("Images/Math/Snake3InterconnectedSpirals.jpg");
                imageUrls.push("Images/Math/SpongyStarlight.jpg");
                imageUrls.push("Images/Math/Trypophobia.jpg");
                imageUrls.push("Images/Math/GigerSpace_1.jpg");
                imageUrls.push("Images/Math/SpookySnakes.jpg");
                imageUrls.push("Images/Math/BlackWhiteSnakeCircle.jpg");
                imageUrls.push("Images/Math/ThereAreEddiesInTheSpaceTimeContinuum.jpg");
                imageUrls.push("Images/Math/HexagonArrowTessellationCircles.jpg");
                imageUrls.push("Images/Math/GothicOrganicCity.jpg");
                imageUrls.push("Images/Math/ZebraQuadSpirals.jpg");
                imageUrls.push("Images/Math/SnakeEyeWatcherCircle.jpg");
                imageUrls.push("Images/Math/SnakeTriangularConnection.jpg");
                imageUrls.push("Images/Math/GoldenSnakeMandala.jpg");
                imageUrls.push("Images/Math/GoldenSnakeEyes.jpg");
                imageUrls.push("Images/Math/SnakeEyeTriangle.jpg");
                imageUrls.push("Images/Math/TBoxFlowerCirlce.jpg");
                imageUrls.push("Images/Math/GaudiGothicWithBackground.jpg");
                imageUrls.push("Images/Math/SirmioneOctaSpiral.jpg");
                imageUrls.push("Images/Math/MechelenStadhuisSideBullseye.jpg");
                imageUrls.push("Images/Math/MechelenStadhuisSideInfiniteArena.jpg");
                imageUrls.push("Images/Math/EschersPrison.jpg");
                imageUrls.push("Images/Math/FractalButterfly.jpg");
                imageUrls.push("Images/Math/FractalSolarEclipse.jpg");
                imageUrls.push("Images/Math/StrangeGothicCity.jpg");
                imageUrls.push("Images/Math/YellowSunflowerMobius.jpg");
                imageUrls.push("Images/Math/SpiralPiano.jpg");
                imageUrls.push("Images/Math/MechelenStadhuisSideMobius.jpg");
                imageUrls.push("Images/Math/AttractiveGoldFractal.jpg");
                imageUrls.push("Images/Math/InfinitePiano.jpg");
                imageUrls.push("Images/Math/MidnightStar.jpg");
                imageUrls.push("Images/Math/SintRomboutsSideWindowSpirals.jpg");
                imageUrls.push("Images/Math/MechelenStadhuisSideHolomorphic.jpg");
                imageUrls.push("Images/Math/MechelenStadhuisSideDoubleSpiral.jpg");
                imageUrls.push("Images/Math/EsherWindows.jpg");
                imageUrls.push("Images/Math/QuadrupleSmile.jpg");
                imageUrls.push("Images/Math/MidnightSunSpirals.jpg");
                imageUrls.push("Images/Math/MobiusForest.jpg");
                imageUrls.push("Images/Math/SunAndShadowsDoubleSpiral.jpg");
                imageUrls.push("Images/Math/SunAndShadowsSpiral.jpg");
                imageUrls.push("Images/Math/CosmicCandy.jpg");
                imageUrls.push("Images/Math/EsherWindowSpirals.jpg");
                imageUrls.push("Images/Math/TheImaginaryKiss.jpg");
                imageUrls.push("Images/Math/RedAndYellowTulipSpirals.jpg");
                imageUrls.push("Images/Math/AsianDoubleSpiral.jpg");
                imageUrls.push("Images/Math/XBetween5Spirals.jpg");
                imageUrls.push("Images/Math/InfiniteLove.jpg");
                imageUrls.push("Images/Math/LookAtInfinity.jpg");
                imageUrls.push("Images/Math/SkinOnSkinLove.jpg");
                imageUrls.push("Images/Math/TheHiddenKnight.jpg");
                imageUrls.push("Images/Math/BleachedCornflowerSpirals.jpg");
                imageUrls.push("Images/Math/SpiralLight.jpg");
                imageUrls.push("Images/Math/NewtonsEye.jpg");
                imageUrls.push("Images/Math/CloverMirror.jpg");
                imageUrls.push("Images/Math/MirrorMirrorOnTheWallOval.jpg");
                imageUrls.push("Images/Math/SevenPhotographers.jpg");
                imageUrls.push("Images/Math/ArgusSupreme.jpg");
                imageUrls.push("Images/Math/SleekMirrorSpace.jpg");
                imageUrls.push("Images/Math/BlackWhitePrimitiveJagged.jpg");
                imageUrls.push("Images/Math/DeliciouslyYellow.jpg");
                imageUrls.push("Images/Math/DnaFabric.jpg");
                imageUrls.push("Images/Math/IWillBeWatchingYou.jpg");
                imageUrls.push("Images/Math/NewtonArgusFlower.jpg");
                imageUrls.push("Images/Math/SeaOfEyes.jpg");
                imageUrls.push("Images/Math/TheBirthOfArgus.jpg");
                imageUrls.push("Images/Math/TheTrinityOfEyes.jpg");
                imageUrls.push("Images/Math/YellowSeahorse.jpg");
                imageUrls.push("Images/Math/YellowSpiralFlower.jpg");
                imageUrls.push("Images/Math/YourDigitalLife.jpg");
                imageUrls.push("Images/Math/ElevenSpirals.jpg");
                imageUrls.push("Images/Math/TubularExplosion.jpg");
                imageUrls.push("Images/Math/TrappedBetweenTime.jpg");
                imageUrls.push("Images/Math/DiamondMirror.jpg");
                imageUrls.push("Images/Math/MathematicalWeaving.jpg");
                imageUrls.push("Images/Math/MathematicalEpiphany.jpg");
                imageUrls.push("Images/Math/BlackWhiteFusion.jpg");
                imageUrls.push("Images/Math/InfinityKnots.jpg");
                imageUrls.push("Images/Math/KnottedSpace.jpg");
                imageUrls.push("Images/Math/DonutKnot.jpg");
                imageUrls.push("Images/Math/Tokamak.jpg");
                imageUrls.push("Images/Math/IntricateWebOfSpirals.jpg");
                imageUrls.push("Images/Math/SpiralGateway.jpg");
                imageUrls.push("Images/Math/MeetMeAtTheCentre.jpg");
                imageUrls.push("Images/Math/BigBangMath.jpg");
                imageUrls.push("Images/Math/ColoredPentagram.jpg");
                imageUrls.push("Images/Math/BlackWhiteOrangeCheckers.jpg");
                imageUrls.push("Images/Math/BinaryRealm.jpg");
                imageUrls.push("Images/Math/Bound.jpg");
                imageUrls.push("Images/Math/CirclesWithinCircles.jpg");
                imageUrls.push("Images/Math/Cocoon.jpg");
                imageUrls.push("Images/Math/ComplexerKnot.jpg");
                imageUrls.push("Images/Math/FatouFlower.jpg");
                imageUrls.push("Images/Math/GoldenJulia.jpg");
                imageUrls.push("Images/Math/GoldenLaceJulia.jpg");
                imageUrls.push("Images/Math/HeartShapedBox.jpg");
                imageUrls.push("Images/Math/InnerWorld.jpg");
                imageUrls.push("Images/Math/IronSpiral.jpg");
                imageUrls.push("Images/Math/JuliaPower3PurpleOrange.jpg");
                imageUrls.push("Images/Math/LemonSquash.jpg");
                imageUrls.push("Images/Math/LightbulbCircle.jpg");
                imageUrls.push("Images/Math/Lightworld.jpg");
                imageUrls.push("Images/Math/MathSun.jpg");
                imageUrls.push("Images/Math/MysteriousBloodLine.jpg");
                imageUrls.push("Images/Math/MysteryPearls.jpg");
                imageUrls.push("Images/Math/PearlShellCircle.jpg");
                imageUrls.push("Images/Math/QuadFlower.jpg");
                imageUrls.push("Images/Math/QuadLight.jpg");
                imageUrls.push("Images/Math/Quasar.jpg");
                imageUrls.push("Images/Math/RedCoralCircle.jpg");
                imageUrls.push("Images/Math/RedScape.jpg");
                imageUrls.push("Images/Math/RedStarfish.jpg");
                imageUrls.push("Images/Math/ShockWaves.jpg");
                imageUrls.push("Images/Math/SimpleBlack&WhiteSpiral.jpg");
                imageUrls.push("Images/Math/Starburst.jpg");
                imageUrls.push("Images/Math/TwirlSpace.jpg");
                imageTitles.push("Sint Roumbouts Spiral Space 8&2");
                imageTitles.push("Sint Roumbouts Double Spiral One");
                imageTitles.push("Satan Spiral");
                imageTitles.push("Sint Rombouts Holomorphic Six Fold");
                imageTitles.push("Satan's Pit");
                imageTitles.push("Sint Rombouts Glass Rosette and Corridors");
                imageTitles.push("Satan's Pentagram");
                imageTitles.push("Leuven Window Circular Skyscraper");
                imageTitles.push("Leuven Window Spiral Rosette");
                imageTitles.push("Eye Ceiling");
                imageTitles.push("Eye Explosion");
                imageTitles.push("Eye Double Circle Swirl");
                imageTitles.push("Leuven Window Spiral With Spirals");
                imageTitles.push("Eye Power");
                imageTitles.push("Leuven Door, Glass Dream");
                imageTitles.push("Leuven WindowDoubleStar.jpg");
                imageTitles.push("Mechelen Townhall - Möbius One");
                imageTitles.push("Mechelen Townhall - Clover Spiral");
                imageTitles.push("The Magnificent Tree Night Spiral");
                imageTitles.push("Mechelen Townhall - Glass Rosette");
                imageTitles.push("Mushrooms Clover");
                imageTitles.push("Sirmione Castle - Hyperbolica");
                imageTitles.push("Spiral Mix");
                imageTitles.push("Mechelen Townhall - Spiral Madness");
                imageTitles.push("The Magnificent Tree Night Möbius");
                imageTitles.push("Mushrooms Flower");
                imageTitles.push("The Magnificent Tree Spiral");
                imageTitles.push("Third Eye Circle");
                imageTitles.push("Leuven Windows Square");
                imageTitles.push("Prying open my third eye!");
                imageTitles.push("Mushroom Flower");
                imageTitles.push("Los Meurtos");
                imageTitles.push("Leuven Window Spirals");
                imageTitles.push("Dream Of Forefathers");
                imageTitles.push("Mushroom Trinity");
                imageTitles.push("Third Eye Cathedral");
                imageTitles.push("MushroomTrip.jpg");
                imageTitles.push("The Gathering");
                imageTitles.push("46 & 2");
                imageTitles.push("Third Eye Parabola");
                imageTitles.push("Attractor-Newton Fractal Eleven");
                imageTitles.push("Eyes Flower Explosion");
                imageTitles.push("Eye Star Seven");
                imageTitles.push("Eye Star Twirl Spiral");
                imageTitles.push("Jagged Spiral Coral Ball");
                imageTitles.push("Mushroom Triangle");
                imageTitles.push("Mushroom Collision");
                imageTitles.push("Mushroom Look");
                imageTitles.push("Eye Trail Spiral");
                imageTitles.push("Eye Spiral Ball");
                imageTitles.push("Eye Star Spider Web");
                imageTitles.push("Eye Star Circle Seven");
                imageTitles.push("Eye Star Extreme");
                imageTitles.push("Eye Star Möbius");
                imageTitles.push("Eye Star Double Spiral");
                imageTitles.push("Panspermia");
                imageTitles.push("Paranoia");
                imageTitles.push("Mushroom Fairy Ring");
                imageTitles.push("Mushroom Six Eyes");
                imageTitles.push("Eye Flower 9-13");
                imageTitles.push("Eye Star Double Möbius");
                imageTitles.push("Eye Spirals 13-1");
                imageTitles.push("Rusted T-Box Tessellation Möbius");
                imageTitles.push("Welcome Back HAL");
                imageTitles.push("Sauron Twist");
                imageTitles.push("Third Eye");
                imageTitles.push("Eye By Wire");
                imageTitles.push("Infinity Stare");
                imageTitles.push("Radiant Eyes");
                imageTitles.push("Digital Espionage");
                imageTitles.push("Introspection");
                imageTitles.push("Spiral Out!");
                imageTitles.push("Spiral Nirvana");
                imageTitles.push("Van Gogh's Flower Dream");
                imageTitles.push("Copper Coil Spiral");
                imageTitles.push("Newton's Egg");
                imageTitles.push("Spiral Zoom");
                imageTitles.push("One Million Spirals");
                imageTitles.push("Rock Burst");
                imageTitles.push("Nail Virus");
                imageTitles.push("Triangular Miniral Deposits");
                imageTitles.push("Icy Worlds Core");
                imageTitles.push("Lost Civilizations");
                imageTitles.push("Worlds From Within");
                imageTitles.push("Ancient Space Cities");
                imageTitles.push("Hal-Newton");
                imageTitles.push("Vonoroi Space 3");
                imageTitles.push("Spooky Snakes Cateyes");
                imageTitles.push("Glass Coil Fatou");
                imageTitles.push("Spiral World");
                imageTitles.push("Snake Magic");
                imageTitles.push("Twisted Snake Spiral");
                imageTitles.push("Twisted Snake - 3 Spirals");
                imageTitles.push("Twisted Snake Möbius");
                imageTitles.push("SnakeWorld 3");
                imageTitles.push("Gothic Skyscraper");
                imageTitles.push("The Ultimate Particle");
                imageTitles.push("Fresnel Tunnel");
                imageTitles.push("Flower Power Twirls");
                imageTitles.push("Spiral Ra");
                imageTitles.push("Counting Sheep");
                imageTitles.push("Black & Yellow Tube Magic");
                imageTitles.push("Keltic Snake Knot");
                imageTitles.push("Gigeresque Spiral");
                imageTitles.push("Black & Yellow Connections");
                imageTitles.push("Hexagonal Arrow Tessellation Spirals");
                imageTitles.push("Golden Snake Attractive Bassin Spirals");
                imageTitles.push("Snake 3 Interconnected Spirals");
                imageTitles.push("Spongy Starlight");
                imageTitles.push("Trypophobia");
                imageTitles.push("Giger Space 1");
                imageTitles.push("Spooky Snakes");
                imageTitles.push("Black & White Snake Circle");
                imageTitles.push("There are eddies in the Space-Time Continuum");
                imageTitles.push("Hexagonal Arrow Tessellation Circles");
                imageTitles.push("Gothic Organic City");
                imageTitles.push("Zebra Quad Spirals");
                imageTitles.push("SnakeEyeWatcherCircle");
                imageTitles.push("SnakeTriangularConnection");
                imageTitles.push("GoldenSnakeMandala");
                imageTitles.push("GoldenSnakeEyes");
                imageTitles.push("SnakeEyeTriangle");
                imageTitles.push("T-Box Flower Cirlce");
                imageTitles.push("Gaudi Gothic");
                imageTitles.push("Sirmione Octa Spiral");
                imageTitles.push("Gothic Bullseye");
                imageTitles.push("Infinite Arena");
                imageTitles.push("Escher's Prison");
                imageTitles.push("Fractal Butterfly");
                imageTitles.push("Fractal Solar Eclipse");
                imageTitles.push("Strange Gothic City");
                imageTitles.push("Yellow Sunflower");
                imageTitles.push("Spiral Piano");
                imageTitles.push("Mechelen Stadhuis Möbius");
                imageTitles.push("Attractive Gold Fractal");
                imageTitles.push("Infinite Piano");
                imageTitles.push("Midnight Star");
                imageTitles.push("Sint-Rombouts Window Spirals");
                imageTitles.push("Mechelen Townhall Holomorphic");
                imageTitles.push("Mechelen Townhall Double Spiral");
                imageTitles.push("Esher Windows");
                imageTitles.push("Quadruple Smile");
                imageTitles.push("Midnight Sun Spirals");
                imageTitles.push("Möbius Forest");
                imageTitles.push("Sun & Shadows Double Spiral");
                imageTitles.push("Sun & Shadows Spiral");
                imageTitles.push("Cosmic Candy");
                imageTitles.push("Esher Window Spirals");
                imageTitles.push("The Imaginary Kiss");
                imageTitles.push("Red & Yellow Tulip Spirals");
                imageTitles.push("Asian Double Spiral");
                imageTitles.push("X Between 5 Spirals");
                imageTitles.push("Infinite Love");
                imageTitles.push("Look At Infinity");
                imageTitles.push("Skin On Skin Love");
                imageTitles.push("The Hidden Knight");
                imageTitles.push("Bleached Cornflower Spirals");
                imageTitles.push("SpiralLight");
                imageTitles.push("Newton's Eye");
                imageTitles.push("Clover Mirror");
                imageTitles.push("Mirror Mirror On The Wall");
                imageTitles.push("Seven Photographers");
                imageTitles.push("Argus Supreme");
                imageTitles.push("Sleek Mirror Space");
                imageTitles.push("Primitive Jagged");
                imageTitles.push("Deliciously Yellow");
                imageTitles.push("Dna Fabric");
                imageTitles.push("I'll be watching you");
                imageTitles.push("Newton Argus Flower");
                imageTitles.push("Sea Of Eyes");
                imageTitles.push("The Birth Of Argus");
                imageTitles.push("The Trinity Of Eyes");
                imageTitles.push("Yellow Seahorse");
                imageTitles.push("Yellow Spiral Flower");
                imageTitles.push("Your Digital Life");
                imageTitles.push("Eleven Spirals");
                imageTitles.push("Tubular Explosion");
                imageTitles.push("Trapped Between Time");
                imageTitles.push("Diamond Mirror");
                imageTitles.push("Mathematical Weaving");
                imageTitles.push("Mathematical Epiphany");
                imageTitles.push("Black & White Fusion");
                imageTitles.push("Infinity Knots");
                imageTitles.push("Knotted Space");
                imageTitles.push("Donut Knot");
                imageTitles.push("Tokamak");
                imageTitles.push("Intricate Web Of Spirals");
                imageTitles.push("SpiralGateway");
                imageTitles.push("Meet Me At The Centre ");
                imageTitles.push("Big-Bang Math");
                imageTitles.push("Colored Pentagram");
                imageTitles.push("Black, White, Orange Checkers");
                imageTitles.push("Binary Realm");
                imageTitles.push("Bound");
                imageTitles.push("Circles within Circles");
                imageTitles.push("Cocoon");
                imageTitles.push("Complexer Knot");
                imageTitles.push("Fatou Flower");
                imageTitles.push("Golden Julia");
                imageTitles.push("Golden Lace Julia");
                imageTitles.push("Heart Shaped Box");
                imageTitles.push("Inner World");
                imageTitles.push("Iron Spiral");
                imageTitles.push("Julia of the third power");
                imageTitles.push("Lemon Squash");
                imageTitles.push("Lightbulb Circle");
                imageTitles.push("Light World");
                imageTitles.push("Math Sun");
                imageTitles.push("Mysterious Bloodline");
                imageTitles.push("Mystery Pearls");
                imageTitles.push("Pearlshell Circle");
                imageTitles.push("Quad Flower");
                imageTitles.push("Quad Light");
                imageTitles.push("Quasar");
                imageTitles.push("Red Coral Circle");
                imageTitles.push("Redscape");
                imageTitles.push("Red Starfish");
                imageTitles.push("Shockwaves");
                imageTitles.push("Simple Black&White Spiral");
                imageTitles.push("Starburst");
                imageTitles.push("Twirl Space");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(SetupControl.ThemeMath);
            };
            SetupControl.SetMenuLogos = function (menuItem) {
                SetupControl.title.Text = menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Logos/Nomad.jpg");
                imageUrls.push("Images/Logos/BugFactory.jpg");
                imageUrls.push("Images/Logos/Evolver.jpg");
                imageUrls.push("Images/Logos/GIT.png");
                imageUrls.push("Images/Logos/X-Pose.jpg");
                imageUrls.push("Images/Logos/GPOD.jpg");
                imageUrls.push("Images/Logos/IAM.png");
                imageUrls.push("Images/Logos/Kaisho.jpg");
                imageUrls.push("Images/Logos/Kobold.jpg");
                imageUrls.push("Images/Logos/lepinotblanc.png");
                imageUrls.push("Images/Logos/Mithra.png");
                imageUrls.push("Images/Logos/Scalmat.png");
                imageUrls.push("Images/Logos/Tripz.jpg");
                imageUrls.push("Images/Logos/Xfp_2.png");
                imageTitles.push("Nomad");
                imageTitles.push("BugFactory");
                imageTitles.push("Evolver");
                imageTitles.push("GIT");
                imageTitles.push("X-Pose");
                imageTitles.push("G-POD");
                imageTitles.push("IAM");
                imageTitles.push("Kaisho");
                imageTitles.push("Kobold");
                imageTitles.push("Le Pinot Blanc");
                imageTitles.push("Mithra");
                imageTitles.push("Scalmat");
                imageTitles.push("Tripz");
                imageTitles.push("Xfp");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuArt = function (menuItem) {
                if (menuItem.subMenuItems.length > 0) {
                    var found = false;
                    for (var iMenu = 0; iMenu < menuItem.subMenuItems.length; iMenu--) {
                        if (menuItem.subMenuItems[iMenu].menuText == "Spirals") {
                            var subMenuItem = menuItem.subMenuItems[0];
                            subMenuItem.clickedMenu(subMenuItem);
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        var subMenuItem = menuItem.subMenuItems[0];
                        subMenuItem.clickedMenu(subMenuItem);
                    }
                }
                SetupControl.title.Text = menuItem.menuText;
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuSpirals = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                menuItem.parentMenu.clickedMenu(menuItem);
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Art/Spirals/Frazer_6.jpg");
                imageUrls.push("Images/Art/Spirals/Frazer_Spikes.jpg");
                imageUrls.push("Images/Art/Spirals/4Leaves.jpg");
                imageUrls.push("Images/Art/Spirals/SixtyNineDegrees.jpg");
                imageUrls.push("Images/Art/Spirals/AnotherKindOfInfinity.jpg");
                imageUrls.push("Images/Art/Spirals/Asian.jpg");
                imageUrls.push("Images/Art/Spirals/BWild.jpg");
                imageUrls.push("Images/Art/Spirals/Cannabis.jpg");
                imageUrls.push("Images/Art/Spirals/Cornflower.jpg");
                imageUrls.push("Images/Art/Spirals/Cranebird.jpg");
                imageUrls.push("Images/Art/Spirals/CurlyFlower.jpg");
                imageUrls.push("Images/Art/Spirals/DnaSpiral.jpg");
                imageUrls.push("Images/Art/Spirals/DoubleNautilus.jpg");
                imageUrls.push("Images/Art/Spirals/EventHorizon.jpg");
                imageUrls.push("Images/Art/Spirals/KnotOfLeaves.jpg");
                imageUrls.push("Images/Art/Spirals/LightTwirl.jpg");
                imageUrls.push("Images/Art/Spirals/LSDTrip.jpg");
                imageUrls.push("Images/Art/Spirals/MysticalPlant.jpg");
                imageUrls.push("Images/Art/Spirals/MysticalPlant_II.jpg");
                imageUrls.push("Images/Art/Spirals/MysticalPlantIII.jpg");
                imageUrls.push("Images/Art/Spirals/NautilusFlower.jpg");
                imageUrls.push("Images/Art/Spirals/OrientalFlower.jpg");
                imageUrls.push("Images/Art/Spirals/Peacock.jpg");
                imageUrls.push("Images/Art/Spirals/PeriodicallyTwistingSpiral.jpg");
                imageUrls.push("Images/Art/Spirals/Phoenix.jpg");
                imageUrls.push("Images/Art/Spirals/Snake.jpg");
                imageUrls.push("Images/Art/Spirals/SpiralFlower.jpg");
                imageUrls.push("Images/Art/Spirals/TheTriangle.jpg");
                imageUrls.push("Images/Art/Spirals/TrippingDonut.jpg");
                imageUrls.push("Images/Art/Spirals/TwistedTriangularSpiral_II.jpg");
                imageTitles.push("Frazer Six");
                imageTitles.push("Frazer Spikes");
                imageTitles.push("4 Leaves spiral");
                imageTitles.push("69 Degrees");
                imageTitles.push("Another kind of Infinity");
                imageTitles.push("Asian");
                imageTitles.push("B.Wild");
                imageTitles.push("Cannabis");
                imageTitles.push("Corn flower");
                imageTitles.push("Cranebird");
                imageTitles.push("Curly Flower");
                imageTitles.push("Dna Spiral");
                imageTitles.push("Double Nautilus");
                imageTitles.push("Event Horizon");
                imageTitles.push("Knot Of Leaves");
                imageTitles.push("Light twirl");
                imageTitles.push("LSD Trip");
                imageTitles.push("Mystical Plant");
                imageTitles.push("Mystical Plant II");
                imageTitles.push("Mystical Plant III");
                imageTitles.push("Nautilus Flower");
                imageTitles.push("Oriental Flower");
                imageTitles.push("Peacock");
                imageTitles.push("Periodically Twisting Spiral");
                imageTitles.push("Phoenix");
                imageTitles.push("Snake");
                imageTitles.push("Spiral Flower");
                imageTitles.push("The Triangle");
                imageTitles.push("Tripping Donut");
                imageTitles.push("Twisted Triangular Spiral II");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuMdf = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Art/Mdf/BeenSmokingTooMuch.jpg");
                imageUrls.push("Images/Art/Mdf/CandleLady.jpg");
                imageUrls.push("Images/Art/Mdf/SpiralOfCircles.jpg");
                imageUrls.push("Images/Art/Mdf/Curvy_II_Painted.jpg");
                imageUrls.push("Images/Art/Mdf/Curvy_Penne.jpg");
                imageUrls.push("Images/Art/Mdf/Heart.jpg");
                imageUrls.push("Images/Art/Mdf/KaderVoorEls.jpg");
                imageUrls.push("Images/Art/Mdf/lady.jpg");
                imageUrls.push("Images/Art/Mdf/LoveTulip.jpg");
                imageUrls.push("Images/Art/Mdf/MexicanEye.jpg");
                imageUrls.push("Images/Art/Mdf/Seahorse_Inox.jpg");
                imageTitles.push("Been smoking too much");
                imageTitles.push("Candle Lady");
                imageTitles.push("Spiral Of Circles (86x88 cm)");
                imageTitles.push("Curvy II");
                imageTitles.push("Curvy Penne");
                imageTitles.push("Heart");
                imageTitles.push("Frame for Els");
                imageTitles.push("Lady");
                imageTitles.push("Love Tulip");
                imageTitles.push("Mexican Eye");
                imageTitles.push("Seahorse (Inox)");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuWallArt = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Art/WallArt/SideWallManadala.jpg");
                imageTitles.push("Side wall mandala - Acryl 53x205cm");
                imageUrls.push("Images/Art/WallArt/Flames.jpg");
                imageTitles.push("Flames - Acryl 60x95cm");
                imageUrls.push("Images/Art/WallArt/SpiralFlowerMandala.jpg");
                imageTitles.push("Spiral flower mandala - Acryl 79x180cm");
                imageUrls.push("Images/Art/WallArt/ToiletMandala.jpg");
                imageTitles.push("Toilet Mandala - Acryl 110x110cm");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuPaintings = function (menuItem) {
                SetupControl.title.Text = menuItem.parentMenu.menuText + " : " + menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                imageUrls.push("Images/Art/Paintings/Whales.jpg");
                imageUrls.push("Images/Art/Paintings/Chameleon.jpg");
                imageUrls.push("Images/Art/Paintings/Pauw.jpg");
                imageUrls.push("Images/Art/Paintings/Oehoe.jpg");
                imageUrls.push("Images/Art/Paintings/Leeuwin.jpg");
                imageUrls.push("Images/Art/Paintings/AbstractForm.jpg");
                imageUrls.push("Images/Art/Paintings/McDonnell_Rf-101C_Voodoo.jpg");
                imageUrls.push("Images/Art/Paintings/Els.jpg");
                imageUrls.push("Images/Art/Paintings/CaitlinPlop.jpg");
                imageUrls.push("Images/Art/Paintings/Mechelen_Zenne_Zonsondergang.jpg");
                imageUrls.push("Images/Art/Paintings/Rose.jpg");
                imageUrls.push("Images/Art/Paintings/PalmLeafsShadows.jpg");
                imageTitles.push("Whales, Owen's birthcard on 100% cotton cold pressed paper. 41x31cm.");
                imageTitles.push("Chameleon, watercolour, Gouache, gold acrylic ink on 100% cotton cold pressed paper. 41x31cm.");
                imageTitles.push("Peacock, Acryl on MDF, 122x81cm");
                imageTitles.push("Owl, Acryl on MDF, 122x81cm");
                imageTitles.push("Lionness, Acryl on MDF 122x122cm");
                imageTitles.push("Abstract form, Oil on MDF, 80x122cm");
                imageTitles.push("Mc Donnell Rf-101C Voodoo, Oil on hardboard");
                imageTitles.push("Els, Oil on hardboard");
                imageTitles.push("Caitlin, Oil on hardboard");
                imageTitles.push("Sunset, Oil on MDF");
                imageTitles.push("Rose, Oil on hardboard.");
                imageTitles.push("Palm Leaf Shadows, Acryl on Canvas, 50x60cm");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles);
                Web.Renderer.ThemeManager.ChangeTheme(Web.ThemeManager.ThemeDefault);
            };
            SetupControl.SetMenuSoftware = function (menuItem) {
                SetupControl.title.Text = menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                var imageClickActions = [];
                imageUrls.push("Images/Software/Xfp_2.png");
                imageUrls.push("Images/Software/MentalArithmetic.jpg");
                imageUrls.push("Images/Software/LazyVsix2017.jpg");
                imageTitles.push("Xfp 2.1 - Click image to download.");
                imageTitles.push("Mental Arithmetic - Click image to download.");
                imageTitles.push("Lazy vsix package, plugins for Visual Studio 2017 - Click image to download.");
                imageClickActions.push(function () { return SetupControl.DownloadFile('Software/Xfp.zip'); });
                imageClickActions.push(function () { return SetupControl.DownloadFile('Software/MentalArithmetic.zip'); });
                imageClickActions.push(function () { return SetupControl.DownloadFile('Software/LazyVSIX2017.zip'); });
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles, imageClickActions);
                Web.Renderer.ThemeManager.ChangeTheme(SetupControl.ThemeSoftware);
            };
            SetupControl.SetMenuContact = function (menuItem) {
                SetupControl.title.Text = menuItem.menuText;
                var imageUrls = [];
                var imageTitles = [];
                var imageClickActions = [];
                imageUrls.push("Images/contact.jpg");
                imageTitles.push("Contact me");
                SetupControl.imageStrip.SetNewImages(imageUrls, imageTitles, imageClickActions);
                Web.Renderer.ThemeManager.ChangeTheme(SetupControl.ThemeContact);
            };
            SetupControl.ThemeSoftware = "Software";
            SetupControl.ThemeContact = "Contact";
            SetupControl.ThemeMath = "Math";
            return SetupControl;
        }());
        Web.SetupControl = SetupControl;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Vector = /** @class */ (function () {
            function Vector(x, y) {
                this.DegreesToRadians = Math.PI / 180.0;
                this.x = x;
                this.y = y;
            }
            Vector.prototype.Add = function (v) {
                this.x = this.x + v.x;
                this.y = this.y + v.y;
            };
            Vector.Add = function (v1, v2) {
                return new Vector(v1.x + v2.x, v1.y + v2.y);
            };
            Vector.prototype.Subtract = function (v) {
                this.x = this.x - v.x;
                this.y = this.y - v.y;
            };
            Vector.Subtract = function (v1, v2) {
                return new Vector(v1.x - v2.x, v1.y - v2.y);
            };
            Vector.prototype.Multiply = function (n) {
                this.x = this.x * n;
                this.y = this.y * n;
            };
            Vector.Mulitply = function (v, n) {
                return new Vector(v.x * n, v.y * n);
            };
            Vector.prototype.Divide = function (n) {
                this.x = this.x / n;
                this.y = this.y / n;
            };
            Vector.prototype.Magnitude = function () {
                return Math.sqrt(this.x * this.x + this.y * this.y);
            };
            Vector.prototype.Normalize = function () {
                var m = this.Magnitude();
                if (m != 0) {
                    this.Divide(m);
                }
            };
            Vector.Normalize = function (v) {
                var m = v.Magnitude();
                if (m != 0) {
                    return new Vector(v.x / m, v.y / m);
                }
                return v;
            };
            Vector.prototype.Limit = function (max) {
                var m = this.Magnitude();
                if (m > max) {
                    this.Normalize();
                    this.Multiply(max);
                }
            };
            Vector.Equals = function (a, b) {
                return a.x == b.x && a.y == b.y;
            };
            Vector.prototype.Rotate = function (degrees) {
                this.RotateRadians(degrees * this.DegreesToRadians);
            };
            Vector.prototype.RotateRadians = function (radians) {
                var cosAngle = Math.cos(radians);
                var sinAngle = Math.sin(radians);
                this.x = cosAngle * this.x - sinAngle * this.y;
                this.y = sinAngle * this.x + cosAngle * this.y;
            };
            Vector.DotProduct = function (v1, v2) {
                return (v1.x * v2.x + v1.y * v2.y);
            };
            Vector.prototype.DotProduct = function (other) {
                return Vector.DotProduct(this, other);
            };
            Vector.Angle = function (v1, v2) {
                if (Vector.Equals(v1, v2)) {
                    return 0;
                }
                return Math.acos(Math.min(1.0, Vector.Normalize(v1).DotProduct(Vector.Normalize(v2))));
            };
            Vector.prototype.Angle = function (other) {
                return Vector.Angle(this, other);
            };
            // Linear interpolation, widely known as Lerp.
            Vector.Lerp = function (start, end, percent) {
                var endMinusStart = Vector.Subtract(end, start);
                var multiplied = Vector.Mulitply(endMinusStart, percent);
                return Vector.Add(start, multiplied);
            };
            return Vector;
        }());
        Web.Vector = Vector;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
/// <reference path="../Interfaces/Func.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Radiate = /** @class */ (function (_super) {
            __extends(Radiate, _super);
            function Radiate(size, requirement, getColor, beams, speed) {
                var _this = _super.call(this, size, requirement) || this;
                _this.beamPoints = [];
                _this.animationStartAngle = 0;
                _this.getColor = getColor;
                if (beams < 2 || beams > 90) {
                    beams = 10;
                }
                _this.beamAngle = 360 / (beams * 2);
                _this.beams = beams;
                _this.speed = speed;
                // Each beam has 3 points, which we use over and over again.
                _this.beamPoints.push(new Web.Point(0, 0));
                _this.beamPoints.push(new Web.Point(0, 0));
                _this.beamPoints.push(new Web.Point(0, 0));
                return _this;
            }
            Radiate.prototype.Render = function (width, height) {
                var centerWidth = width * .5;
                var centerHeight = height * .5;
                var radius = Math.max(width, height);
                var centerPoint = this.beamPoints[0];
                centerPoint.x = Web.Renderer.MouseX;
                centerPoint.y = Web.Renderer.MouseY;
                var angle = this.animationStartAngle;
                var color = this.getColor();
                for (var iBeam = 0; iBeam < this.beams; iBeam++) {
                    var angleRadians = Web.Renderer.ToRadians * angle;
                    var x = centerWidth + (radius * Math.cos(angleRadians));
                    var y = centerHeight - (radius * Math.sin(angleRadians));
                    var radiusPoint1 = this.beamPoints[1];
                    radiusPoint1.x = x;
                    radiusPoint1.y = y;
                    angle += this.beamAngle;
                    angleRadians = Web.Renderer.ToRadians * angle;
                    x = centerWidth + (radius * Math.cos(angleRadians));
                    y = centerHeight - (radius * Math.sin(angleRadians));
                    var radiusPoint2 = this.beamPoints[2];
                    radiusPoint2.x = x;
                    radiusPoint2.y = y;
                    Web.Renderer.FillPolygon(this.beamPoints, color);
                    angle += this.beamAngle;
                }
                var angleStep = this.speed * Web.Renderer.RenderDelta;
                this.animationStartAngle += angleStep;
            };
            return Radiate;
        }(Web.AutoDrawingBase));
        Web.Radiate = Radiate;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
/// <reference path="AutoDrawingBase.ts"/>
/// <reference path="../Interfaces/Func.ts"/>
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Area = /** @class */ (function (_super) {
            __extends(Area, _super);
            function Area(size, requirement, getColor) {
                var _this = _super.call(this, size, requirement) || this;
                _this.getColor = getColor;
                _this.maxSize = size;
                return _this;
            }
            Area.prototype.MeasureDock = function (otherSize) {
                if (this.Dock == Web.GraphDocking.Bottom || this.Dock == Web.GraphDocking.Top) {
                    var maxHeight = Web.Renderer.Height * .05;
                    if (maxHeight < this.maxSize) {
                        return maxHeight;
                    }
                }
                else if (this.Dock == Web.GraphDocking.Left || this.Dock == Web.GraphDocking.Right) {
                    var maxWidth = Web.Renderer.Width * .05;
                    if (maxWidth < this.maxSize) {
                        return maxWidth;
                    }
                }
                return this.maxSize;
            };
            Area.prototype.Render = function (width, height) {
                var color = this.getColor();
                Web.Renderer.FillArea(0, 0, width, height, color);
                Web.Renderer.DrawRoundedRectangle(1, 1, width - 2, height - 2, 5, 2, false, true, color, Web.Renderer.ColorBlack);
            };
            return Area;
        }(Web.AutoDrawingBase));
        Web.Area = Area;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
window.onload = function () {
    Erroba.Web.SetupControl.Initialize(window, document);
    Erroba.Web.Renderer.Render();
};
window.onresize = function () {
    if (Erroba.Web.Renderer.Canvas != null) {
        var clientWidth = window.innerWidth;
        var clientHeight = window.innerHeight;
        Erroba.Web.Renderer.ResizeCanvas(clientWidth, clientHeight);
    }
};
var Erroba;
(function (Erroba) {
    var Web;
    (function (Web) {
        var Side = /** @class */ (function (_super) {
            __extends(Side, _super);
            function Side() {
                return _super !== null && _super.apply(this, arguments) || this;
            }
            Object.defineProperty(Side.prototype, "FillColor", {
                get: function () { return this.fillColor; },
                set: function (value) { this.fillColor = value; },
                enumerable: true,
                configurable: true
            });
            Side.prototype.MeasureDock = function (otherSize) {
                return 25;
            };
            Side.prototype.Render = function (width, height) {
                Web.Renderer.FillArea(0, 0, width, height, this.fillColor);
            };
            return Side;
        }(Web.AutoDrawingBase));
        Web.Side = Side;
    })(Web = Erroba.Web || (Erroba.Web = {}));
})(Erroba || (Erroba = {}));
//# sourceMappingURL=Main.js.map